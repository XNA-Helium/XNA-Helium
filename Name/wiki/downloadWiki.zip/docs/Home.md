**Project Description**
A small XNA game in the Worms Style. It runs on the Zune, Windows,  and  Xbox with a few tweaks. The code is still in for per-pixel collision and deformable terrain however the current version does not use that code because of Zune performance problems.

See Releases page for the latest update

# The Title Screen, Player Selection and Weapon selection Menu
![](Home_title.JPG)![](Home_Player.JPG)![](Home_weaponselection.JPG)
# Some in-game shots
![](Home_Shooting.JPG)![](Home_shot.JPG)


## Controls for the game are simple

# In any Menu
# Press in and Up or In and Down to change which option you have selected
# Press in on the D-Pad to select your current optoin

# In the Weapon Selection Menu
# same as any other Menu
# Press Play/Pause to exit it without any changes

# In the Game (Not in shooting mode)
# Push left or right on the D-Pad to move your unit to the left or right
# Push In on the center of the D-Pad to deploy your weapon (Your not in Shooting Mode)
# Push the Play/Pause button to get the weapon selection menu
# Press Back to end your turn, Hold Back to quit

# In the Game (In Shooting Mode)
# Push Up/Down on the D-pad to adjust hte angle of your shot
# Press In on the D-Pad (HOLD IT)
# When you release the D-Pad you will shot with a power = the time you held the D-Pad in
# Press play/pause to cancel shooting (in case your facing the wrong direction)


## Thats it ! Enjoy :)