﻿#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{
    public class NetworkGameMenu : BaseMenu
    {
        public NetworkGameMenu()
            : base()
        {
            _menu = new UIBaseMenu(@"Content\Art/GUI/MenuBackground", Vector2.Zero);
            UIButton b = new UIButton(@"Content\Art/GUI/Join", new Vector2(20, 175));
            _menu.Add(Join, b);
            b = new UIButton(@"Content\Art/GUI/Back", new Vector2(20, 245));
            _menu.Add(Back, b);
            b = new UIButton(@"Content\Art/GUI/Host", new Vector2(20, 210));
            _menu.Add(Host, b);
            _menu.Setup();
        }

        public override void Update(GameTime p_Time)
        {
            _menu.Update();
            _menu.ProcessInput(PlayerIndex.One); //only uncomment me if there are buttons
        }
        public override void ProccessInput(PlayerIndex p_index)
        {
            _menu.ProcessInput(p_index);
        }
        public override void Draw(SpriteBatch p_spriteBatch, GameTime p_Time)
        {
            _menu.Draw(p_spriteBatch, p_Time);
        }
        public override void Back()
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu(new MainMenu());
        }
        protected void Join()
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu(new JoinNetworkMenu());
        }
        protected void Host()
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu(new HostNetworkMenu());
        }
    }
}
