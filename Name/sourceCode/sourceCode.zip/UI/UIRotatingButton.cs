
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

//using PPE.Core;
//using PPE.Input;

namespace Pauliver
{

    public class UIRotatingButton : UIElementContainer<Callback>
    {
        protected int si;
        Vector2 MiddlePosition;

        public UIRotatingButton(Vector2 BasePosition)
            : base()
        {
            si = 0;
            MiddlePosition = new Vector2(BasePosition.X , BasePosition.Y);
        }
        //has a left button
        //has a right button
        //middle button rotates
        public override void Add(Callback value, UIElement Element)
        {
            Element.Position = MiddlePosition;
            base.Add(value, Element);
        }
        public virtual void Add(Callback value, String Element)
        {
            UIImageElement i = new UIImageElement(Element, MiddlePosition);
            base.Add(value, i);
        }
        public virtual void Setup(int visible)
        {
            foreach (Pair<Callback, UIElement> e in base._Elements)
            {
                e.Second.Visible = false;
            }
            base._Elements[visible].Second.Visible = true;
        }

        public virtual void ProcessInput(Pauliver.PlayerIndex p_Index)
        {
            if (si == 0)
            {
#if !ZUNE
                if (PInput.Instance.Keyboard.Enter.SinglePress)
                {
                    base._Elements[si].Second.Visible = false;
                    base._Elements[si].First.Invoke();
                    ++si;
                    base._Elements[si].Second.Visible = true;
                }
#endif
                if (PInput.Instance.GamePad(p_Index).A.SinglePress)
                {
                    base._Elements[si].Second.Visible = false;
                    base._Elements[si].First.Invoke();
                    ++si;
                    base._Elements[si].Second.Visible = true;
                }
            }
            else if (si == (_Elements.Count - 1))
            {
#if !ZUNE
                if (PInput.Instance.Keyboard.Enter.SinglePress)
                {
                    base._Elements[si].First.Invoke();
                }
#endif
                if (PInput.Instance.GamePad(p_Index).A.SinglePress)
                {
                    base._Elements[si].First.Invoke();
                }
            }
            else
            {
#if !ZUNE
                if (PInput.Instance.Keyboard.Enter.SinglePress)
                {
                    base._Elements[si].First.Invoke();
                    _Elements[si].Second.Visible = false;
                    si = _Elements.Count - 1;
                    _Elements[si].Second.Visible = true;
                }
#endif
                if (PInput.Instance.GamePad(p_Index).A.SinglePress)
                {
                    base._Elements[si].First.Invoke();
                    _Elements[si].Second.Visible = false;
                    si = _Elements.Count - 1;
                    _Elements[si].Second.Visible = true;
                }
            }
            if (si > 0 && si < _Elements.Count - 1)
            {
#if !ZUNE
                if (PInput.Instance.Keyboard.A.SinglePress)
                {
                    _Elements[si].Second.Visible = false;
                    if (++si >= (_Elements.Count - 1))
                    {
                        si = 1;
                    }
                    _Elements[si].Second.Visible = true;
                }
#endif
                if (PInput.Instance.GamePad(p_Index).DPadLeft.SinglePress)
                {
                    _Elements[si].Second.Visible = false;
                    if (++si >= (_Elements.Count - 1))
                    {
                        si = 1;
                    }
                    _Elements[si].Second.Visible = true;
                }
#if !ZUNE
                if (PInput.Instance.Keyboard.D.SinglePress)
                {
                    _Elements[si].Second.Visible = false;
                    if (--si <= 0)
                    {
                        si = _Elements.Count - 2;
                    }
                    _Elements[si].Second.Visible = true;
                }
#endif
                if (PInput.Instance.GamePad(p_Index).DPadRight.SinglePress)
                {
                    _Elements[si].Second.Visible = false;
                    if (--si <= 0)
                    {
                        si = _Elements.Count - 2;
                    }
                    _Elements[si].Second.Visible = true;
                }
            }
        }

        public bool AtFront
        {
            get
            {
                return (si == 0);
            }
        }

        public bool AtBack
        {
            get
            {
                return (si == (_Elements.Count - 1));
            }
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_Time)
        {
            base.Draw(p_SpriteBatch, p_Time);
        }
    }

}