#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{
    public class UITextElement : UIElement
    {
        Color _color;
        SpriteFont _sf;
        string _text;
        public String Text
        {
            get { return _text; }
            set { _text = value; }
        }
        public UITextElement(Vector2 Position, SpriteFont sf, string text)
            : base(Position)
        {
            _sf = sf;
            _text = text;
            _color = Color.White;
        }
        public UITextElement(Vector2 Position, SpriteFont sf, string text, Color color)
            : base(Position)
        {
            _sf = sf;
            _text = text;
            _color = color;
        }
        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_Time)
        {
            if (base.visible)
            {
                p_SpriteBatch.DrawString(_sf, _text, base._AbsolutionPosition, _color, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, 0.1f);
            }
        }
    }
}