
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{
    public class UIButton : UIElement
    {
        UIImageElement _Active;
        UIImageElement _Inactive;
        bool IsActive;
        public bool Active
        {
            get
            {
                return IsActive;
            }
            set
            {
                IsActive = value;
            }
        }
        public UIButton(String ImageName, Vector2 Position)
            : base(Position)
        {
            _Active = new UIImageElement(ImageName + "_active", Position);
            _Inactive = new UIImageElement(ImageName + "_inactive", Position);
        }
        public UIButton(String ActiveImage, String InactiveImage, Vector2 Position)
            : base(Position)
        {
            _Active = new UIImageElement(ActiveImage, Position);
            _Inactive = new UIImageElement(InactiveImage, Position);
        }
        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_Time)
        {
            if (base.visible)
            {
                if (IsActive)
                {
                    _Active.Draw(p_SpriteBatch, p_Time);
                }
                else
                {
                    _Inactive.Draw(p_SpriteBatch, p_Time);
                }
            }
        }
    }
}