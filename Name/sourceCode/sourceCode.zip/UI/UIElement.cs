
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{

    //later add base UI system
    //that loads default fonts and colors

    public abstract class UIElement
    {
        protected Vector2 _AbsolutionPosition;
        public Vector2 Position
        {
            get
            {
                return _AbsolutionPosition;
            }
            set
            {
                _AbsolutionPosition = value;
            }
        }
        protected bool visible;
        public bool Visible
        {
            get{
                return visible;
            }
            set{
                visible = value;
            }
        }

        public UIElement(Vector2 _position)
        {
            visible = true;
            _AbsolutionPosition = _position;
        }

        public virtual void Update()
        {
        }

        //public abstract void Input(PlayerIndex p_Index);

        public abstract void Draw(SpriteBatch p_SpriteBatch, GameTime p_Time);
    }

}
