
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

//using PPE.Core;
//using PPE.Input;

namespace Pauliver
{
    public class UIBaseMenu : UIButtonList<Callback>
    {
        List<UIElement> drawable;
        public UIBaseMenu(String BackgroundName, Vector2 Position)
            : base()
        {
            UIBackground _Background = new UIBackground(BackgroundName, Position);
            drawable = new List<UIElement>();
            drawable.Add(_Background);
        }
        public override void ProcessInput(Pauliver.PlayerIndex p_Index)
        {
            base.ProcessInput(p_Index);

#if WINDOWS
            if (PInput.Instance.Keyboard.Enter.SinglePress)
            {
                _Elements[base.selected].First.Invoke();
            }
#endif
            if (PInput.Instance.GamePad(p_Index).A.SinglePress)
            {
                _Elements[base.selected].First.Invoke();
            }
            if (PInput.Instance.GamePad(p_Index).Back.SinglePress)
            {
                Game1.Instance.CurrentMenu.Back();
            }
        }
        public virtual void AddUIElement(UIElement element)
        {
            drawable.Add(element);
        }
        public virtual void RemoveUIElement(UIElement element)
        {
            drawable.Remove(element);
        }
        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_Time)
        {
            for(int i = 0; i < drawable.Count; ++i)
            {
                drawable[i].Draw(p_SpriteBatch, p_Time);
            }
            base.Draw(p_SpriteBatch, p_Time);
        }
    }

}