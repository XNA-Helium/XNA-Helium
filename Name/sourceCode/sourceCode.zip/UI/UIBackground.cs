
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{
    public class UIBackground : UIImageElement
    {
        public UIBackground(String Imagename, Vector2 Position)
            : base(Imagename, Position)
        {
            DrawLevel = DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuBackground);
        }

    }
}