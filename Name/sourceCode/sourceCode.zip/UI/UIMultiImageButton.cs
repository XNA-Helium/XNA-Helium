
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

//using PPE.Core;
//using PPE.Input;

namespace Pauliver
{

    public class UIMultiImageButton : UIElement
    {
        protected int si;
        protected List<UIElement> _Elements;
        protected Vector2 position;
        public UIMultiImageButton(Vector2 BasePosition)
            : base(BasePosition)
        {
            si = 0;
            position = BasePosition;
            _Elements = new List<UIElement>();
        }
        //has a left button
        //has a right button
        //middle button rotates
        public virtual void Add(UIElement Element)
        {
            Element.Position = position;
            _Elements.Add(Element);
        }
        public virtual void AddImage(String Name)
        {
            _Elements.Add(new UIImageElement(Name, position));
        }
        public virtual void Setup(int visible)
        {
            if(visible > _Elements.Count)
            {
                visible = _Elements.Count - 1;
            }
            if(visible < 0)
            {
                visible = 0;
            }
            si = visible;
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_Time)
        {
            _Elements[Index].Draw(p_SpriteBatch, p_Time);
        }
        public int Index
        {
            get{
                return si;
            }
            set
            {
                si = value;
            }
        }
    }

}