#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{
    class MainMenu : BaseMenu
    {
        public MainMenu(bool firstrun)
            : base()
        {
            _menu = new UIBaseMenu(@"Content\Art/GUI/MainMenuBackground", Vector2.Zero);
            UIButton b = new UIButton(@"Content\Art/GUI/Local", new Vector2(20, 140));
            _menu.Add(LocalGame, b);
            b = new UIButton(@"Content\Art/GUI/Exit", new Vector2(20, 245));
            _menu.Add(Back, b);
            b = new UIButton(@"Content\Art/GUI/Credits", new Vector2(20, 210));
            _menu.Add(Options, b);
            if(firstrun)
            {
                b = new UIButton(@"Content\Art/GUI/Network", new Vector2(20, 175));
                _menu.Add(NetworkGame, b);
            }
            _menu.Setup();
        }

        public MainMenu():base()
        {
            _menu = new UIBaseMenu(@"Content\Art/GUI/MainMenuBackground", Vector2.Zero);
            UIButton b = new UIButton(@"Content\Art/GUI/Local", new Vector2(20, 140));
            _menu.Add(LocalGame, b);
            b = new UIButton(@"Content\Art/GUI/Exit", new Vector2(20, 245));
            _menu.Add(Back, b);
            b = new UIButton(@"Content\Art/GUI/Credits", new Vector2(20, 210));
            _menu.Add(Options, b);
            b = new UIButton(@"Content\Art/GUI/Network", new Vector2(20, 175));
            _menu.Add(NetworkGame, b);
            _menu.Setup();
        }

        public override void Update(GameTime p_Time)
        {
            _menu.Update();
            _menu.ProcessInput(PlayerIndex.One);
#if !ZUNE
            _menu.ProcessInput(PlayerIndex.Two);
            _menu.ProcessInput(PlayerIndex.Three);
            _menu.ProcessInput(PlayerIndex.Four);
#endif
        }

        public override void ProccessInput(PlayerIndex p_index)
        {
            _menu.ProcessInput(p_index);
        }

        public override void Draw(SpriteBatch p_spriteBatch, GameTime p_Time)
        {
            _menu.Draw(p_spriteBatch, p_Time);
        }


        protected void LocalGame()
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu(new PlayerSelection());
        }
        protected void NetworkGame()
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu(new NetworkGameMenu());
        }

        protected void Options()
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu(new OptionsMenu());
        }

        public override void Back()
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.Exit();
        }
    }
}