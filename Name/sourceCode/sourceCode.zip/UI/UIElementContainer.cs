
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{

    public class UIElementContainer<T> : UIElement
    {
        protected List<Pair<T, UIElement>> _Elements;

        public UIElementContainer()
            : base(Vector2.Zero)
        {
            _Elements = new List<Pair<T, UIElement>>();
        }

        public virtual void Remove(T value, UIElement Element)
        {
            Pair<T, UIElement> p = new Pair<T, UIElement>(value, Element);
            if (_Elements.Contains(p))
            {
                _Elements.Remove(p);
            }
        }
        public virtual void Add(T value, UIElement Element)
        {
            _Elements.Add(new Pair<T, UIElement>(value, Element));
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_Time)
        {
            foreach (Pair<T, UIElement> pairs in _Elements)
            {
                pairs.Second.Draw(p_SpriteBatch, p_Time);
            }
        }
    }

}