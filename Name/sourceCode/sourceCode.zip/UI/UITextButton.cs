
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{
    public class UITextButton : UIButton
    {
        UITextElement _Text;
        public UITextButton(String ImageName, SpriteFont font, Vector2 Position, Color color, String text)
            : base(ImageName, Position)
        {
            _Text = new UITextElement(Position, font, text, color);
        }
        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_Time)
        {
            base.Draw(p_SpriteBatch, p_Time);
            _Text.Draw(p_SpriteBatch, p_Time);
        }
    }
}