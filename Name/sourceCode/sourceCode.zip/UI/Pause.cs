#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{
    class Pause : BaseMenu
    {
        public Pause()
            : base()
        {
            _menu = new UIBaseMenu(@"Content\Art/GUI/Pause_overlay", new Vector2(20,20) );
            UIButton b = new UIButton(@"Content\Art/GUI/Resume", new Vector2(40, 100));
            _menu.Add(Back, b);
            _menu.Setup();
        }

        public override void Update(GameTime p_Time)
        {
            _menu.Update();
            _menu.ProcessInput(PlayerIndex.One);
#if !ZUNE
            _menu.ProcessInput(PlayerIndex.Two);
            _menu.ProcessInput(PlayerIndex.Three);
            _menu.ProcessInput(PlayerIndex.Four);
#endif
        }

        public override void ProccessInput(PlayerIndex p_index)
        {
            _menu.ProcessInput(p_index);
        }

        public override void Draw(SpriteBatch p_spriteBatch, GameTime p_Time)
        {
            _menu.Draw(p_spriteBatch, p_Time);
        }

        public override void Back()
        {
            Game1.Instance.PopTopMenu();
        }
    }
}