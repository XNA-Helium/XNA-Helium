#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{
    class Loading : BaseMenu
    {
        Texture2D[] loadingImages;
        int index = 0;
        int temp = 0;
        public Loading()
            : base()
        {
            loadingImages = new Texture2D[4];
            _menu = new UIBaseMenu(@"Content\Art/GUI/MainMenuBackground", Vector2.Zero);
            UIButton b = new UIButton(@"Content\Art/GUI/Local", new Vector2(400, 400));
            _menu.Add(Back, b);
            _menu.Setup();

            loadingImages[0] = PContentManager.Instance.GetObject<Texture2D>(@"Content\Art/GUI/loading1");
            loadingImages[1] = PContentManager.Instance.GetObject<Texture2D>(@"Content\Art/GUI/loading2");
            loadingImages[2] = PContentManager.Instance.GetObject<Texture2D>(@"Content\Art/GUI/loading3");
            loadingImages[3] = PContentManager.Instance.GetObject<Texture2D>(@"Content\Art/GUI/loading4");
        }

        public override void Update(GameTime p_Time)
        {
            _menu.Update();
            _menu.ProcessInput(PlayerIndex.One);
#if !ZUNE
            _menu.ProcessInput(PlayerIndex.Two);
            _menu.ProcessInput(PlayerIndex.Three);
            _menu.ProcessInput(PlayerIndex.Four);
#endif
        }

        public override void ProccessInput(PlayerIndex p_index)
        {
            _menu.ProcessInput(p_index);
        }

        public override void Draw(SpriteBatch p_spriteBatch, GameTime p_Time)
        {
            _menu.Draw(p_spriteBatch, p_Time);
            Incriment();
            p_spriteBatch.Draw(loadingImages[index], new Vector2(40, 100), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuButton));
        }

        public void Incriment()
        {
            if (++temp >= 4)
            {
                temp = 0;
                if (++index >= 4)
                {
                    index = 0;
                }
            }
        }

        public override void Back()
        {
        }
    }
}