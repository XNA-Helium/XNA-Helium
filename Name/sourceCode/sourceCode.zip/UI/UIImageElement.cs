#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion
//using PPE.Core;


namespace Pauliver
{

    public class UIImageElement : UIElement
    {
        Texture2D _image;
        protected float DrawLevel;
        public UIImageElement(String imageName, Vector2 Position)
            : base(Position)
        {
            DrawLevel = DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuButton);
            _image = Pauliver.PContentManager.Instance.GetObject<Texture2D>(imageName);
        }
        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_Time)
        {
            if (base.visible)
            {
                p_SpriteBatch.Draw(_image, base._AbsolutionPosition, null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLevel);
            }
        }
    }
   
}