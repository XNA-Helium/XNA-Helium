﻿
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    class Target : BaseMenu
    {
        protected float scale;
        
        public float Scale{
            get{
                return scale;
            }
            set{
                scale = value;
            }
        }
        
        public Target():base()
        {
            _menu = new UIBaseMenu(, new Vector2(0, 0));
        }
        public override void Draw(SpriteBatch p_spriteBatch, GameTime p_Time)
        {
            //throw new NotImplementedException();
        }
        public override void Update(GameTime p_Time)
        {
            //throw new NotImplementedException();
        }
        public override void ProccessInput(PlayerIndex p_index)
        {
            //throw new NotImplementedException();
        }
    }
}