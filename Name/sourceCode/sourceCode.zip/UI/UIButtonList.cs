
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

//using PPE.Core;
//using PPE.Input;

namespace Pauliver
{
    public class UIButtonList<T> : UIElementContainer<T>
    {
        protected int selected;
        public UIButtonList()
            : base()
        {
            selected = 0;
        }

        public void Setup()
        {
            foreach (Pair<T, UIElement> pairs in _Elements)
            {
                (pairs.Second as UIButton).Active = false;
                (pairs.Second as UIButton).Visible = true;
            }
            (_Elements[selected].Second as UIButton).Active = true;
        }

        public virtual void ProcessInput(Pauliver.PlayerIndex p_Index)
        {
            int oldindex = selected;
            int newindex = selected;
#if !ZUNE
            if (PInput.Instance.Keyboard.W.SinglePress)
            {
                if (++newindex == base._Elements.Count)
                {
                    newindex = 0;
                }
            }
#endif
            if (PInput.Instance.GamePad(p_Index).DPadUp.SinglePress)
            {
                if (++newindex == base._Elements.Count)
                {
                    newindex = 0;
                }
            }
#if !ZUNE
            if (PInput.Instance.Keyboard.S.SinglePress)
            {
                if (newindex == 0)
                {
                    newindex = _Elements.Count - 1;
                }
                else
                {
                    --newindex;
                }
            }
#endif
            if (PInput.Instance.GamePad(p_Index).DPadDown.SinglePress)
            {
                if (newindex == 0)
                {
                    newindex = _Elements.Count - 1;
                }
                else
                {
                    --newindex;
                }
            }
            if (newindex != selected)
            {
                (_Elements[oldindex].Second as UIButton).Active = false;
                (_Elements[newindex].Second as UIButton).Active = true;
                selected = newindex;
            }
        }

        public T GetCurrent()
        {
            return (_Elements[selected].First);
        }
        public int Index
        {
            get
            {
                return selected;
            }
        }
    }
}