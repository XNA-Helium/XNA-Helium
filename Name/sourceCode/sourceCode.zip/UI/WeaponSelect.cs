#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{

    public class AvailableWeaponList
    {
        public const int INFINITY = -1;

        // Actual Fields
        public int FlameThrower = 5;
        public int Rocket = -1;
        public int Cluster = -1;
        public int CarpetBomb = 4;
        public int Grenade = 1;
        public int LandMine = 2;
        public int JetPack = 6;
        public int SpiderMine = 3;
        

        public enum LauncherType
        {
            RocketLauncher = 0,
            FlameThrower = 1,
            ClusterLauncher = 2,
            NapalmLauncher = 3,
            NukeLauncher = 4,
            MineLauncher = 5,
            JetPack = 6,
            SpiderMineLauncher = 7
        }; 

        public int MapWeaponToSlot(WeaponObject wobject )
        {
            if (wobject is CarpetBombLauncher)
            {
                return 3;
            }
            if (wobject is ClusterLauncher)
            {
                return 2;
            }
            if (wobject is FlameThrower)
            {
                return 1;
            }
            if (wobject is GrenadeLauncher)
            {
                return 4;
            }
            if (wobject is JetPack)
            {
                return 6;
            }
            if (wobject is LandMineLauncher)
            {
                return 5;
            }
            if (wobject is RocketLauncher)
            {
                return 0;
            }
            if (wobject is SpiderMineLauncher)
            {
                return 7;
            }
            return -1;
        }

        public int GetAvailable(LauncherType type)
        {
            switch (type)
            {
                case LauncherType.RocketLauncher:
                    return Rocket;
                case LauncherType.FlameThrower:
                    return FlameThrower;
                case LauncherType.ClusterLauncher:
                    return Cluster;
                case LauncherType.NapalmLauncher:
                    return CarpetBomb;
                case LauncherType.NukeLauncher:
                    return Grenade;
                case LauncherType.MineLauncher:
                    return LandMine;
                case LauncherType.JetPack:
                    return JetPack;
                case LauncherType.SpiderMineLauncher:
                    return SpiderMine;
            }
            return 0;
        }

        public int GetAvailable(WeaponObject wobject)
        {
            if (wobject is CarpetBombLauncher)
            {
                return CarpetBomb;
            }
            if (wobject is ClusterLauncher)
            {
                return Cluster;
            }
            if (wobject is FlameThrower)
            {
                return FlameThrower;
            }
            if (wobject is GrenadeLauncher)
            {
                return Grenade;
            }
            if (wobject is JetPack)
            {
                return JetPack;
            }
            if (wobject is LandMineLauncher)
            {
                return LandMine;
            }
            if (wobject is RocketLauncher)
            {
                return Rocket;
            }
            if (wobject is SpiderMineLauncher)
            {
                return SpiderMine;
            }
            return 0;
        }
    }

    class WeaponSelectionScreen : BaseMenu
    {
        AvailableWeaponList weaponlist;
        PlayerObject _po;
        Texture2D WeaponMenuBack;
        //UITextElement _uit;
        public WeaponSelectionScreen(PlayerObject po) :base()
        {
            weaponlist = (Game1.Instance.GameManager as GameManagerTeamedInterface).CurrentUTP().AvailableWeapons;
            _po = po;
            _menu = new UIBaseMenu(@"Content\Art\GUI\Pick_Weapon",new Vector2(22,55));
            WeaponMenuBack = PContentManager.Instance.GetObject<Texture2D>(@"Content\Art/GUI/WeaponMenuBack");
            
            _menu.Add(SelectRocket, new UIButton(@"Content\Art\GUI\RocketLauncherLeft", @"Content\Art\GUI\RocketLauncherRight", new Vector2(56, 200)));
            _menu.Add(SelectFlameThrower, new UIButton(@"Content\Art\GUI\FlamethrowerActive", @"Content\Art\GUI\FlamethrowerInactive", new Vector2(120, 200)));
            _menu.Add(SelectCluster, new UIButton(@"Content\Art\GUI\ClusterLauncherLeft", @"Content\Art\GUI\ClusterLauncherRight", new Vector2(56, 165)));
            _menu.Add(SelectCarpetBomb, new UIButton(@"Content\Art\GUI\NapalmActive", @"Content\Art\GUI\NapalmInactive", new Vector2(120, 165)));
            _menu.Add(SelectGrenade, new UIButton(@"Content\Art\GUI\GrenadeLauncherLeft", @"Content\Art\GUI\GrenadeLauncherRight", new Vector2(56, 130)));
            _menu.Add(SelectLandMine, new UIButton(@"Content\Art\GUI\MineActive", @"Content\Art\GUI\MineInactive", new Vector2(120, 130)));
            _menu.Add(SelectJetPack, new UIButton(@"Content\Art\GUI\JetPackLeft", @"Content\Art\GUI\JetPackRight", new Vector2(56, 95)));
            _menu.Add(SelectSpiderMine, new UIButton(@"Content\Art\GUI\SpiderMineActive", @"Content\Art\GUI\SpiderMineInactive", new Vector2(120, 95)));
            
            _menu.Setup();
        }

        public override void  Draw(SpriteBatch p_spriteBatch, GameTime p_Time)
        {
            p_spriteBatch.Draw(WeaponMenuBack, new Vector2(51, 89), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuBackground));

            p_spriteBatch.Draw(PContentManager.Instance.GetObject<Texture2D>("" + weaponlist.FlameThrower), new Vector2(152, 200), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuButton));
            p_spriteBatch.Draw(PContentManager.Instance.GetObject<Texture2D>("" + weaponlist.Rocket), new Vector2(88, 200), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuButton));
            p_spriteBatch.Draw(PContentManager.Instance.GetObject<Texture2D>("" + weaponlist.Cluster), new Vector2(88, 165), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuButton));
            p_spriteBatch.Draw(PContentManager.Instance.GetObject<Texture2D>("" + weaponlist.CarpetBomb), new Vector2(152, 165), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuButton));
            p_spriteBatch.Draw(PContentManager.Instance.GetObject<Texture2D>("" + weaponlist.Grenade), new Vector2(88, 130), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuButton));
            p_spriteBatch.Draw(PContentManager.Instance.GetObject<Texture2D>("" + weaponlist.LandMine), new Vector2(152, 130), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuButton));
            p_spriteBatch.Draw(PContentManager.Instance.GetObject<Texture2D>("" + weaponlist.JetPack), new Vector2(88, 95), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuButton));
            p_spriteBatch.Draw(PContentManager.Instance.GetObject<Texture2D>("" + weaponlist.SpiderMine), new Vector2(152, 95), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuButton));

            _menu.Draw(p_spriteBatch,p_Time);
        }
        public override void  Update(GameTime p_Time)
        {
            _menu.Update();
        }
        public override void ProccessInput(PlayerIndex p_index)
        {
            _menu.ProcessInput(p_index);
        }

        public void SelectLandMine()
        {
            if (weaponlist.LandMine != 0)
            {
                Game1.Instance.PopTopMenu();
                bool canshoot = ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot;
                _po[ComponentType.Holder_Weapon] = new Holder_Weapon(new LandMineLauncher(_po));
                ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot = canshoot;
            }
        }

        public void SelectFlameThrower()
        {
            if (weaponlist.FlameThrower != 0)
            {
                Game1.Instance.PopTopMenu();
                bool canshoot = ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot;
                _po[ComponentType.Holder_Weapon] = new Holder_Weapon(new FlameThrower(_po));
                ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot = canshoot;
            }
        }

        public void SelectCarpetBomb()
        {
            if (weaponlist.CarpetBomb != 0)
            {
                Game1.Instance.PopTopMenu();
                bool canshoot = ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot;
                _po[ComponentType.Holder_Weapon] = new Holder_Weapon(new CarpetBombLauncher(_po));
                ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot = canshoot;
            }
        }

        public void SelectSpiderMine()
        {
            if (weaponlist.SpiderMine != 0)
            {
                Game1.Instance.PopTopMenu();
                bool canshoot = ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot;
                _po[ComponentType.Holder_Weapon] = new Holder_Weapon(new SpiderMineLauncher(_po));
                ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot = canshoot;
            }
        }

        public void SelectRocket()
        {
            if (weaponlist.Rocket != 0)
            {
                Game1.Instance.PopTopMenu();
                bool canshoot = ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot;
                _po[ComponentType.Holder_Weapon] = new Holder_Weapon(new RocketLauncher(_po));
                ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot = canshoot;
            }
        }

        public void SelectCluster()
        {
            if (weaponlist.Cluster != 0)
            {
                Game1.Instance.PopTopMenu();
                bool canshoot = ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot;
                _po[ComponentType.Holder_Weapon] = new Holder_Weapon(new ClusterLauncher(_po));
                ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot = canshoot;
            }
        }

        public void SelectGrenade()
        {
            if (weaponlist.Grenade != 0)
            {
                Game1.Instance.PopTopMenu();
                bool canshoot = ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot;
                _po[ComponentType.Holder_Weapon] = new Holder_Weapon(new GrenadeLauncher(_po));
                ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot = canshoot;
            }
        }

        public void SelectJetPack()
        {
            if (weaponlist.JetPack != 0)
            {
                Game1.Instance.PopTopMenu();
                bool canshoot = ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot;
                _po[ComponentType.Holder_Weapon] = new Holder_Weapon(new JetPack(_po));
                ((_po[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon[ComponentType.Input_Shoot] as Input_Shoot).CanShoot = canshoot;
            }
        }
        
        public override void Back()
        {
            Game1.Instance.PopTopMenu();
        }

    }
}