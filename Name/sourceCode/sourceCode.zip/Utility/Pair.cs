#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{

    public class Pair<T, U>
    {
        T _first;
        U _Second;

        public Pair(T p_first, U p_second)
        {
            _first = p_first;
            _Second = p_second;
        }

        public T First
        {
            get
            {
                return _first;
            }
            set
            {
                _first = value;
            }
        }

        public U Second
        {
            get
            {
                return _Second;
            }
            set
            {
                _Second = value;
            }
        }
    }


    public class Triplet<T, U, V>
    {
        T _first;
        U _Second;
        V _Third;
        public Triplet(T p_first, U p_second,V p_third)
        {
            _first = p_first;
            _Second = p_second;
            _Third = p_third;
        }

        public T First
        {
            get
            {
                return _first;
            }
            set
            {
                _first = value;
            }
        }

        public U Second
        {
            get
            {
                return _Second;
            }
            set
            {
                _Second = value;
            }
        }

        public V Third
        {
            get
            {
                return _Third;
            }
            set
            {
                _Third = value;
            }
        }
    }

}
