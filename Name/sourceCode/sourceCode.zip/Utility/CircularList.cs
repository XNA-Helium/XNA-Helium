

#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{
    class CircularList <T>
    {
        List<T> _List;
        int index;
        public CircularList()
        {
            _List = new List<T>();
            index = 0;
        }

        public void Add(T Item)
        {
            _List.Add(Item);
        }

        public void Remove(T Object)
        {
            if (_List.IndexOf(Object) <= index)
            {
                --index;
            }
            _List.Remove(Object);
        }

        public T Current
        {
            get
            {
                if(index >=_List.Count )
                {
                    return _List[index];
                }
                else
                {
                    return default(T);
                }
            }
        }

        public T Previous
        {
            get
            {
                if (index == 0)
                {
                    index = _List.Count - 1;
                    return _List[index];
                }
                else
                {
                    return _List[--index];
                }
            }
        }

        public T Next
        {
            get
            {
                if (++index >= _List.Count)
                {
                    index = 0;
                }
                return _List[index];
            }
        }

        public int Count
        {
            get
            {
                return _List.Count;
            }
        }
    }
}
