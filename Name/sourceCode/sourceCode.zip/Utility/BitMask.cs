
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    // ToDo
    // turn this into a REAL bitmask [using bits]
    class BitMask
    {
        private List<bool> _items;
        public BitMask(int size)
        {
            _items = new List<bool>(_items);
            for (int i = 0; i < size; ++i)
            {
                _items[i] = false;
            }
        }
        public void Reset()
        {
            for (int i = 0; i < _items.Count; ++i)
            {
                _items[i] = false;
            }
        }
        public void SetBit(int Bit)
        {
            SetBit(Bit, true);
        }
        public void SetBit(int Bit, bool value)
        {
            _items[Bit] = value;
        }
        public void FlipBit(int Bit)
        {
            _items[Bit] = !_items[Bit];
        }
        public bool IsSet(int Bit)
        {
            return _items[Bit];
        }
        public bool AnyChanges()
        {
            for (int i = 0; i <= _items.Count; ++i)
            {
                if (_items[i])
                {
                    return _items[i];
                }
            }
            return false;
        }
    }
}
