
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    class Cloud : GameObject
    {
        private int interval = 30;
        private int count;
        private CalcNextPosition c;
        public delegate Vector2 CalcNextPosition(Vector2 current);
        public Cloud(String ImageName, float scale, CalcNextPosition thingy):base()
        {
            count = 0;
            c = thingy;
            base.AddComponent(new Game_Position());
            base.AddComponent(new Game_Scale(scale));
            base.AddComponent(new Game_Rotation(0.0f));
            base.AddComponent(new Game_Velocity(0.0f, 0.0f));
            base.AddComponent(new DrawLayer(DrawLayer.LayerDepth.FarFarBackground));
            base.AddComponent(new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(ImageName)));
        }
        public Cloud(String ImageName, float scale, CalcNextPosition thingy, int pinterval)
            : base()
        {
            interval = pinterval;
            count = 0;
            c = thingy;
            base.AddComponent(new Game_Position());
            base.AddComponent(new Game_Scale(scale));
            base.AddComponent(new Game_Rotation(0.0f));
            base.AddComponent(new Game_Velocity(0.0f, 0.0f));
            base.AddComponent(new DrawLayer(DrawLayer.LayerDepth.FarFarBackground));
            base.AddComponent(new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(ImageName)));
        }
        public override void Update(GameTime p_time)
        {
            if(++count == interval)
            {
                Vector2 Position = (this[ComponentType.Game_Position] as Game_Position).Position;
                Position = c(Position);
                (this[ComponentType.Game_Position] as Game_Position).Position = Position;
                count = 0;
            }
            base.Update(p_time);
        }
    }
}
