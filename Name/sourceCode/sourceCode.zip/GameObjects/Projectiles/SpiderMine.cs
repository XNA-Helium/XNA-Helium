
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    class SpiderMine : ProjectileObject
    {
        public SpiderMine(Facing direction)
            : base(direction)
        {
            collided = false;
            Drawable_Sprite_Static dss = null;
            dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/SpiderMine"));//@@ change me
            base.AddComponent(dss);
            (this[ComponentType.Collidable] as Collidable).CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/WeaponCollision"));//@@ change me
        }

        public override ProjectileObject ReturnNew()
        {
            return new SpiderMine((this[ComponentType.Game_Facing] as Game_Facing).Facing);
        }

        public override void OnCollision(GameObject rhs)
        {
            if (!collided)
            {
                if (rhs == this)
                {
                    base.RemoveComponent(ComponentType.Drawable_Sprite_Static);
                    Facing f = (this[ComponentType.Game_Facing] as Game_Facing).Facing;
                    int multiplier = 1;
                    if(f == Facing.Left)
                    {
                        multiplier = -1;
                    }
                    (this[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(multiplier * 1,1);
                    Drawable_Sprite_Animated dsa = new Drawable_Sprite_Animated();
                    dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/SpiderMineRight"), new Rectangle(0, 0, 16, 32), "SMR", 2);
                    dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/SpiderMineLeft"), new Rectangle(0, 0, 16, 32), "SML", 2);
                    if( (base[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Left)
                    {
                        dsa.SetCurrentAnimation("SML");
                    }else{
                        dsa.SetCurrentAnimation("SMR");
                    }
                    base.AddComponent(dsa);
                    collided = true;
                }
            }
            else if(rhs != this && (rhs is ProjectileObject || rhs is DefaultExplosion || rhs is PlayerObject || rhs is LandMine) )
            {
                if (rhs[ComponentType.Game_Hitpoint] != null)
                {
                    (rhs[ComponentType.Game_Hitpoint] as Game_Hitpoints).Hitpoints -= 20;
                }
                Vector2 position = (this[ComponentType.Game_Position] as Game_Position).Position;
                WeaponExplosion we = new WeaponExplosion(new Vector2(position.X, position.Y));
                Game1.Instance.GameManager.AddToSceneGraphLater(we);
                base.OnCollision(rhs);
                Game1.Instance.GameManager.RemoveFromSceneGraph(this);
            }
            else if(rhs == this)
            {
                if (collided)
                {
                    int velocity = 0;
                    Facing facing = (base[ComponentType.Game_Facing] as Game_Facing).Facing;
                    if (facing == Facing.Left)
                    {
                        velocity = -1;
                    }
                    else if (facing == Facing.Right)
                    {
                        velocity = 1;
                    }

                    (this[ComponentType.Game_Velocity] as Game_Velocity).Velocity += new Vector2(velocity, 0);
                }
            }
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            if (collided)
            {
                base.Draw(p_SpriteBatch, p_GameTime, p_Screen);
            }
            else
            {
                float rotation = (this[ComponentType.Game_Rotation] as Game_Rotation).Rotation;
                Vector2 speed = (this[ComponentType.Game_Velocity] as Game_Velocity).Velocity;
                (this[ComponentType.Game_Rotation] as Game_Rotation).Rotation = (float)Math.Atan(speed.Y / speed.X);
                base.Draw(p_SpriteBatch, p_GameTime, p_Screen);
                (this[ComponentType.Game_Rotation] as Game_Rotation).Rotation = rotation;
            }
        }
    }
}
