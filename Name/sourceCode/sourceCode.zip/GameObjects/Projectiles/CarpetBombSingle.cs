
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    class CarpetBombSingle : ProjectileObject
    {
        public CarpetBombSingle(Facing direction)
            : base(direction)
        {
            Drawable_Sprite_Static dss = null;
            dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/NapalmPiece"));
            base.AddComponent(dss);
            (this[ComponentType.Collidable] as Collidable).CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/WeaponCollision"));
        }

        public override void OnCollision(GameObject rhs)
        {
            if (rhs == this)
            {
                //collided with terrain
                Vector2 position = (this[ComponentType.Game_Position] as Game_Position).Position;
                Napalm we = new Napalm(new Vector2(position.X, position.Y));
                Game1.Instance.GameManager.AddToSceneGraphLater(we);
                base.OnCollision(rhs);
                Game1.Instance.GameManager.RemoveFromSceneGraph(this);
            }
            /* else if (rhs[ComponentType.Game_Hitpoint] != null)
            {
                //collided with terrain
                Vector2 position = (this[ComponentType.Game_Position] as Game_Position).Position;
                SmallExplosion we = new SmallExplosion(new Vector2(position.X, position.Y));
                Game1.Instance.GameManager.AddToSceneGraphLater(we);
                base.OnCollision(rhs);
                Game1.Instance.GameManager.RemoveFromSceneGraph(this);
            }*/
        }

        public override ProjectileObject ReturnNew()
        {
            return new CarpetBombSingle((this[ComponentType.Game_Facing] as Game_Facing).Facing);
        }

    }
}
