
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    class GrenadeCluster : ProjectileObject
    {
        public GrenadeCluster(Facing direction)
            : base(direction)
        {
            Drawable_Sprite_Static dss = null;
            dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/ClusterGrenade"));
            base.AddComponent(dss);
            (this[ComponentType.Collidable] as Collidable).CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/WeaponCollision"));
        }
        public override void OnCollision(GameObject rhs)
        {
            if (!collided)
            {
                Vector2 position = (this[ComponentType.Game_Position] as Game_Position).Position;
                GrenadeSingle wem = new GrenadeSingle(Facing.Right);
                //GrenadeSingle wer = new GrenadeSingle(Facing.Right);
                //GrenadeSingle wel = new GrenadeSingle(Facing.Left);
                GrenadeSingle wer2 = new GrenadeSingle(Facing.Right);
                GrenadeSingle wel2 = new GrenadeSingle(Facing.Left);

                Random rand1 = new Random();
                Random rand2 = new Random();
                
                (wem[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(0.0f, -10.0f);
                if (NetworkManager.IsUsed)
                {
                    //(wer[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(0.5f, -0.5f);
                    //(wel[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(-0.5f, -0.5f);
                    (wer2[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(0.5f, -0.5f);
                    (wel2[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(-0.5f, -0.5f);
                }
                else
                {
                    //(wer[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(0.6f, -7.0f);
                    //(wel[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(-0.6f, -7.0f);
                    (wer2[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(0.3f, -5.0f);
                    (wel2[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(-0.3f, -5.0f);
                    (wem[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(0.0f, -7.0f);
                }
                (wel2[ComponentType.Game_Position] as Game_Position).Position = new Vector2(position.X - 14, position.Y - 14);
                //(wel[ComponentType.Game_Position] as Game_Position).Position = new Vector2(position.X - 12, position.Y - 10);
                (wem[ComponentType.Game_Position] as Game_Position).Position = new Vector2(position.X, position.Y - 3);
                (wer2[ComponentType.Game_Position] as Game_Position).Position = new Vector2(position.X + 14, position.Y - 14);
                //(wer[ComponentType.Game_Position] as Game_Position).Position = new Vector2(position.X + 12, position.Y - 10);
                //Game1.Instance.GameManager.AddToSceneGraphLater(wel);
                //Game1.Instance.GameManager.AddToSceneGraphLater(wer);
                Game1.Instance.GameManager.AddToSceneGraphLater(wem);
                Game1.Instance.GameManager.AddToSceneGraphLater(wel2);
                Game1.Instance.GameManager.AddToSceneGraphLater(wer2);
                if (rhs == this)
                {
                    //collided with terrain
                }
                base.OnCollision(rhs);
                Game1.Instance.GameManager.RemoveFromSceneGraph(this);
            }
        }
        public override ProjectileObject ReturnNew()
        {
            return new GrenadeCluster((this[ComponentType.Game_Facing] as Game_Facing).Facing);
        }
    }
}
