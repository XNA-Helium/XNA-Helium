
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    class CarpetBomb : ProjectileObject
    {
        public CarpetBomb(Facing direction)
            : base(direction)
        {
            Drawable_Sprite_Static dss = null;
            dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/Napalm"));
            base.AddComponent(dss);
            (this[ComponentType.Collidable] as Collidable).CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/WeaponCollision"));
        }

        public override void Update(GameTime p_time)
        {
            base.Update(p_time);
            Vector2 position = (base[ComponentType.Game_Position] as Game_Position).Position;
            if ((position.Y) >= (Game1.Instance.GameManager.Level as DynamicLevel)[(int)position.X] - 32)
            {
                SpawnCarpetBombs();
                Game1.Instance.GameManager.RemoveFromSceneGraph(this);
            }
        }

        public override void OnCollision(GameObject rhs)
        {
            if (!collided)
            {
                SpawnCarpetBombs();
                if (rhs == this)
                {
                    //collided with terrain
                }
                base.OnCollision(rhs);
                Game1.Instance.GameManager.RemoveFromSceneGraph(this);
            }
        }

        public void SpawnCarpetBombs()
        {
            Vector2 position = (this[ComponentType.Game_Position] as Game_Position).Position;


            int multiplier = 0;

            Facing facing = (this[ComponentType.Game_Facing] as Game_Facing).Facing;
            if (facing == Facing.Left)
            {
                multiplier = -1;
            }
            else if (facing == Facing.Right)
            {
                multiplier = 1;
            }
            CarpetBombSingle wel = new CarpetBombSingle(facing);
            CarpetBombSingle wem = new CarpetBombSingle(facing);
            CarpetBombSingle wer = new CarpetBombSingle(facing);
            //CarpetBombSingle www = new CarpetBombSingle(facing);

            (wem[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(0.0f * multiplier, -1.0f);
            (wer[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(2.0f * multiplier, -1.0f);
            (wel[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(4.0f * multiplier, -1.0f);
            ///(www[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2(6.0f * multiplier, -1.0f);
            (wel[ComponentType.Game_Position] as Game_Position).Position = new Vector2(position.X, position.Y - 0);
            (wem[ComponentType.Game_Position] as Game_Position).Position = new Vector2(position.X, position.Y - 0);
            (wer[ComponentType.Game_Position] as Game_Position).Position = new Vector2(position.X, position.Y - 0);
            ///(www[ComponentType.Game_Position] as Game_Position).Position = new Vector2(position.X, position.Y - 0);
            Game1.Instance.GameManager.AddToSceneGraphLater(wel);
            Game1.Instance.GameManager.AddToSceneGraphLater(wer);
            Game1.Instance.GameManager.AddToSceneGraphLater(wem);
            ///Game1.Instance.GameManager.AddToSceneGraphLater(www);
        }

        public override ProjectileObject ReturnNew()
        {
            return new CarpetBomb((this[ComponentType.Game_Facing] as Game_Facing).Facing);
        }
    }
}
