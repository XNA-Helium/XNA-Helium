
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    class FlameCollision
    {
        public FlameCollision()
        {

        }
    }

    class Flame : ProjectileObject
    {
        GameObject FlameCollision;
        int framesleft = 30;
        WeaponObject weaponObject;
        public Flame(Facing direction,WeaponObject weapon)
            : base(direction)
        {
            {
                float angle = (weapon[ComponentType.Game_Rotation] as Game_Rotation).Rotation;
                Vector2 offset = Vector2.Zero;
                if ((weapon[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Right)
                {
                    offset = new Vector2((float)55 * (float)Math.Cos(angle), (float)55 * (float)Math.Sin(angle));
                }
                if ((weapon[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Left)
                {
                    offset = new Vector2((float)-55 * (float)Math.Cos(angle), (float)-55 * (float)Math.Sin(angle));
                }

                Vector2 StartPosition = (weapon[ComponentType.Game_Position] as Game_Position).Position + offset;
                FlameCollision = new FlameExplosion(StartPosition);
                Game1.Instance.GameManager.AddToSceneGraph(FlameCollision);
            }

            weaponObject = weapon;
            base.RemoveComponent(ComponentType.Affectable_Gravity);
            base.RemoveComponent(ComponentType.Affectable_Wind);
            base.RemoveComponent(ComponentType.Drawable_Sprite_Static);
            Drawable_Sprite_Animated dsa = null;
            dsa = new Drawable_Sprite_Animated();
            dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/FlameLeft"), new Rectangle(0, 0, 96, 32), "FlameLeft", 2);
            dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/FlameRight"), new Rectangle(0, 0, 96, 32), "FlameRight", 2);
            if (direction == Facing.Left)
            {
                dsa.SetCurrentAnimation("FlameLeft");
            }
            else
            {
                dsa.SetCurrentAnimation("FlameRight");
            }
            base.AddComponent(dsa);
            (this[ComponentType.Collidable] as Collidable).CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/WeaponCollision"));//@@ change me
        }

        public Flame(Facing direction)
            : base(direction)
        {
            base.RemoveComponent(ComponentType.Affectable_Gravity);
            base.RemoveComponent(ComponentType.Affectable_Wind);
            base.RemoveComponent(ComponentType.Drawable_Sprite_Static);
            Drawable_Sprite_Animated dsa = null;
            dsa = new Drawable_Sprite_Animated();
            dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/FlameLeft"), new Rectangle(0, 0, 96, 32), "FlameLeft", 3);
            dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/FlameRight"), new Rectangle(0, 0, 96, 32), "FlameRight", 3);
            if (direction == Facing.Left)
            {
                dsa.SetCurrentAnimation("FlameLeft");
            }
            else
            {
                dsa.SetCurrentAnimation("FlameRight");
            }
            base.AddComponent(dsa);
            (this[ComponentType.Collidable] as Collidable).CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/WeaponCollision"));//@@ change me
        }

        public override ProjectileObject ReturnNew()
        {
            return new Flame((this[ComponentType.Game_Facing] as Game_Facing).Facing);
        }

        public override void Update(GameTime p_time)
        {
            --framesleft;
            base.Update(p_time);
            if(framesleft <= 0)
            {
                Game1.Instance.GameManager.RemoveFromSceneGraph(this);
                Game1.Instance.GameManager.RemoveFromSceneGraph(FlameCollision);
            }
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            if(weaponObject != null)
            {
                weaponObject.Draw(p_SpriteBatch, p_GameTime, p_Screen);
            }
            base.Draw(p_SpriteBatch, p_GameTime, p_Screen);
        }
    }
}
