
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    class Grenade : ProjectileObject
    {
        public Grenade(Facing direction)
            : base(direction)
        {
            Drawable_Sprite_Static dss = null;
            dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/Grenade"));
            base.AddComponent(dss);
            (this[ComponentType.Collidable] as Collidable).CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/WeaponCollision"));
        }

        public override ProjectileObject ReturnNew()
        {
            return new Grenade((this[ComponentType.Game_Facing] as Game_Facing).Facing);
        }

        public override void OnCollision(GameObject rhs)
        {
            if (!collided)
            {
                Vector2 position = (this[ComponentType.Game_Position] as Game_Position).Position;
                LargeExplosion we = new LargeExplosion(new Vector2(position.X, position.Y));
                Game1.Instance.GameManager.AddToSceneGraphLater(we);
                if (rhs == this)
                {
                    //collided with terrain
                }
                base.OnCollision(rhs);
                Game1.Instance.GameManager.RemoveFromSceneGraph(this);
            }
        }
        public override void Update(GameTime p_time)
        {
            base.Update(p_time);
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            float rotation = (this[ComponentType.Game_Rotation] as Game_Rotation).Rotation;
            Vector2 speed = (this[ComponentType.Game_Velocity] as Game_Velocity).Velocity;
            (this[ComponentType.Game_Rotation] as Game_Rotation).Rotation = (float)Math.Atan(speed.Y / speed.X );
            base.Draw(p_SpriteBatch, p_GameTime, p_Screen);
            (this[ComponentType.Game_Rotation] as Game_Rotation).Rotation = rotation;
        }
    }
}
