
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    class LandMine : ProjectileObject
    {
        public LandMine(Facing direction)
            : base(direction)
        {
            Drawable_Sprite_Static dss = null;
            dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/Mine"));//@@ change me
            base.AddComponent(dss);
            base.AddComponent(new Settled_Ground());
            (this[ComponentType.Collidable] as Collidable).CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/WeaponCollision"));//@@ change me
        }

        public override ProjectileObject ReturnNew()
        {
            return new LandMine((this[ComponentType.Game_Facing] as Game_Facing).Facing);
        }

        public override void OnCollision(GameObject rhs)
        {
            if (!collided)
            {
                if (rhs == this)
                {
                    collided = true;
                    (this[ComponentType.Settled_Ground] as Settled_Ground).Settled = true;
                    Vector2 position = (this[ComponentType.Game_Position] as Game_Position).Position;
                    Collidable c = this[ComponentType.Collidable] as Collidable;
                    position.Y = ((Game1.Instance.GameManager.Level as DynamicLevel)[(int)position.X]) + (0.5f * c.Height);
                    (this[ComponentType.Game_Position] as Game_Position).Position = position;
                }
            }
            else if (rhs != this && (rhs is ProjectileObject || rhs is DefaultExplosion || rhs is PlayerObject || rhs is SpiderMine))
            {
                Vector2 position = (this[ComponentType.Game_Position] as Game_Position).Position;
                MineExplosion we = new MineExplosion(new Vector2(position.X, position.Y));
                Game1.Instance.GameManager.AddToSceneGraphLater(we);
                base.OnCollision(rhs);
                Game1.Instance.GameManager.RemoveFromSceneGraph(this);
            }
        }
        public override void Update(GameTime p_time)
        {
            if (collided)
            {
                // Don't update base 
                // because we don't want to focus 
                // on this after it hits the ground
                foreach (Component gameComponent in _ComponentCollection.Values)
                {
                    gameComponent.Update(p_time);
                }
            }
            else
            {
                base.Update(p_time);
            }
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            if (collided)
            {
                base.Draw(p_SpriteBatch, p_GameTime, p_Screen);
            }
            else
            {
                float rotation = (this[ComponentType.Game_Rotation] as Game_Rotation).Rotation;
                Vector2 speed = (this[ComponentType.Game_Velocity] as Game_Velocity).Velocity;
                (this[ComponentType.Game_Rotation] as Game_Rotation).Rotation = (float)Math.Atan(speed.Y / speed.X);
                base.Draw(p_SpriteBatch, p_GameTime, p_Screen);
                (this[ComponentType.Game_Rotation] as Game_Rotation).Rotation = rotation;
            }
        }
    }
}
