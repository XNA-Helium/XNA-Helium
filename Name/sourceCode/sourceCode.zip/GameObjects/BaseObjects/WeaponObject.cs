
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    public abstract class WeaponObject : GameObject
    {

        protected LaunchingRod rod;
        public LaunchingRod Rod
        {
            get
            {
                return rod;
            }
            set
            {
                rod = value;
            }
        }

        protected bool hasrod;
        public bool HasRod
        {
            get
            {
                return hasrod;
            }
        }
        private PlayerObject _PO;
        public PlayerObject Player
        {
            get
            {
                return _PO;
            }
        }
        public WeaponObject(PlayerObject _po)
        {
            hasrod = true;
            _PO = _po;
            Facing facing = (_PO[ComponentType.Game_Facing] as Game_Facing).Facing;
            Game_Position gp = new Game_Position();
            Game_Velocity gv = new Game_Velocity();
            Game_Position_Relative gpr = new Game_Position_Relative(_po);
            Game_Rotation gr = new Game_Rotation(0.0f);
            Game_Facing gf = new Game_Facing((_PO[ComponentType.Game_Facing] as Game_Facing).Facing);
            base.AddComponent(gf);
            base.AddComponent(gv);
            base.AddComponent(gr);
            base.AddComponent(gp);
            base.AddComponent(gpr);
            AddComponent(new DrawLayer(DrawLayer.LayerDepth.Weapons));
            
#if XBOX 
            Input_GamePad igp = new Input_GamePad();
            base.AddComponent(igp);
#elif ZUNE
            Input_GamePad igp = new Input_GamePad();
            base.AddComponent(igp);
#elif WINDOWS
                Input_Keyboard ikb = new Input_Keyboard();
                base.AddComponent(ikb);
#else
                Input_GamePad igp = new Input_GamePad();
                base.AddComponent(igp);
            }
#endif
            base.AddComponent(new Input_Shoot());
        }

        public abstract void SetFacing(Facing facing);

        public abstract ProjectileObject Fire(float Velocity);
    }

}
