
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    public abstract class ProjectileObject : GameObject
    {
        protected bool collided;
        public ProjectileObject(Facing direction):base()
        {
            collided = false;
            Game_Facing gf = new Game_Facing(direction);
            base.AddComponent(gf);
            Drawable_Sprite_Static dss = null;
            if (direction == Facing.Left)
            {
                dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/RocketLeft"));
            }
            if (direction == Facing.Right)
            {
                dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/RocketRight"));
            }
            Game_Position gp = new Game_Position();
            Game_Rotation gr = new Game_Rotation(0.0f);
            Game_Velocity gv = new Game_Velocity();
            //Game_Velocity_Limiting gvl = new Game_Velocity_Limiting(new Vector2(0.0f,9.0f));
            Type_Weapon tw = new Type_Weapon();
            base.AddComponent(tw);
            Collidable_Animal ca = new Collidable_Animal();
            base.AddComponent(ca);
            Collidable_Terrain ct = new Collidable_Terrain();
            base.AddComponent(ct);
            Collidable c = new Collidable();
            CollisionCallback cc = new CollisionCallback(OnCollision);
            base.AddComponent(c);
            base.AddComponent(cc);
            base.AddComponent(gr);
            base.AddComponent(dss);
            base.AddComponent(gp);
            base.AddComponent(gr);
            base.AddComponent(gv);
            //base.AddComponent(gvl);


            Affectable_Gravity ag = new Affectable_Gravity();
            Affectable_Wind aw = new Affectable_Wind();
            base.AddComponent(ag);
            base.AddComponent(aw);
            c.CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/WeaponCollision")); 
            DrawLayer d = new DrawLayer(DrawLayer.LayerDepth.Projectiles);
            base.AddComponent(d);
        }

        public abstract ProjectileObject ReturnNew();

        public virtual void OnCollision(GameObject rhs)
        {
            if(!collided)
            {
                collided = true;
                //set off explosion
            }
        }
        public override void Update(GameTime p_time)
        {
            base.Update(p_time);
            Game1.Instance.CenterOn((this[ComponentType.Game_Position] as Game_Position).Position);
        }
    }

}
