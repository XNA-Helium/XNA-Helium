
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    class FlameThrower : WeaponObject
    {
        Vector2 Offset = new Vector2(0, -35);
        public FlameThrower(PlayerObject _po)
            : base(_po)
        {
            (this[ComponentType.Game_Position_Relative] as Game_Position_Relative).Offset = Offset;

            Holder_Projectile hp = new Holder_Projectile(new Rocket((_po[ComponentType.Game_Facing] as Game_Facing).Facing));
            base.AddComponent(hp);

            Drawable_Sprite_Static dss = null;
            if ((_po[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Left)
            {
                dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/FlamethrowerLeft")); 
            }
            if ((_po[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Right)
            {
                dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/FlamethrowerRight")); 
            }
            base.AddComponent(dss);
        }

        public override ProjectileObject Fire(float Velocity)
        {
            AvailableWeaponList weaponlist = (Game1.Instance.GameManager as GameManagerTeamedInterface).CurrentUTP().AvailableWeapons;
            if (weaponlist.FlameThrower != AvailableWeaponList.INFINITY)
            {
                weaponlist.FlameThrower -= 1;
            }
            float angle = (this[ComponentType.Game_Rotation] as Game_Rotation).Rotation;
            Vector2 offset = Vector2.Zero;
            if ((this[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Right)
            {
                offset = new Vector2((float)32 * (float)Math.Cos(angle), (float)32 * (float)Math.Sin(angle));
            }
            if ((this[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Left)
            {
                offset = new Vector2((float)-32 * (float)Math.Cos(angle), (float)-32 * (float)Math.Sin(angle));
            }

            Vector2 StartPosition = (this[ComponentType.Game_Position] as Game_Position).Position + offset;
            Flame rocket = new Flame((this[ComponentType.Game_Facing] as Game_Facing).Facing, this);
            (rocket[ComponentType.Game_Position] as Game_Position).Position = StartPosition;
           
            (rocket[ComponentType.Game_Rotation] as Game_Rotation).Rotation = angle;
            Game1.Instance.GameManager.AddToSceneGraph(rocket);
            return rocket;
        }

        public override void SetFacing(Facing facing)
        {
            Drawable_Sprite_Static dss = null;
            if (facing == Facing.Left)
            {
                dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/FlamethrowerLeft"));
            }
            if (facing == Facing.Right)
            {
                dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/FlamethrowerRight"));
            }
            (this[ComponentType.Game_Facing] as Game_Facing).Facing = facing;
            base.AddComponent(dss);
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            // if this objects input component is active then draw
            // otherwise do not draw
            base.Draw(p_SpriteBatch, p_GameTime, p_Screen);
        }

        public override void Update(GameTime p_time)
        {
            // if this objects input component is active then update
            // otherwise do not update        
            base.Update(p_time);
        }
    }
}
