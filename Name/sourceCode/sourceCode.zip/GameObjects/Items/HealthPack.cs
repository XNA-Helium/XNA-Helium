#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{
    class HealthPack : GameObject
    {
        int _Hitpoints;
        bool Used;
        public HealthPack(int points,Vector2 Position):base()
        {
            Used = false;
            _Hitpoints = points;
            Affectable_Gravity ag = new Affectable_Gravity();
            base.AddComponent(ag);
            //Game_Scale gs = new Game_Scale();
            // base.AddComponent(gs);
            Game_Rotation gr = new Game_Rotation();
            base.AddComponent(gr);
            Game_Position gp = new Game_Position(Position);
            base.AddComponent(gp);
            Drawable_Sprite_Static dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/HealthPack"));
            base.AddComponent(dss);
            Type_Weapon tw = new Type_Weapon();
            base.AddComponent(tw);
            Collidable_Animal ca = new Collidable_Animal();
            Collidable_Terrain ct = new Collidable_Terrain();
            base.AddComponent(ct);
            base.AddComponent(ca);
            Collidable c = new Collidable();
            base.AddComponent(c);
            Game_Velocity gv = new Game_Velocity();
            base.AddComponent(gv);
            (this[ComponentType.Collidable] as Collidable).CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/HealthPack"));
        
            _Hitpoints = points;
            CollisionCallback cb = new CollisionCallback(Callback);
            base.AddComponent(cb);
            Settled_Ground sg = new Settled_Ground();
            base.AddComponent(sg);
            AddComponent(new DrawLayer(DrawLayer.LayerDepth.HealthPacks));
            
        }

        public override void Update(GameTime p_time)
        {
            base.Update(p_time);
            if((this[ComponentType.Collidable] as Collidable).Moving)
            {
                Game1.Instance.CenterOn((this[ComponentType.Game_Position] as Game_Position).Position);
            }
        }

        public void Callback(GameObject Collider)
        {
            if (!Used)
            {
                if (Collider[ComponentType.Collidable] != null)
                {
                    if (Collider[ComponentType.Game_Hitpoint] != null)
                    {
                        (Collider[ComponentType.Game_Hitpoint] as Game_Hitpoints).Hitpoints += _Hitpoints;
                        this.DeleteMe();
                        EventManager.GetInstance().AddEvent(DeleteMe, 0.0f);
                        Used = true;
                    }
                }
            }
        }
    }
}
