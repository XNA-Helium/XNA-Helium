
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    class JetPack : WeaponObject
    {
        bool animationset;
        public JetPack(PlayerObject _po) :base(_po)
        {
            animationset = false;
            Drawable_Sprite_Animated dsa = new Drawable_Sprite_Animated();
            dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/JetPackActiveLeft"), new Rectangle(0, 0, 24, 48), "JetPackActiveLeft",5);
            dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/JetPackActiveRight"), new Rectangle(0, 0, 24, 48), "JetPackActiveRight",5);
            dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/JetPackInactiveLeft"), new Rectangle(0, 0, 24, 48), "JetPackInactiveLeft",2);
            dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/JetPackInactiveRight"), new Rectangle(0, 0, 24, 48), "JetPackInactiveRight",2);
            Game_Position_Relative gpr = new Game_Position_Relative(_po,new Vector2(0.0f,-10.0f));
            base.AddComponent(gpr);
            Drawable_Text dt = new Drawable_Text(GetTotalEnergy, new Vector2(0,18));
            base.AddComponent(dt);
            base.AddComponent(dsa);
            base.AddComponent(new Game_Velocity_Limiting(new Vector2(10,10)));
            (base[ComponentType.DrawLayer] as DrawLayer).Layer = 0.66f;

            AddComponent(new DrawLayer(DrawLayer.LayerDepth.HealthPacks)); //behind players            

            SetAnimation("JetPackActive");
            base.AddComponent(ComponentType.Input_Shoot,new Input_Shoot_Other());
        }
        public override void Update(GameTime p_time)
        {
            base.Update(p_time);
            if(!animationset)
            {
                 SetAnimation("JetPackInactive");
            }
            animationset = false;
            Game1.Instance.CenterOn(base.Player.Position());
        }
        public void SetAnimation(string animationname)
        {
            Drawable_Sprite_Animated dsa = (Drawable_Sprite_Animated) base[ComponentType.Drawable_Sprite_Animated];
            if (dsa.CurrentlyPlaying != (animationname + base.Player.GetFacing()))
            {
                dsa.SetCurrentAnimation(animationname + base.Player.GetFacing());
            }
            animationset = true;
        }

        public override ProjectileObject Fire(float Velocity)
        {
            AvailableWeaponList weaponlist = (Game1.Instance.GameManager as GameManagerTeamedInterface).CurrentUTP().AvailableWeapons;
            if (weaponlist.JetPack != AvailableWeaponList.INFINITY)
            {
                weaponlist.JetPack -= 1;
            }
            return null;
        }

        public override void SetFacing(Facing facing)
        {}

        public string GetTotalEnergy()
        {
            float TotalEnergy = 0.0f;
            if(this[ComponentType.Input_Shoot] != null)
            {
                TotalEnergy = (this[ComponentType.Input_Shoot] as Input_Shoot_Other).Totalenergy;
            }
            return "" + (int)TotalEnergy;
        }
        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            (this[ComponentType.Game_Position] as Game_Position).Position = Player.Position();
            base.Draw(p_SpriteBatch, p_GameTime, p_Screen);
        }

    }

}