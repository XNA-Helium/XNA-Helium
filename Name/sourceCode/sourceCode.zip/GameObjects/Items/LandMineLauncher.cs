
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    class LandMineLauncher : WeaponObject
    {
        Vector2 Offset = new Vector2(0, -35);
        public LandMineLauncher(PlayerObject _po)
            : base(_po)
        {
            (this[ComponentType.Game_Position_Relative] as Game_Position_Relative).Offset = Offset;

            Holder_Projectile hp = new Holder_Projectile(new Rocket((_po[ComponentType.Game_Facing] as Game_Facing).Facing));
            base.AddComponent(hp);

            Drawable_Sprite_Static dss = null;
            if ((_po[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Left)
            {
                dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/MineLauncherLeft")); 
            }
            if ((_po[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Right)
            {
                dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/MineLauncherRight")); 
            }
            base.AddComponent(dss);
        }

        public override ProjectileObject Fire(float Velocity)
        {
            AvailableWeaponList weaponlist = (Game1.Instance.GameManager as GameManagerTeamedInterface).CurrentUTP().AvailableWeapons;
            if (weaponlist.LandMine != AvailableWeaponList.INFINITY)
            {
                weaponlist.LandMine -= 1;
            }

            Vector2 StartPosition = (this[ComponentType.Game_Position] as Game_Position).Position;
            LandMine rocket = new LandMine((this[ComponentType.Game_Facing] as Game_Facing).Facing);
            (rocket[ComponentType.Game_Position] as Game_Position).Position = StartPosition;
            float angle = (this[ComponentType.Game_Rotation] as Game_Rotation).Rotation;
            if ((this[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Right)
            {
                (rocket[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2((float)Velocity * (float)Math.Cos(angle), (float)Velocity * (float)Math.Sin(angle));
            }
            if ((this[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Left)
            {
                (rocket[ComponentType.Game_Velocity] as Game_Velocity).Velocity = new Vector2((float)-Velocity * (float)Math.Cos(angle), (float)-Velocity * (float)Math.Sin(angle));
            }

            Game1.Instance.GameManager.AddToSceneGraph(rocket);
            return rocket;
        }

        public override void SetFacing(Facing facing)
        {
            Drawable_Sprite_Static dss = null;
            if (facing == Facing.Left)
            {
                dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/MineLauncherLeft"));
            }
            if (facing == Facing.Right)
            {
                dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/MineLauncherRight"));
            }
            (this[ComponentType.Game_Facing] as Game_Facing).Facing = facing;
            base.AddComponent(dss);
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            // if this objects input component is active then draw
            // otherwise do not draw
            base.Draw(p_SpriteBatch, p_GameTime, p_Screen);
        }

    }
}
