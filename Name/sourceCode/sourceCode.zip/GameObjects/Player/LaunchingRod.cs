
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    public class LaunchingRod : GameObject
    {
        Vector2 RightOffset = new Vector2(0, -16);
        Vector2 LeftOffset = new Vector2(0, -16);
        private PlayerObject _PO;
        public LaunchingRod(PlayerObject _po):base()
        {
            _PO = _po;

            Drawable_Sprite_Animated dsa = new Drawable_Sprite_Animated();
            Game_Position gp = new Game_Position();
            Game_Position_Relative gpr = new Game_Position_Relative(_po);
            Game_Rotation gr = new Game_Rotation(0.0f);
            base.AddComponent(gr);
            base.AddComponent(gp);
            base.AddComponent(dsa);
            base.AddComponent(gpr);

            dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/RodLeft"), new Rectangle(0, 0, 16, 32), "DeployLeft", 3);
            dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/RodRight"), new Rectangle(0, 0, 16, 32), "DeployRight", 3);
            dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/RodExtendedLeft"), new Rectangle(0, 0, 16, 32), "Left", 3);
            dsa.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/RodExtendedRight"), new Rectangle(0, 0, 16, 32), "Right", 3);


            if ((_PO[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Right)
            {
                gpr.Offset = RightOffset;
                dsa.SetCurrentAnimation("DeployRight", "Right");
            }
            if ((_PO[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Left)
            {
                gpr.Offset = RightOffset;
                dsa.SetCurrentAnimation("DeployLeft", "Left");
            }
            DrawLayer d = new DrawLayer(DrawLayer.LayerDepth.HealthPacks);
            base.AddComponent(d);
        }

        public override void Update(GameTime p_time)
        {
            if ((_PO[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Right)
            {
                (this[ComponentType.Game_Position_Relative] as Game_Position_Relative).Offset = RightOffset;
            }
            if ((_PO[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Left)
            {
                (this[ComponentType.Game_Position_Relative] as Game_Position_Relative).Offset = LeftOffset;
            }
            base.Update(p_time);
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            base.Draw(p_SpriteBatch, p_GameTime, p_Screen);
        }

        ~LaunchingRod()
        {
        }
    }
}
