
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Net;
#endregion



namespace Pauliver
{
    class PlayerHitpoints : GameObject
    {
        //Vector2 _lastPosition;
        private GameObject _Object;
        private Game_Hitpoints gh;

        public GameObject GetRelated
        {
            get
            {
                return _Object;
            }
        }

        public PlayerHitpoints(GameObject HasHitpoints)
            : base()
        {
            _Object = HasHitpoints;
            gh = (HasHitpoints[ComponentType.Game_Hitpoint] as Game_Hitpoints);
            
            base.AddComponent(new Game_Position());
            base.AddComponent(new Drawable_Text(gh.GetHitpoints));
            base.AddComponent(new Game_Position_Relative(HasHitpoints, new Vector2(0, 32)));
            base.AddComponent(new DrawLayer(DrawLayer.LayerDepth.PlayerHitPoints));
            base.AddComponent(new Game_Team( (_Object[ComponentType.Game_Team] as Game_Team).Team) );
        }

        public override void Update(GameTime p_time)
        {
            base.Update(p_time);
            if (gh.Hitpoints <= 0)
            {
                if (NetworkManager.IsUsed)
                {
                    if ((Game1.Instance.GameManager as GameManagerTeamedInterface).MyMachineIsActive())
                    {
                        {   // Remove the Player Object
                            PacketWriter pw = new PacketWriter();
                            pw.Write(NetworkGameManagerTeamed.REMOVEOBJECT);
                            int id = Game1.Instance.GameManager.GetIndex(_Object);
                            pw.Write(id);
                            NetworkManager.Instance.SendToAll(pw);
                            Game1.Instance.GameManager.RemoveFromSceneGraph(_Object);
                        }
                        {   // Remove the Player Hitpoint Object
                            PacketWriter pw = new PacketWriter();
                            pw.Write(NetworkGameManagerTeamed.REMOVEOBJECT);
                            int id = Game1.Instance.GameManager.GetIndex(this);
                            pw.Write(id);
                            NetworkManager.Instance.SendToAll(pw);
                            Game1.Instance.GameManager.RemoveFromSceneGraph(this);
                        }
                    }
                }else{
                    Game1.Instance.GameManager.RemoveFromSceneGraph(_Object);
                    Game1.Instance.GameManager.RemoveFromSceneGraph(this);
                }
            }
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            base.Draw(p_SpriteBatch, p_GameTime, p_Screen);
        }
    }
}