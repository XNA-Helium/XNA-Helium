
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    
    public class PlayerObject : GameObject
    {
        public PlayerObject()
            : base()
        {
            Type_Animal a = new Type_Animal();
            Game_Position p = new Game_Position(100, 500);
            Game_Rotation r = new Game_Rotation(0.0f);
            Game_Velocity v = new Game_Velocity(0.0f, 0.0f);
            Drawable_Sprite_Animated s = new Drawable_Sprite_Animated();
            int fps = 5;

            s.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/StandLeft"), new Rectangle(0, 0, 32, 32), "IdleLeft", fps);
            s.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/StandRight"), new Rectangle(0, 0, 32, 32), "IdleRight", fps);
            s.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/WalkLeft"), new Rectangle(0, 0, 32, 32), "WalkLeft", fps);
            s.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/WalkRight"), new Rectangle(0, 0, 32, 32), "WalkRight", fps);
            s.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/AimLeft"), new Rectangle(0, 0, 32, 32), "AimLeft", fps);
            s.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/AimRight"), new Rectangle(0, 0, 32, 32), "AimRight", fps);
            s.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/ShootLeft"), new Rectangle(0, 0, 32, 32), "ShootLeft", fps);
            s.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/ShootRight"), new Rectangle(0, 0, 32, 32), "ShootRight", fps);

            Game_Facing gf = null;
            if (p.Position.X > Game1.Instance.World.X / 2)
            {
                s.SetCurrentAnimation("IdleLeft");
                gf = new Game_Facing(Facing.Left);
            }
            else
            {
                s.SetCurrentAnimation("IdleRight");
                gf = new Game_Facing(Facing.Right);
            }
            base.AddComponent(gf);
            Collidable_Terrain ct = new Collidable_Terrain();
            Collidable c = new Collidable();
            Affectable_Gravity g = new Affectable_Gravity();
            Input_Movement im = new Input_Movement();
            Input_Shoot iss = new Input_Shoot();
            Settled_Ground sg = new Settled_Ground();
            Game_Team gt = new Game_Team(Team.NoTeam);
            //Game_Velocity_Limiting gvl = new Game_Velocity_Limiting(new Vector2(0.0f, 9.0f));
            DrawLayer dl = new DrawLayer(DrawLayer.LayerDepth.Players);
            base.AddComponent(gt);
            base.AddComponent(iss);
            base.AddComponent(dl);
            base.AddComponent(p);
            base.AddComponent(r);
            base.AddComponent(v);
            base.AddComponent(s);
            base.AddComponent(c);
            base.AddComponent(g);
            base.AddComponent(sg);
            base.AddComponent(im);
            base.AddComponent(a);
            base.AddComponent(ct);
            Game_Hitpoints gh = new Game_Hitpoints(100);
            base.AddComponent(gh);
            
            //Debug_Rectangle_Collision drc = new Debug_Rectangle_Collision();
            
            //base.AddComponent(drc);
            c.CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/CollidingBox"));

#if XBOX
            Input_GamePad igp = new Input_GamePad();
            base.AddComponent(igp);
#elif ZUNE
            Input_GamePad igp = new Input_GamePad();
            base.AddComponent(igp);
#elif WINDOWS
            Input_Keyboard ikb = new Input_Keyboard();
            base.AddComponent(ikb);
#else
            Input_GamePad igp = new Input_GamePad();
            base.AddComponent(igp);
#endif
            Input_Menu menu = new Input_Menu();
            base.AddComponent(menu);

            base.AddComponent(new Holder_Weapon(new RocketLauncher(this)));
        }

        public Facing GetFacing()
        {
            return (this[ComponentType.Game_Facing] as Game_Facing).Facing;
        }

        public Team Team
        {
            get
            {
                return (this[ComponentType.Game_Team] as Game_Team).Team;
            }
            set
            {
                (this[ComponentType.Game_Team] as Game_Team).Team = value;
            }
        }

        public override void ProcessInput(PlayerIndex p_Index)
        {
            if (!(base[ComponentType.Holder_Weapon] as Holder_Weapon).IsActive)
            {
                (base[ComponentType.Input_Movement] as Input_Movement).ProcessInput(p_Index);
                if (!(base[ComponentType.Holder_Weapon] as Holder_Weapon).Deploying)
                {
                    (base[ComponentType.Input_Menu] as Input_Menu).ProcessInput(p_Index);
                }
            }
            else
            {
                (base[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon.ProcessInput(p_Index);
            }
        }

        public Vector2 Position()
        {
            return (this[ComponentType.Game_Position] as Game_Position).Position;
        }

        ~PlayerObject()
        {
        }
    }
}