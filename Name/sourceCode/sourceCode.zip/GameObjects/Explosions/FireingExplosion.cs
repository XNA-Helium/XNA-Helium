#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{
    public class FireingExplosion : GameObject
    {
        public FireingExplosion(GameObject Barrel)
            : base()
        {
            //Game_Scale gs = new Game_Scale();
            //base.AddComponent(gs);
            Game_Rotation gr = new Game_Rotation();
            base.AddComponent(gr);
            Game_Position gp = new Game_Position();
            base.AddComponent(gp);
            Drawable_Sprite_Static dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content\Art/Sprites/ShootingCone"));
            base.AddComponent(dss);
            DrawLayer d = new DrawLayer(DrawLayer.LayerDepth.GuiLayer);
            base.AddComponent(d);
        }

        public void SetPostion(Vector2 Position)
        {
            (this[ComponentType.Game_Position] as Game_Position).Position = Position;
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen, float p_AspectRatio)
        {
            Texture2D _CurrentTexture = (this[ComponentType.Drawable_Sprite_Static] as Drawable_Sprite_Static).GetTexture;
            float DrawLayer = 0.90f;
            if (this[ComponentType.DrawLayer] != null)
            {
                DrawLayer = (this[ComponentType.DrawLayer] as DrawLayer).Layer;
            }

            int x = (int)(this[ComponentType.Game_Position] as Game_Position).Position.X + (int)(.5f * _CurrentTexture.Width);
            int y = (int)(this[ComponentType.Game_Position] as Game_Position).Position.Y + (int)(.5f * _CurrentTexture.Height);

            Rectangle DrawTarget = new Rectangle((int)x, (int)y, (int)(_CurrentTexture.Width * Scale * p_AspectRatio), (int)(_CurrentTexture.Height * Scale * p_AspectRatio));

            if (DrawTarget.Intersects(p_Screen))
            {
                #region Handle extreme edge cases [xna 2.0 revisit]
                //XNA Handles this case i guess,
                // so don't fuck with it
                // also we have no way to get the real size of the backbuffer
                // height/width is slightly off
                /*if(DrawTarget.X < 0)
                {
                    SourceRectangle.X += Math.Abs(DrawTarget.X);
                    DrawTarget.X = 0;
                }
                if(DrawTarget.Y < 0)
                {
                    SourceRectangle.Y += Math.Abs(DrawTarget.Y);
                    DrawTarget.Y = 0;
                }

                if(DrawTarget.X + DrawTarget.Width > p_Screen.Width )
                {
                    SourceRectangle.Width -= (DrawTarget.X + DrawTarget.Width - p_Screen.Width );
                    DrawTarget.Width -= (DrawTarget.X + DrawTarget.Width - p_Screen.Width);
                }
                if(DrawTarget.Y + DrawTarget.Height > p_Screen.Height)
                {
                    SourceRectangle.Height -= (DrawTarget.Y + DrawTarget.Height - p_Screen.Height);
                    DrawTarget.Height -= (DrawTarget.Y + DrawTarget.Height - p_Screen.Height);
                }*/
                #endregion
                DrawTarget.X -= (int)p_Screen.X * 1;
                DrawTarget.Y -= (int)p_Screen.Y * 1;
                DrawTarget.X = (int)(DrawTarget.X * (float)p_AspectRatio);
                DrawTarget.Y = (int)(DrawTarget.Y * (float)p_AspectRatio);

                /*
                 * Remember, when you add in a rotation origin
                 * xna then uses THAT as the point from which to draw
                 * so instead of drawing from the upper left hand corner
                 * your now drawing from the middle, which means you need
                 * to shift DrawingPoint down and to the right by .5 * width
                 * and .5 * heigth so that it IS in the center now [at rotation origin]
                 * instead of in the upper left hand corner
                 * The same if you are using a Rectangle to draw from, and not a Point2 [or vector2]
                 */

                p_SpriteBatch.Draw(_CurrentTexture, DrawTarget, null, Color.White, (this[ComponentType.Game_Rotation] as Game_Rotation).Rotation, new Vector2(_CurrentTexture.Width / 2, 0), SpriteEffects.None, DrawLayer);
            }
        }
    }
}
