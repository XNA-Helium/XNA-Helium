#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{
    class WeaponExplosion : DefaultExplosion
    {
        int deletein;

        public WeaponExplosion(Vector2 Position): base()
        {
            Game_Rotation gr = new Game_Rotation();
            base.AddComponent(gr);
            Game_Position gp = new Game_Position(Position);
            base.AddComponent(gp);
            Drawable_Sprite_Animated dss = new Drawable_Sprite_Animated();
            int fps = 2;
            deletein = 8 * fps;
            dss.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/Explosion2"), new Rectangle(0, 0, 64, 64), "Explosion2", fps);

            dss.SetCurrentAnimation("Explosion2"); 
            
            base.AddComponent(dss);

            DrawLayer d = new DrawLayer(DrawLayer.LayerDepth.Explosions);
            base.AddComponent(d);
        }
        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            base.Draw(p_SpriteBatch, p_GameTime, p_Screen);
        }

        public override void Update(GameTime p_time)
        {
            if (deletein-- == 0)
            {
                Game1.Instance.GameManager.RemoveFromSceneGraph(this);
            }
            base.Update(p_time);
        }
    }
}
