#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{
    class MineExplosion : DefaultExplosion
    {
        int deletein = 24;

        bool FirstCollisionRun;
        bool collided;
        public MineExplosion(Vector2 Position)
            : base()
        {
            FirstCollisionRun = false;
            collided = false;
            Game_Rotation gr = new Game_Rotation();
            base.AddComponent(gr);
            Game_Position gp = new Game_Position(Position);
            base.AddComponent(gp);
            Drawable_Sprite_Animated dss = new Drawable_Sprite_Animated();
            int fps = 2;

            dss.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/Explosion3"), new Rectangle(0, 0, 64, 64), "Explosion3", fps);

            dss.SetCurrentAnimation("Explosion3");

            base.AddComponent(dss);
            Type_Weapon tw = new Type_Weapon();
            base.AddComponent(tw);
            Collidable_Animal ca = new Collidable_Animal();
            base.AddComponent(ca);
            Collidable c = new Collidable();
            CollisionCallback cc = new CollisionCallback(OnCollision);
            base.AddComponent(c);
            base.AddComponent(cc);
            (this[ComponentType.Collidable] as Collidable).CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/Explosion3mask"));
            DrawLayer d = new DrawLayer(DrawLayer.LayerDepth.Explosions);
            base.AddComponent(d);
        }

        public void OnCollision(GameObject RHS)
        {
            if (!FirstCollisionRun)
            {
                collided = true;
                if (RHS[ComponentType.Game_Position] != null)
                {
                    if (RHS[ComponentType.Game_Hitpoint] != null)
                    {
                        int Damage = 0;
                        Vector2 RHS_Position = (RHS[ComponentType.Game_Position] as Game_Position).Position;
                        Vector2 This_Position = (this[ComponentType.Game_Position] as Game_Position).Position;
                        Vector2 distance = RHS_Position - This_Position;
                        int td = Math.Abs( (int)distance.X ); //.Length();
                        if (td > 64)
                        {
                            td = 64;
                        }
                        if (td < 0)
                        {
                            td = 0;
                        }
                        Damage = 64 - td;
                        Damage /= 3;
                        Damage += 24;

                        Damage /= 2; //Damage gets applied 2x, so we  divide by 2 to "hack-fix" the bug

                        (RHS[ComponentType.Game_Hitpoint] as Game_Hitpoints).Hitpoints -= Math.Abs(Damage);
                        (RHS[ComponentType.Collidable] as Collidable).Moving = true;
                    }
                }
            }
        }


        public override void  Update(GameTime p_time)
        {
            if (deletein-- == 0)
            {
                Game1.Instance.GameManager.RemoveFromSceneGraph(this);
            }
            base.Update(p_time);
            if (collided)
            {
                FirstCollisionRun = true;
            }
            else
            {
                (this[ComponentType.Collidable] as Collidable).Moving = true;
            }
        }
    }
}