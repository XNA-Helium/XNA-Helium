#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{
    class FlameExplosion : GameObject
    {
        public FlameExplosion(Vector2 Position)
            : base()
        {
            Game_Rotation gr = new Game_Rotation();
            base.AddComponent(gr);
            Game_Position gp = new Game_Position(Position);
            base.AddComponent(gp);
            //Drawable_Sprite_Static dss = new Drawable_Sprite_Static(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/FlameThrowerMask"));
            //base.AddComponent(dss);
           
            Type_Weapon tw = new Type_Weapon();
            base.AddComponent(tw);
            Collidable_Animal ca = new Collidable_Animal();
            base.AddComponent(ca);
            Collidable c = new Collidable();
            CollisionCallback cc = new CollisionCallback(OnCollision);
            base.AddComponent(c);
            base.AddComponent(cc);
            (this[ComponentType.Collidable] as Collidable).CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/FlameThrowerMask"));
            DrawLayer d = new DrawLayer(DrawLayer.LayerDepth.Explosions);
            base.AddComponent(d);
        }

        public override void Update(GameTime p_time)
        {
            (this[ComponentType.Collidable] as Collidable).Moving = true;
            base.Update(p_time);
        }

        public void OnCollision(GameObject rhs)
        {
            if (rhs[ComponentType.Game_Hitpoint] != null)
            {
                (rhs[ComponentType.Game_Hitpoint] as Game_Hitpoints).Hitpoints -= 1;
            }
        }

    }
}