#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{
    class Napalm : DefaultExplosion
    {
        int totalDamage = 30;

        public Napalm(Vector2 Position)
            : base()
        {
            Game_Position gp = new Game_Position(Position);
            base.AddComponent(gp);
            Game_Rotation gr = new Game_Rotation();
            base.AddComponent(gr);
            Drawable_Sprite_Animated dss = new Drawable_Sprite_Animated();
            int fps = 1;

            dss.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/NapalmFireBig"), new Rectangle(0, 0, 32, 32), "Level1", fps);
            dss.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/NapalmFireMed"), new Rectangle(0, 0, 32, 32), "Level2", fps);
            dss.SetupAnimation(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/NapalmFireSmall"), new Rectangle(0, 0, 32, 32), "Level3", fps);

            dss.SetCurrentAnimation("Level1");
            base.AddComponent(dss);
            Type_Weapon tw = new Type_Weapon();
            base.AddComponent(tw);
            Collidable_Animal ca = new Collidable_Animal();
            base.AddComponent(ca);
            Collidable c = new Collidable();
            CollisionCallback cc = new CollisionCallback(OnCollision);
            base.AddComponent(c);
            base.AddComponent(cc);
            (this[ComponentType.Collidable] as Collidable).CalcRectange(PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/Sprites/NapalmMask"));
            DrawLayer d = new DrawLayer(DrawLayer.LayerDepth.Explosions);
            base.AddComponent(d);

            Position.Y = (Game1.Instance.GameManager.Level as DynamicLevel)[(int)Position.X] - (c.Height / 2) - 5;
            gp.Position = Position;

            Random rand = new Random();

            int updates = rand.Next(0, 18);

            while (--updates >= 0)
            {
                dss.Update(null);
            }
        }
        public void OnCollision(GameObject RHS)
        {
            if (RHS[ComponentType.Game_Position] != null)
            {
                if (RHS[ComponentType.Game_Hitpoint] != null)
                {
                    totalDamage -= 1;
                    (RHS[ComponentType.Game_Hitpoint] as Game_Hitpoints).Hitpoints -= 1;
                    (RHS[ComponentType.Collidable] as Collidable).Moving = true;
                    switch(totalDamage)
                    {
                        case 20:
                            (base[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("Level2");
                            break;
                        case 10:
                            (base[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("Level3");
                            break;
                        case 0:
                            Game1.Instance.GameManager.RemoveFromSceneGraph(this);
                            break;
                    }
                }
                else if (RHS is LargeExplosion)
                {
                    totalDamage -= 20;
                    if (totalDamage <= 0)
                    {
                        Game1.Instance.GameManager.RemoveFromSceneGraph(this);
                    }
                    else if (totalDamage <= 10)
                    {
                        (base[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("Level3");
                    }
                    else if (totalDamage <= 20)
                    {
                        (base[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("Level2");
                    }
                    else if (totalDamage <= 30)
                    {
                        (base[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("Level1");
                    }
                }
            }
        }
        


        public override void Update(GameTime p_time)
        {
            base.Update(p_time);
        }
    }
}