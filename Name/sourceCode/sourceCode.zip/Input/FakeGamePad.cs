﻿
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics.PackedVector;
#endregion



namespace Pauliver
{


    public class FakeGamePad : GamePad
    {
        public FakeGamePad(PlayerIndex index)
            : base(index)
        {

        }

        public FakeGamePad(int index)
            : base(index)
        {

        }

        public void Read(PacketReader pr)
        {
            {
                byte mask = pr.ReadByte();
                if ((mask & 0x01) == 0x01)
                {
                    ((FakeButtonWrapper)A).IsRegisterDown = true;
                }
                else
                {
                    ((FakeButtonWrapper)A).IsRegisterDown = false;
                }
                if ((mask & 0x02) == 0x02)
                {
                    ((FakeButtonWrapper)B).IsRegisterDown = true;
                }
                else
                {
                    ((FakeButtonWrapper)B).IsRegisterDown = false;
                }
                if ((mask & 0x04) == 0x04)
                {
                    ((FakeButtonWrapper)Back).IsRegisterDown = true;
                }
                else
                {
                    ((FakeButtonWrapper)Back).IsRegisterDown = false;
                }
                if ((mask & 0x08) == 0x08)
                {
                    ((FakeButtonWrapper)DPadUp).IsRegisterDown = true;
                }
                else
                {
                    ((FakeButtonWrapper)DPadUp).IsRegisterDown = false;
                }
                if ((mask & 0x10) == 0x10)
                {
                    ((FakeButtonWrapper)DPadDown).IsRegisterDown = true;
                }
                else
                {
                    ((FakeButtonWrapper)DPadDown).IsRegisterDown = false;
                }
                if ((mask & 0x20) == 0x20)
                {
                    ((FakeButtonWrapper)DPadLeft).IsRegisterDown = true;
                }
                else
                {
                    ((FakeButtonWrapper)DPadLeft).IsRegisterDown = false;
                }
                if ((mask & 0x40) == 0x40)
                {
                    ((FakeButtonWrapper)DPadRight).IsRegisterDown = true;
                }
                else
                {
                    ((FakeButtonWrapper)DPadRight).IsRegisterDown = false;
                }
            }

            ((FakeButtonWrapper)A).SetState((InputWrapper.ButtonState)pr.ReadByte());

            ((FakeButtonWrapper)B).SetState((InputWrapper.ButtonState)pr.ReadByte());

            ((FakeButtonWrapper)Back).SetState((InputWrapper.ButtonState)pr.ReadByte());

            float x = pr.ReadSingle();
            float y = pr.ReadSingle();

            LeftStick.Update(new Vector2(x, y));

            ((FakeButtonWrapper)DPadUp).SetState((InputWrapper.ButtonState)pr.ReadByte());

            ((FakeButtonWrapper)DPadDown).SetState((InputWrapper.ButtonState)pr.ReadByte());

            ((FakeButtonWrapper)DPadLeft).SetState((InputWrapper.ButtonState)pr.ReadByte());

            ((FakeButtonWrapper)DPadRight).SetState((InputWrapper.ButtonState)pr.ReadByte());
        }

        public override void Update()
        {
            ((FakeButtonWrapper)A).SetNone();

            ((FakeButtonWrapper)B).SetNone();

            ((FakeButtonWrapper)Back).SetNone();

            LeftStick.Update(Vector2.Zero);

            ((FakeButtonWrapper)DPadUp).SetNone();

            ((FakeButtonWrapper)DPadDown).SetNone();

            ((FakeButtonWrapper)DPadLeft).SetNone();
            ((FakeButtonWrapper)DPadRight).SetNone();
#if !ZUNE
            Start.Update();
            X.Update();
            Y.Update();
            LeftBumper.Update();
            RightBumper.Update();
            RightStick.Update(Vector2.Zero);
#endif
        }

        protected override void SetupButtons()
        {
            A = new FakeButtonWrapper(Buttons.A, _index);
            B = new FakeButtonWrapper(Buttons.B, _index);
            Back = new FakeButtonWrapper(Buttons.Back, _index);
            LeftStick = new ThumbStick();
            DPadDown = new FakeButtonWrapper(Buttons.DPadDown, _index);
            DPadUp = new FakeButtonWrapper(Buttons.DPadUp, _index);
            DPadLeft = new FakeButtonWrapper(Buttons.DPadLeft, _index);
            DPadRight = new FakeButtonWrapper(Buttons.DPadRight, _index);
#if !ZUNE
            Start = new FakeButtonWrapper(Buttons.Start, _index);
            X = new FakeButtonWrapper(Buttons.X, _index);
            Y = new FakeButtonWrapper(Buttons.Y, _index);
            LeftBumper = new FakeButtonWrapper(Buttons.LeftShoulder, _index);
            RightBumper = new FakeButtonWrapper(Buttons.RightShoulder, _index);
            RightStick = new ThumbStick();
#endif
        }
        public void SetState(Buttons b, Pauliver.ButtonWrapper.ButtonState state)
        {
            switch (b)
            {
                case Buttons.A:
                    ((FakeButtonWrapper)A).SetState(state);
                    break;
                case Buttons.B:
                    ((FakeButtonWrapper)B).SetState(state);
                    break;
                case Buttons.Back:
                    ((FakeButtonWrapper)Back).SetState(state);
                    break;
                case Buttons.DPadDown:
                    ((FakeButtonWrapper)DPadDown).SetState(state);
                    break;
                case Buttons.DPadUp:
                    ((FakeButtonWrapper)DPadUp).SetState(state);
                    break;
                case Buttons.DPadRight:
                    ((FakeButtonWrapper)DPadRight).SetState(state);
                    break;
                case Buttons.DPadLeft:
                    ((FakeButtonWrapper)DPadLeft).SetState(state);
                    break;
#if !ZUNE
                //add other buttons
#endif

            }
        }

        public void SetLeftStickState(Vector2 Value)
        {
            LeftStick.X = Value.X;
            LeftStick.Y = Value.Y;
        }
#if !ZUNE
        public void SetRightStickState(Vector2 Value)
        {
            RightStick.X = Value.X;
            RightStick.Y = Value.Y;
        }
#endif
    }

}
