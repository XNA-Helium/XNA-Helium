﻿
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics.PackedVector;
#endregion



namespace Pauliver
{


    public class FakeButtonWrapper : ButtonWrapper
    {

        public FakeButtonWrapper(Microsoft.Xna.Framework.Input.Buttons button, PlayerIndex Player)
            : base(button, Player)
        {
        }
        protected override void SetStateFromInput()
        {
            //prevent base from being called
            //base.SetStateFromInput();
        }
        public override void Update()
        {
            _State = ButtonState.None;
        }

        public void ClearRegisterDown()
        {
            RegisterDown = true;
        }

        public void SetPress()
        {
            _State = ButtonState.Pressed;
        }
        public void SetHeld()
        {
            _State = ButtonState.Held;
        }
        public void SetNone()
        {
            _State = ButtonState.None;
        }
        public void SetState(ButtonState state)
        {
            _State = state; ;
        }
    }

}
