﻿
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics.PackedVector;
#endregion



namespace Pauliver
{
#if WINDOWS
    public class KeyboardWrapper : InputWrapper
    {
        protected Microsoft.Xna.Framework.Input.Keys T;

        public KeyboardWrapper(Microsoft.Xna.Framework.Input.Keys Key)
        {
            T = Key;
            _State = ButtonState.None;
            SetStateFromInput();
        }

        protected void SetStateFromInput()
        {
            if (Microsoft.Xna.Framework.Input.Keyboard.GetState().IsKeyDown(T))
            {
                if (RegisterDown)
                    _State = ButtonState.Held;
            }
            if (Microsoft.Xna.Framework.Input.Keyboard.GetState().IsKeyUp(T))
            {
                if (RegisterDown)
                {
                    if (_State == ButtonState.Held)
                    {
                        _State = ButtonState.Pressed;
                    }
                    else
                    {
                        _State = ButtonState.None;
                    }
                }
                else //RegisterDown == false
                {
                    RegisterDown = true;
                }
            }
        }

        public override void Update()
        {
            SetStateFromInput();
        }

    }
#endif
}
