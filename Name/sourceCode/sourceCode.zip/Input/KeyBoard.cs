﻿
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics.PackedVector;
#endregion



namespace Pauliver
{

#if WINDOWS
    public class KeyBoard
    {
        public KeyboardWrapper W;
        public KeyboardWrapper A;
        public KeyboardWrapper S;
        public KeyboardWrapper D;

        public KeyboardWrapper E;

        public KeyboardWrapper Q;
        public KeyboardWrapper U;

        public KeyboardWrapper Up;
        public KeyboardWrapper Down;
        public KeyboardWrapper Left;
        public KeyboardWrapper Right;

        public KeyboardWrapper Space;
        public KeyboardWrapper Enter;
        public KeyboardWrapper Plus;
        public KeyboardWrapper Minus;
        public KeyboardWrapper Escape;

        public KeyboardWrapper Tab;

        public KeyBoard()
        {
            W = new KeyboardWrapper(Keys.W);
            A = new KeyboardWrapper(Keys.A);
            S = new KeyboardWrapper(Keys.S);
            D = new KeyboardWrapper(Keys.D);

            E = new KeyboardWrapper(Keys.E);

            Q = new KeyboardWrapper(Keys.Q);
            U = new KeyboardWrapper(Keys.U);

            Plus = new KeyboardWrapper(Keys.Add);
            Minus = new KeyboardWrapper(Keys.Subtract);

            Up = new KeyboardWrapper(Keys.Up);
            Down = new KeyboardWrapper(Keys.Down);
            Left = new KeyboardWrapper(Keys.Left);
            Right = new KeyboardWrapper(Keys.Right);

            Space = new KeyboardWrapper(Keys.Space);
            Enter = new KeyboardWrapper(Keys.Enter);
            Escape = new KeyboardWrapper(Keys.Escape);

            Tab = new KeyboardWrapper(Keys.Tab);
        }

        public void Update()
        {
            W.Update();
            A.Update();
            S.Update();
            D.Update();

            E.Update();

            Q.Update();
            U.Update();

            Up.Update();
            Down.Update();
            Left.Update();
            Right.Update();

            Space.Update();
            Enter.Update();
            Plus.Update();
            Minus.Update();
            Escape.Update();

            Tab.Update();
        }
    }
#endif

}
