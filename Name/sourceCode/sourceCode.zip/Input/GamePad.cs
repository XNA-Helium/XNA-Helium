﻿
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics.PackedVector;
#endregion



namespace Pauliver
{


    public class GamePad
    {
        public struct ThumbStick
        {
            public float X;
            public float Y;
            public void Update(Vector2 vector)
            {
                X = vector.X;
                Y = vector.Y;
            }
        }

        public void Write(PacketWriter pw)
        {
            {
                byte mask = 0x00;

                if (A.IsRegisterDown)
                {
                    mask |= 0x01;// 10 00 00 00
                }
                if (B.IsRegisterDown)
                {
                    mask |= 0x02;// 01 00 00 00
                }
                if (Back.IsRegisterDown)
                {
                    mask |= 0x04;// 00 10 00 00
                }
                if (DPadUp.IsRegisterDown)
                {
                    mask |= 0x08;// 00 01 00 00
                }
                if (DPadLeft.IsRegisterDown)
                {
                    mask |= 0x10;// 00 00 10 00
                }
                if (DPadDown.IsRegisterDown)
                {
                    mask |= 0x20;// 00 00 01 00
                }
                if (DPadRight.IsRegisterDown)
                {
                    mask |= 0x40;// 00 00 00 10
                }
                pw.Write(mask);
            }

            pw.Write(A.GetStateForStreaming());

            pw.Write(B.GetStateForStreaming());

            pw.Write(Back.GetStateForStreaming());

            pw.Write(LeftStick.X);
            pw.Write(LeftStick.Y);

            pw.Write(DPadUp.GetStateForStreaming());

            pw.Write(DPadDown.GetStateForStreaming());

            pw.Write(DPadLeft.GetStateForStreaming());

            pw.Write(DPadRight.GetStateForStreaming());
        }

        public ButtonWrapper A;
        public ButtonWrapper B;
        public ThumbStick LeftStick;
        public ButtonWrapper Back;
        public ButtonWrapper DPadUp;
        public ButtonWrapper DPadDown;
        public ButtonWrapper DPadLeft;
        public ButtonWrapper DPadRight;
#if !ZUNE
        public ButtonWrapper Start;
        public ButtonWrapper X;
        public ButtonWrapper Y;
        public ButtonWrapper LeftBumper;
        public ButtonWrapper RightBumper;
        public ThumbStick RightStick;
#endif

        protected PlayerIndex _index;
        public GamePad(PlayerIndex index)
        {
            _index = index;
            SetupButtons();
        }
        public GamePad(int Player)
        {
            _index = (PlayerIndex)(Player - 1);
            SetupButtons();
        }

        protected virtual void SetupButtons()
        {
            A = new ButtonWrapper(Buttons.A, _index);
            B = new ButtonWrapper(Buttons.B, _index);
            Back = new ButtonWrapper(Buttons.Back, _index);
            LeftStick = new ThumbStick();
            DPadDown = new ButtonWrapper(Buttons.DPadDown, _index);
            DPadUp = new ButtonWrapper(Buttons.DPadUp, _index);
            DPadRight = new ButtonWrapper(Buttons.DPadRight, _index);
            DPadLeft = new ButtonWrapper(Buttons.DPadLeft, _index);
#if !ZUNE
            Start = new ButtonWrapper(Buttons.Start, _index);
            X = new ButtonWrapper(Buttons.X, _index);
            Y = new ButtonWrapper(Buttons.Y, _index);
            LeftBumper = new ButtonWrapper(Buttons.LeftShoulder, _index);
            RightBumper = new ButtonWrapper(Buttons.RightShoulder, _index);
            RightStick = new ThumbStick();
#endif
        }

        public virtual void Update()
        {
            A.Update();
            B.Update();

            Back.Update();

            LeftStick.Update(Microsoft.Xna.Framework.Input.GamePad.GetState((Microsoft.Xna.Framework.PlayerIndex)_index).ThumbSticks.Left);
            DPadUp.Update();
            DPadDown.Update();
            DPadLeft.Update();
            DPadRight.Update();

            //Zune 30 controls
            if (DPadDown.State == InputWrapper.ButtonState.Pressed || DPadDown.State == InputWrapper.ButtonState.Held)
            {
                LeftStick.Y -= 1;
            }
            if (DPadUp.State == InputWrapper.ButtonState.Pressed || DPadUp.State == InputWrapper.ButtonState.Held)
            {
                LeftStick.Y += 1;
            }
            if (DPadLeft.State == InputWrapper.ButtonState.Pressed || DPadLeft.State == InputWrapper.ButtonState.Held)
            {
                LeftStick.X -= 1;
            }
            if (DPadRight.State == InputWrapper.ButtonState.Pressed || DPadRight.State == InputWrapper.ButtonState.Held)
            {
                LeftStick.X += 1;
            }
#if !ZUNE
            Start.Update();
            X.Update();
            Y.Update();
            LeftBumper.Update();
            RightBumper.Update();
            RightStick.Update(Microsoft.Xna.Framework.Input.GamePad.GetState((Microsoft.Xna.Framework.PlayerIndex)_index).ThumbSticks.Right);
#endif
        }
    }

}
