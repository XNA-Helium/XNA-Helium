﻿
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics.PackedVector;
#endregion



namespace Pauliver
{

    public class PInput
    {
        protected static PInput _Instance;
        public static PInput Instance
        {
            get
            {
                if (_Instance == null)
                {
                    _Instance = new PInput();
                }
                return _Instance;
            }
        }
#if WINDOWS
        protected KeyBoard _Keyboard;
#endif
        protected GamePad _GamePad1;
        public GamePad GamePad1
        {
            get
            {
                return _GamePad1;
            }
        }
        protected GamePad _GamePad2;
        public GamePad GamePad2
        {
            get
            {
                return _GamePad2;
            }
        }
        protected GamePad _GamePad3;
        public GamePad GamePad3
        {
            get
            {
                return _GamePad3;
            }
        }
        protected GamePad _GamePad4;
        public GamePad GamePad4
        {
            get
            {
                return _GamePad4;
            }
        }
        //@@ this should be handled in a different way
        public bool Is1Human = true;
        public bool Is2Human = false;
        public bool Is3Human = false;
        public bool Is4Human = false;

        protected PInput()
        {
#if WINDOWS
            _Keyboard = new KeyBoard();
#endif
            _GamePad1 = new GamePad(PlayerIndex.One);
            _GamePad2 = null;
            _GamePad3 = null;
            _GamePad4 = null;
#if !ZUNE
            _GamePad2 = new GamePad(PlayerIndex.Two);
            _GamePad3 = new GamePad(PlayerIndex.Three);
            _GamePad4 = new GamePad(PlayerIndex.Four);
#endif
        }

        public void SetFakeGamePad(int i, PlayerIndex index)
        {
            switch (i)
            {
                //case 1:
                //_GamePad1 = new FakeGamePad(index);
                //break;
                case 2:
                    _GamePad2 = new FakeGamePad(index);
                    break;
                case 3:
                    _GamePad3 = new FakeGamePad(index);
                    break;
                case 4:
                    _GamePad4 = new FakeGamePad(index);
                    break;
            }
        }

        public void ResetGamePads()
        {
#if !ZUNE
            _GamePad2 = new GamePad(PlayerIndex.Two);
            _GamePad3 = new GamePad(PlayerIndex.Three);
            _GamePad4 = new GamePad(PlayerIndex.Four);
#else
            _GamePad2 = null;
            _GamePad3 = null;
            _GamePad4 = null;
#endif
        }

        public void Update()
        {
#if WINDOWS
            _Keyboard.Update();
#endif
            _GamePad1.Update();
            if (_GamePad2 != null)
                _GamePad2.Update();
            if (_GamePad3 != null)
                _GamePad3.Update();
            if (_GamePad4 != null)
                _GamePad4.Update();

        }
#if WINDOWS
        public KeyBoard Keyboard
        {
            get
            {
                return _Keyboard;
            }
        }
#endif

        public void ReadInputFromNetwork(PlayerIndex index, PacketReader pr)
        {
            if (!(GamePad(index) is FakeGamePad))
            {
                pr.ReadByte();
                pr.ReadByte();
                pr.ReadByte();
                pr.ReadByte();

                pr.ReadSingle();
                pr.ReadSingle();

                pr.ReadByte();
                pr.ReadByte();
                pr.ReadByte();
                pr.ReadByte();
                return;
            }
            FakeGamePad fgp = (FakeGamePad)GamePad(index);
            fgp.Read(pr);
        }

        public void WriteInputToNetwork(PlayerIndex index, PacketWriter pr)
        {
            GamePad gp = GamePad(index);
            gp.Write(pr);
        }

        public GamePad GamePad(int index)
        {
            switch (index)
            {
                case 1:
                    return _GamePad1;
                case 2:
                    return _GamePad2;
                case 3:
                    return _GamePad3;
                case 4:
                    return _GamePad4;
            }
            return _GamePad1;
        }

        public GamePad GamePad(PlayerIndex index)
        {
            switch (index)
            {
                case PlayerIndex.One:
                    return _GamePad1;
                case PlayerIndex.Two:
                    return _GamePad2;
                case PlayerIndex.Three:
                    return _GamePad3;
                case PlayerIndex.Four:
                    return _GamePad4;
            }
            return _GamePad1;
        }

        public bool IsHuman(PlayerIndex index)
        {
            switch (index)
            {
                case PlayerIndex.One:
                    return Is1Human;
                case PlayerIndex.Two:
                    return Is2Human;
                case PlayerIndex.Three:
                    return Is3Human;
                case PlayerIndex.Four:
                    return Is4Human;
            }
            return false;
        }
    }

}
