#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{

    class FakeCollision : TerrainOnly
    {
        public FakeCollision() : base()
        {}

        public override void ObjectOnObjectCollision()
        {
            base.ObjectOnObjectCollision();
        }

        public override void ObjectOnTerrainCollision()
        {
            List<GameObject> gameobjects = Game1.Instance.GameManager.SceneGraph;
            Terrain t = Game1.Instance.GameManager.Terrain;
            foreach (GameObject g in gameobjects)
            {
                Vector2 p = (g[ComponentType.Game_Position] as Game_Position).Position;
                Collidable c = (g[ComponentType.Collidable] as Collidable);
                {
                    ProjectileObject po = (g as ProjectileObject);
                    if (p.X > Game1.Instance.World.X - 32)
                    {
                        if (po != null)
                        {
                            if (p.X > Game1.Instance.World.X + 32)
                            {
                                Game1.Instance.GameManager.RemoveFromSceneGraph(g);
                                c.Moving = false;
                            }
                        }
                        else
                        {
                            p.X = Game1.Instance.World.X - 32;
                        }
                    }
                    else if (p.X < 32)
                    {
                        if (po != null)
                        {
                            if(p.X < -32)
                            {
                                Game1.Instance.GameManager.RemoveFromSceneGraph(g);
                                c.Moving = false;
                            }
                        }
                        else
                        {
                            p.X = 32;
                        }
                    }
                    if (p.Y > Game1.Instance.World.Y + 128)
                    {
                        Game1.Instance.GameManager.RemoveFromSceneGraph(g);
                        c.Moving = false;
                    }
                    if (p.Y <= 0 && po == null)
                    {
                        p.Y = 0;
                    }
                    (g[ComponentType.Game_Position] as Game_Position).Position = p;
                }

                p = (g[ComponentType.Game_Position] as Game_Position).Position;

                if(c != null && c.Moving)
                {
                    float pY = p.Y +(c.Height/2);
                    if( ((int)pY) > t[(int)p.X])
                    {
                        (g[ComponentType.Game_Position] as Game_Position).Position = new Vector2(p.X, t[(int)p.X] - (c.Height/2));
                        c.Moving = false;
                        Game_Velocity gv = (g[ComponentType.Game_Velocity] as Game_Velocity);
                        Settled_Ground sg = (g[ComponentType.Settled_Ground] as Settled_Ground);
                        CollisionCallback cc = (g[ComponentType.CollisionCallback] as CollisionCallback);
                        if (gv != null)
                        {
                            gv.Velocity = Vector2.Zero;
                        }
                        if (sg != null)
                        {
                            sg.Settled = true;
                        }
                        if(cc !=  null)
                        {
                            cc.OnCollision(g);
                        }
                    }else if(g is PlayerObject)
                    {
                        WeaponObject j = (WeaponObject)(g[ComponentType.Holder_Weapon] as Holder_Weapon).Weapon;
                        if ( !(j is JetPack && (j[ComponentType.Input_Shoot] as Input_Shoot_Other).Shooting) ) 
                        {
                            (g[ComponentType.Game_Position] as Game_Position).Position = new Vector2(p.X, t[(int)p.X] - (c.Height / 2));
                            c.Moving = false;
                            Game_Velocity gv = (g[ComponentType.Game_Velocity] as Game_Velocity);
                            Settled_Ground sg = (g[ComponentType.Settled_Ground] as Settled_Ground);
                            CollisionCallback cc = (g[ComponentType.CollisionCallback] as CollisionCallback);
                            if (gv != null)
                            {
                                gv.Velocity = Vector2.Zero;
                            }
                            if (sg != null)
                            {
                                sg.Settled = true;
                            }
                            if (cc != null)
                            {
                                cc.OnCollision(g);
                            }
                        }
                    }
                }
            }
        }
    }
}