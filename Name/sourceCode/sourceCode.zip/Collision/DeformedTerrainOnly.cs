#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{

    class DeformedTerrain : TerrainOnly
    {
        public DeformedTerrain()
            : base()
        {
        }


        public override void ObjectOnTerrainCollision()
        {
            List<GameObject> gameobjects = Game1.Instance.GameManager.SceneGraph;
            Rectangle TerrainBB = Game1.Instance.GameManager.Terrain.m_BoundingRectangle;
            foreach (GameObject gameObject in gameobjects)
            {
                if (gameObject is LargeExplosion || gameObject is SmallExplosion)
                {
                    Collidable temp = (Collidable)gameObject[ComponentType.Collidable];
                    Vector2 Position = (gameObject[ComponentType.Game_Position] as Game_Position).Position;
                    if (Game1.Instance.GameManager.Terrain[(int)Position.X] < (Position.Y + 64)) //@@ should be plus .5 * height
                    {
                        if (TerrainBB.Intersects(temp.GetBoundingBox))
                        {
                            List<Vector2> Points = new List<Vector2>();
                            if (temp.IntersectPixels(TerrainBB, Game1.Instance.GameManager.Terrain.m_TextureData, out Points))
                            {
                                Game1.Instance.GameManager.Level.Terrain.DeformTerrain(Points);
                            }
                        }
                    }
                }
            }
            base.ObjectOnTerrainCollision();
        }

    }
}
