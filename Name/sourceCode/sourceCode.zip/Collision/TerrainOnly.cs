#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{
    class TerrainOnly : BaseCollision
    {
        public TerrainOnly() : base()
        {
        }
        
        public override void ObjectOnObjectCollision()
        {
            List<GameObject> objectlist =  Game1.Instance.GameManager.SceneGraph;
            foreach (GameObject g1 in objectlist)
            {
                Collidable c1 = (g1[ComponentType.Collidable] as Collidable);
                if (c1 != null && c1.Moving)
                {
                    Rectangle g1BB = c1.GetBoundingBox;
                    CollisionCallback cc1 = (g1[ComponentType.CollisionCallback] as CollisionCallback);
                    foreach (GameObject g2 in objectlist)
                    {
                        if (!g1.Equals(g2))
                        {
                            Collidable c2 = (g2[ComponentType.Collidable] as Collidable);
                            if (c2 != null)
                            {
                                if (g1BB.Intersects(c2.GetBoundingBox))
                                {
                                    {
                                        CollisionCallback cc2 = (g2[ComponentType.CollisionCallback] as CollisionCallback);
                                        if (cc1 != null)
                                        {
                                            cc1.OnCollision(g2);
                                        }
                                        if (cc2 != null)
                                        {
                                            cc2.OnCollision(g1);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
