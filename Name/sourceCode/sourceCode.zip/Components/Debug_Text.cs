
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
   [Serializable]
    class Debug_Text : Debug
    {
        ReturnsString _ReturnsString;
        SpriteFont _font;
        public Debug_Text(ReturnsString p_ReturnsString)
        {
            _ReturnsString = p_ReturnsString;
            base._Type = ComponentType.Debug_Text;
            _font = PContentManager.Instance.GetObject<SpriteFont>(@"Content\Art/Fonts/INVADER");
        }
        public override void Update(GameTime p_time)
        {

        }
        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {

            if (Game1.Instance.Debug)
            {
                Vector2 Position = (base.Parent[ComponentType.Game_Position] as Game_Position).Position;
                p_SpriteBatch.DrawString(_font, _ReturnsString(), Position - new Vector2(p_Screen.X, p_Screen.Y), Color.White, 0.0f, new Vector2(0, 0), 1.0f, SpriteEffects.None, 0.01f);
            }
        }
    }
}
