
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{

    [Serializable]
    class Holder_Weapon : DrawableComponent
    {
        bool Active;
        WeaponObject _Weapon;
        public Holder_Weapon(WeaponObject Weapon)
        {
            base._Type = ComponentType.Holder_Weapon;
            _Weapon = Weapon;
            Active = false;
            deploying = false;
        }
        bool deploying;
        public bool Deploying
        {
            get{
                return deploying;
            }
            set{
                deploying = value;
            }
        }

        public bool IsActive
        {
            get
            {
                return Active;
            }
            set
            {
                Active = value;
            }
        }

        public WeaponObject Weapon
        {
            get
            {
                return _Weapon;
            }
        }

        public override void Update(GameTime p_time)
        {
            if (Active)
            {
                _Weapon.Update(p_time);
            }
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            if (Active)
            {
                _Weapon.Draw(p_SpriteBatch, p_GameTime, p_Screen);
            }
        }
    }
}

	//the weapon holder holds a GameObject of weapon type
    //a "animal" can have it, but only 1