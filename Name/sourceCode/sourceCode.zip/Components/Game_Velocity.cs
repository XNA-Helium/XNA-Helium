
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    [Serializable]
    class Game_Velocity : Component
    {
        Vector2 _velocity;
        public Game_Velocity()
        {
            base._Type = ComponentType.Game_Velocity;
            _velocity = new Vector2(0.0f,0.0f);
            //requires a position component
        }
        public Game_Velocity(Vector2 p_Velocity)
        {
            base._Type = ComponentType.Game_Velocity;
            _velocity = new Vector2(p_Velocity.X, p_Velocity.Y);
        }
        public Game_Velocity(float p_x, float p_y)
        {
            base._Type = ComponentType.Game_Velocity;
            _velocity = new Vector2(p_x, p_y);
        }
        public float X
        {
            get
            {
                return _velocity.X;
            }
            set
            {
                _velocity.X = value;
            }
        }
        public float Y
        {
            get
            {
                return _velocity.Y;
            }
            set
            {
                _velocity.Y = value;
            }
        }
        public Vector2 Velocity
        {
            get
            {
                return _velocity;
            }
            set
            {
                _velocity = value;
            }
        }

        public override void Update(GameTime p_time)
        {
            if (_velocity != Vector2.Zero)
            {
                Vector2 MaxVeloctiy = Vector2.Zero;
                Collidable c = (base.Parent[ComponentType.Collidable] as Collidable);
                {
                    if (c != null)
                    {
                        c.Moving = true;
                    }else{
                        return;
                    }
                }
                {
                    Game_Velocity_Limiting gvl = (base.Parent[ComponentType.Game_Velocity_Limiting] as Game_Velocity_Limiting);
                    if (gvl != null)
                    {
                        MaxVeloctiy = gvl.MaxVelocity;

                        if (MaxVeloctiy.X > 0)
                        {
                            if (_velocity.X > MaxVeloctiy.X)
                            {
                                _velocity.X = MaxVeloctiy.X;
                            }
                        }
                        if (MaxVeloctiy.Y > 0)
                        {
                            if (_velocity.Y > MaxVeloctiy.Y)
                            {
                                _velocity.Y = MaxVeloctiy.Y;
                            }
                        }
                    }
                }

                if (_velocity == Vector2.Zero)
                {
                    if (c != null)
                    {
                        if (!c.Moving)
                        {
                            //if we are not moving, then we are not moving.. yes this is redundant
                            c.Moving = false;
                            return;
                        }
                    }
                }

                {//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                    //@@ we should probably take this out, update should do nothing
                    //the physics engine should handle all the movement
                    Settled_Ground sg = (base.Parent[ComponentType.Settled_Ground] as Settled_Ground);
                    Game_Position gp = (base.Parent[ComponentType.Game_Position] as Game_Position);
                    if (sg != null)
                    {
                        if (!sg.Settled)
                        {
                            gp.Position += _velocity; // * p_time ?
                        }
                    }
                    else
                    {
                        gp.Position += _velocity; // * p_time ?
                    }

                }//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            }
        }
    }
}
