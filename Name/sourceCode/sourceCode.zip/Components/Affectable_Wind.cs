
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    class WindManager
    {
        private static WindManager _Instance;
        private Vector2 _Wind;
        public static WindManager Instance
        {
            get
            {
                if (_Instance == null)
                {
                    _Instance = new WindManager();
                }
                return _Instance;
            }
        }

        public Vector2 Wind
        {
            get
            {
                return _Wind;
            }
            internal set
            {
                _Wind = value;
            }
        }
    }

    [Serializable]
    class Affectable_Wind : Component
    {
        public Affectable_Wind()
        {
            base._Type = ComponentType.Affectable_Wind;
        }
        public override void Update(GameTime p_time)
        {
            {
                Settled_Ground sg = (base.Parent[ComponentType.Settled_Ground] as Settled_Ground);
                if (sg != null && sg.Settled)
                {
                    return;
                }
            }
            {
                Collidable c = (base.Parent[ComponentType.Collidable] as Collidable);
                if (c != null)
                {
                    c.Moving = true;
                }
            }

            (base.Parent[ComponentType.Game_Velocity] as Game_Velocity).Velocity += WindManager.Instance.Wind; // * p_time ?
        }
        public Vector2 Wind
        {
            get
            {
                return WindManager.Instance.Wind;
            }
        }
    }

}