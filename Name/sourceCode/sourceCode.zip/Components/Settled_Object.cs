
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    [Serializable]
    class Settled_Object : Component
    {
        Vector2 _previousposition;
        bool _settled;
        Game_Position _SettledOnObject;
        Vector2 _SettledOnObjectsPosition;
        public Settled_Object()
        {
            base._Type = ComponentType.Settled_Object;
            _settled = false;
        }

        public bool Settled
        {
            get { return _settled; }
            set { _settled = value; }
        }

        public Game_Position SettledOn
        {
            get
            {
                return _SettledOnObject;
            }
            set
            {
                _SettledOnObjectsPosition = value.Position;
                _SettledOnObject = value;
            }
        }

        public override void Update(GameTime p_time)
        {
            if (!_settled)
            {
                _previousposition = (base.Parent[ComponentType.Game_Position] as Game_Position).Position;
            }
            else if (_SettledOnObject.Position != _SettledOnObjectsPosition)
            {
                _settled = false;
                if (Parent[ComponentType.Collidable] != null)
                {
                    (Parent[ComponentType.Collidable] as Collidable).Moving = true;
                }
                (base.Parent[ComponentType.Game_Position] as Game_Position).Y -= 8;
                if (Parent[ComponentType.Game_Velocity] != null)
                {
                    (Parent[ComponentType.Game_Velocity] as Game_Velocity).Y -= 4;
                }
            }
            if (_settled)
            {
                if (base.Parent[ComponentType.Collidable] != null)
                {
                    (base.Parent[ComponentType.Collidable] as Collidable).Moving = false;
                }
                (base.Parent[ComponentType.Game_Position] as Game_Position).Position = _previousposition;
            }
        }

        public override void Init()
        {
            _previousposition = (base.Parent[ComponentType.Game_Position] as Game_Position).Position;
        }
    }
}
