
#region Using Statements
using System;
using System.Collections.Generic;
#if WINDOWS
//using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
#endif
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    public enum ComponentType 
    {
        BaseComponent, 
        Affectable_Gravity,
        Affectable_Wind,
        Collidable,
            Collidable_Animal, Collidable_Terrain, Collidable_Weapon,
        CollisionCallback,
        Debug,
            Debug_Rectangle,
                Debug_Rectangle_Collision,
                Debug_Rectangle_Render,
            Debug_Text,
        Drawable,
            Drawable_Line, 
            Drawable_Sprite_Animated, 
            Drawable_Sprite_Static, 
            Drawable_Sprite_Annimated_Static_Collision,
            Drawable_Text, 
        DrawLayer,
        Game_Hitpoint,
        Game_Damage,
        Game_Position,
        Game_Rotation,
        Game_Position_Relative,
        Game_Scale,
        Game_Team,
        Game_Facing,
        Game_Velocity,
        Game_Velocity_Limiting,
        Holder_Projectile,
        Holder_Weapon,
        Input,
            Input_GamePad, Input_Keyboard,
            Input_Menu, Input_Movement,
            Input_Shoot, 
        Type_Animal,
        Type_TerrainAddition,
        Type_Weapon,
        Settled_Ground,
        Settled_Object,
        SoundEffect
    };

    public enum AdditionalUpdate{ None, PostUpdate,PostPostUpdate,PostPostPostUpdate};


    abstract public class Component //: ISerializable 
    {

        GameObject _Parent;

        protected ComponentType _Type;

        public ComponentType Type
        {
            get
            {
                return _Type;
            }
        }

        public virtual void Init() {}

        public GameObject Parent
        {
            get
            {
                return _Parent;
            }
            set
            {
                _Parent = value;
            }
        }

        public virtual void Update(GameTime p_time) { }

        /*
        public Component(SerializationInfo info, StreamingContext ctxt)
        {
            _Type = (ComponentType) info.GetValue("_Type", typeof(int));
        }
        */
#if WINDOWS
        public virtual void /* ISerializable. */ GetObjectData(System.Runtime.Serialization.SerializationInfo p_SerialInfo, System.Runtime.Serialization.StreamingContext p_StreamingContent)
        {
            p_SerialInfo.AddValue("_Type", (int)_Type);
        }
        #endif

    }

}