#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{
    [Serializable]
    class Debug_Rectangle : Debug
    {
        protected Color _RenderColor;
        protected Rectangle _DrawRectangle;
        protected Texture2D _WhiteBox;
        public Debug_Rectangle(Color p_Color)
        {
            base._Type = ComponentType.Debug_Rectangle;
            _RenderColor = p_Color;
        }

        public override void Init()
        {
            base.Init();
            _WhiteBox = PContentManager.Instance.GetObject<Texture2D>("whitebox");
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
           /* if (Game1.Instance.Debug)
            {
                int x = _DrawRectangle.X + (int)(0.5f * _DrawRectangle.Width);
                int y = _DrawRectangle.Y + (int)(0.5f * _DrawRectangle.Height);

                Rectangle DrawTarget = new Rectangle((int)x, (int)y, (int)(_DrawRectangle.Width * p_AspectRatio), (int)(_DrawRectangle.Height * p_AspectRatio));

                if (DrawTarget.Intersects(p_Screen))
                {

                    DrawTarget.X -= (int)p_Screen.X * 1;
                    DrawTarget.Y -= (int)p_Screen.Y * 1;
                    DrawTarget.X = (int)(DrawTarget.X * (float)p_AspectRatio);
                    DrawTarget.Y = (int)(DrawTarget.Y * (float)p_AspectRatio);
                    p_SpriteBatch.Draw(_WhiteBox, DrawTarget, null, _RenderColor, 0.0f, new Vector2(_WhiteBox.Width / 2, _WhiteBox.Height / 2), SpriteEffects.None, 0.0f);
                }
            } */
            //merge in the code from drawable sprite static..
        }
    }
}
