#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    [Serializable]
    class Drawable_Sprite_Annimated_Static_Collision : DrawableComponent
    {
        private Texture2D _CollisionBox;
        public Texture2D CollisionBox
        {
            get
            {
                return _CollisionBox;
            }
        }

        System.Collections.Hashtable _SpriteSheetList;
        String _CurrentSprite;
        bool _CurrentlyPlaying;
        String _NextSprite;

        public string CurrentlyPlaying
        {
            get
            {
                return _CurrentSprite;
            }
        }

        public Drawable_Sprite_Annimated_Static_Collision(Texture2D basetexture)
        {
            _CollisionBox = basetexture;
            base._CurrentTexture = _CollisionBox;
            _CurrentlyPlaying = false;
            base._Type = ComponentType.Drawable_Sprite_Annimated_Static_Collision;
            _SpriteSheetList = new System.Collections.Hashtable();
        }
        public override AdditionalUpdate AdditionalUpdates
        {
            get { return AdditionalUpdate.None; }
        }
        public override void Update()
        {
        }

        public override void Update(GameTime p_time)
        {
            if (_CurrentlyPlaying)
            {
                bool LastFrame = (_SpriteSheetList[_CurrentSprite] as SpriteSheet).AtLastFrame();
                (_SpriteSheetList[_CurrentSprite] as SpriteSheet).Update(p_time);
                if (LastFrame && _NextSprite != null)
                {
                    SetCurrentAnimation(_NextSprite);
                }
            }
        }

        public void SetupAnimation(Texture2D p_SpriteSheet, Rectangle p_BoxSize, String p_Name, int fps)
        {
            SpriteSheet ss = new SpriteSheet(p_SpriteSheet, p_BoxSize, p_Name,fps);
            _SpriteSheetList[p_Name] = ss;
        }

        public void SetCurrentAnimation(String p_AnimationName, String p_NextAnimationName)
        {
            SetCurrentAnimation(p_AnimationName);
            _NextSprite = p_NextAnimationName;
        }


        public void SetCurrentAnimation(String p_AnimationName)
        {
            _CurrentlyPlaying = true;
            (_SpriteSheetList[p_AnimationName] as SpriteSheet).Reset();
            _CurrentSprite = p_AnimationName;
            Texture2D temp = new Texture2D(Game1.Instance.GraphicsDevice.GraphicsDevice, (_SpriteSheetList[p_AnimationName] as SpriteSheet)._BoxSize.Width, (_SpriteSheetList[p_AnimationName] as SpriteSheet)._BoxSize.Height, 1, TextureUsage.AutoGenerateMipMap , SurfaceFormat.Color);

            Color[] ColorArray = new Color[(_SpriteSheetList[p_AnimationName] as SpriteSheet)._BoxSize.Width * (_SpriteSheetList[p_AnimationName] as SpriteSheet)._BoxSize.Height];
            temp.GetData(ColorArray);

            Color[] ColorArray2 = new Color[(_SpriteSheetList[p_AnimationName] as SpriteSheet)._SpriteSheet.Width * (_SpriteSheetList[p_AnimationName] as SpriteSheet)._SpriteSheet.Height];
            (_SpriteSheetList[p_AnimationName] as SpriteSheet)._SpriteSheet.GetData(ColorArray2);

            for (int i = 0; i < (_SpriteSheetList[p_AnimationName] as SpriteSheet)._BoxSize.Height; ++i)
            {
                for (int j = 0; j < (_SpriteSheetList[p_AnimationName] as SpriteSheet)._BoxSize.Width; ++j)
                {
                    ColorArray[(i * (_SpriteSheetList[p_AnimationName] as SpriteSheet)._BoxSize.Width) + j] = ColorArray2[(i * (_SpriteSheetList[p_AnimationName] as SpriteSheet)._SpriteSheet.Width) + j];
                }
            }
            temp.SetData(ColorArray);
            base._CurrentTexture = temp;
            _NextSprite = null;
        }

        public override void PreDraw(SpriteBatch p_SpriteBatch, GameTime p_GameTime)
        {
            if (_CurrentlyPlaying)
            {
                base._CurrentTexture = (_SpriteSheetList[_CurrentSprite] as SpriteSheet).PreDraw(p_SpriteBatch, p_GameTime);
            }
        }

        public void StopAnimation()
        {
            _CurrentlyPlaying = false;
        }
    }
}