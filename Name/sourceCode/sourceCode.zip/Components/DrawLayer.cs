
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    [Serializable]
    public class DrawLayer : Component
    {

        public enum LayerType { Background = 90, Game = 60, Overlay = 40, GUI = 20, DEBUG = 10 };

        //0 front 1 back
        public enum LayerDepth { Background = 99, PlayerHitPoints = 95, HealthPacks = 85, Players = 80, Projectiles = 75, Weapons = 70, Explosions = 65, ArrowAbovePlayer = 64, MiniMap = 59, MiniMapRectangle = 57, GreenPlayerDot = 55, MiniMapDot = 54, MainScreenOverlay = 50, TeamHealthBar = 49, MenuBackground = 39, BetweenMenu = 35, MenuButton = 30, ScreenText = 25, DebugLayer = 19 };


        float _DrawLayer;
        public float Layer
        {
            get
            {
                return _DrawLayer;
            }
            set
            {
                _DrawLayer = value;
            }
        }

        public static float GetLayer(LayerDepth depth)
        {
            return 0.01f * (float)(int)depth; 
        }

        public DrawLayer(LayerDepth DrawLayer)
        {
            base._Type = ComponentType.DrawLayer;
            _DrawLayer = 0.01f * (float)DrawLayer;
        }
        public DrawLayer()
        {
            _DrawLayer = 0.99f;
            base._Type = ComponentType.DrawLayer;
        }
    }
}
