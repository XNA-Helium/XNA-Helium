
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    //simply exists to tell other inputs where to get their input from
    //in this case GamePad


    [Serializable]
    class Input_GamePad : Component
    {
        public Input_GamePad()
        {
            base._Type = ComponentType.Input_GamePad;
        }
    }
}
