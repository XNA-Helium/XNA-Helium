
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    public delegate string ReturnsString();

    [Serializable]
    class Drawable_Text : DrawableComponent
    {
        ReturnsString _ReturnsString;
        SpriteFont _font;
        Vector2 offset;
        public Drawable_Text(ReturnsString p_ReturnsString)
        {
            offset = Vector2.Zero;
            _ReturnsString = p_ReturnsString;
            base._Type = ComponentType.Drawable_Text;
            _font = PContentManager.Instance.GetObject<SpriteFont>(@"Content/Art/Fonts/Irken");
        }
        public Drawable_Text(ReturnsString p_ReturnsString,Vector2 p_offset)
        {
            offset = p_offset;
            _ReturnsString = p_ReturnsString;
            base._Type = ComponentType.Drawable_Text;
            _font = PContentManager.Instance.GetObject<SpriteFont>(@"Content/Art/Fonts/Irken");
        }

        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            Color DrawColor = Color.White;
            Game_Team gt = (Parent[ComponentType.Game_Team] as Game_Team);
            if (gt != null)
            {
                DrawColor = gt.TeamColor();
            }
            Vector2 Position = (base.Parent[ComponentType.Game_Position] as Game_Position).Position + offset;
            string data = _ReturnsString();
            p_SpriteBatch.DrawString(_font, data, (Position - new Vector2(p_Screen.X, p_Screen.Y ) - new Vector2(data.Length * 6 ,0)), DrawColor,0.0f,Vector2.Zero,1.0f,SpriteEffects.None,(Parent[ComponentType.DrawLayer] as DrawLayer).Layer);
        }
    }
}
