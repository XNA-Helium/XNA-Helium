
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    public enum Team{NoTeam,Team1,Team2,Team3,Team4,NoOneLeft};

    class TeamManager
    {

        protected String[] TeamNameStrings;

        protected List<Pair<Team, Color>> _Teams;
        protected System.Collections.Hashtable ht;
        protected static TeamManager _Instance;

        public static TeamManager Instance
        {
            get
            {
                if (_Instance == null)
                {
                    _Instance = new TeamManager();
                }
                return _Instance;
            }
        }

        protected TeamManager()
        {
            TeamNameStrings = new string[5];
            ht = new System.Collections.Hashtable();
            _Teams = new List<Pair<Team, Color>>(5);
            
            _Teams.Add(new Pair<Team, Color>(Team.NoTeam, Color.White));
            _Teams.Add(new Pair<Team, Color>(Team.Team1, Color.Cyan));
            _Teams.Add(new Pair<Team, Color>(Team.Team2, Color.Pink));
            _Teams.Add(new Pair<Team, Color>(Team.Team3, Color.LightGreen));
            _Teams.Add(new Pair<Team, Color>(Team.Team4, new Color(255, 255, 100)));
            
            _Teams[0] = (new Pair<Team, Color>(Team.NoTeam, Color.White));
            _Teams[1] = (new Pair<Team, Color>(Team.Team1, Color.Cyan));
            _Teams[2] = (new Pair<Team, Color>(Team.Team2, Color.Pink));
            _Teams[3] = (new Pair<Team, Color>(Team.Team3, Color.LightGreen));
            _Teams[4] = (new Pair<Team, Color>(Team.Team4, new Color (255,255,100)));

            for(int i = 0; i < 5; ++i)
            {
                TeamNameStrings[i] = (string)((Team)i).ToString();
            }
        }

        public void ResetTeams()
        {
            for (int i = 0; i < 5; ++i)
            {
                TeamNameStrings[i] = (string)((Team)i).ToString();
            }
        }

        public void SetString(String data, Team index)
        {
            lock (TeamNameStrings)
            {
                TeamNameStrings[(int)index] = data;
            }
        }

        public void LoadContent()
        {
            ht[Team.Team1] = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/MiniMap/Team1");
            ht[Team.Team2] = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/MiniMap/Team2");
            ht[Team.Team3] = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/MiniMap/Team3");
            ht[Team.Team4] = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/MiniMap/Team4");
            PContentManager.Instance.Load<Texture2D>(@"Content/Art/MiniMap/MiniMapYou");
        }

        public string GetTeamString(Team index)
        {
            return TeamNameStrings[(int)index];
        }

        public Texture2D GetTexture(Team team){
            return (Texture2D) ht[team];
        }


        public Team GetTeam(Color color)
        {
            for (int i = 0; i < _Teams.Count; i++)
            {
                if (_Teams[i].Second == color)
                {
                    return _Teams[i].First;
                }
            }
            return Team.NoTeam;
        }

        public Color GetTeam(Team Name)
        {
            for (int i = 0; i < _Teams.Count; i++)
            {
                if (_Teams[i].First == Name)
                {
                    return _Teams[i].Second;
                }
            }
            return Color.White;
        }

        public int GetTeamNumber(Team name)
        {
            for (int i = 0; i < _Teams.Count; i++)
            {
                if (_Teams[i].First == name)
                {
                    return i;
                }
            }
            return -1;
        }

        public int GetMaxTeams()
        {
            return _Teams.Count;
        }
    }

    [Serializable]
    public class Game_Team : Component
    {
        Team _team;
        Color color;

        public Game_Team(Team Team)
        {
            base._Type = ComponentType.Game_Team;
            _team = Team;
            color = TeamManager.Instance.GetTeam(_team);
        }

        public Team Team
        {
            get
            {
                return _team;
            }
            set
            {
                _team = value;
                color = TeamManager.Instance.GetTeam(_team);
            }
        }


        public Color TeamColor()
        {
            return color;
        }

    }
}
