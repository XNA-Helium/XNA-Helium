
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    [Serializable]
    class Game_Velocity_Limiting : Component
    {
        Vector2 _MaxVelocity;
        public Game_Velocity_Limiting(Vector2 p_MaxVelocity)
        {
            base._Type = ComponentType.Game_Velocity_Limiting;
            _MaxVelocity = p_MaxVelocity;
            //prevent base velocity from going beyond...
        }

        public Vector2 MaxVelocity
        {
            get
            {
                return _MaxVelocity;
            }
        }
    }
}
