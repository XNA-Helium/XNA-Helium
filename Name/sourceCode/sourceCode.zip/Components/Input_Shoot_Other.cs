
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{

    [Serializable]
    class Input_Shoot_Other : Input_Shoot
    {
        const int Energy = 425;
        float TotalEnergy;
        public float Totalenergy
        {
            get
            {
                return TotalEnergy; ;
            }
        }
 
        public override bool CanShoot
        {
            get
            {
                return _CanShoot;
            }
            set
            {
                if (value)
                {
                    TotalEnergy = Energy;
                }
                _CanShoot = value;
            }
        }
        public Input_Shoot_Other():base()
        {
            TotalEnergy = Energy;
        }


        public override void ProcessGamePad(PlayerIndex p_Index)
        {
            GamePad gp = PInput.Instance.GamePad(p_Index);
            if (Shooting)
            {
                if (gp.B.SinglePress)
                {
                    shooting = false;
                    Done();
                    if(TotalEnergy == 225)
                    {
                        this._CanShoot = true;
                    }
                }
            }else{
                if (gp.A.SinglePress)
                {
                    shooting = true;
                    ShowLauncher();
                }
            }
            if (TotalEnergy <= 0.0f)
            {
                shooting = false;
                Done();
            }
            if (shooting)
            {
                {
                    Vector2 ParentPosition = ((base.Parent as WeaponObject).Player[ComponentType.Game_Position] as Game_Position).Position;
                    int MinHeight = Game1.Instance.GameManager.Level.Terrain[(int)ParentPosition.X] - ((base.Parent as WeaponObject).Player[ComponentType.Collidable] as Collidable).Height;
                    if(ParentPosition.Y > MinHeight)
                    {
                        ((base.Parent as WeaponObject).Player[ComponentType.Game_Position] as Game_Position).Y = MinHeight;
                        ((base.Parent as WeaponObject).Player[ComponentType.Settled_Ground] as Settled_Ground).Settled = false;
                        ((base.Parent as WeaponObject).Player[ComponentType.Game_Velocity] as Game_Velocity).Y = 0.0f;
                    }
                }
                if (gp.LeftStick.Y > 0.0f)
                {
                    ((base.Parent as WeaponObject).Player[ComponentType.Game_Velocity] as Game_Velocity).Y -= 0.55f;// *gp.LeftStick.Y;
                    TotalEnergy -= 0.55f;// *gp.LeftStick.Y;
                    (base.Parent as JetPack).SetAnimation("JetPackActive");
                }
                else if(gp.LeftStick.Y < -0.25f)
                {
                    if (!((base.Parent as WeaponObject).Player[ComponentType.Settled_Ground] as Settled_Ground).Settled)
                    {
                        ((base.Parent as WeaponObject).Player[ComponentType.Game_Velocity] as Game_Velocity).Y -= 0.2f;
                        TotalEnergy -= 0.2f;
                        (base.Parent as JetPack).SetAnimation("JetPackActive");
                    }
                }else
                {
                    if ( !( (base.Parent as WeaponObject).Player[ComponentType.Settled_Ground] as Settled_Ground ).Settled  )
                    {
                        ((base.Parent as WeaponObject).Player[ComponentType.Game_Velocity] as Game_Velocity).Y -= 0.475f;
                        TotalEnergy -= 0.475f;
                        (base.Parent as JetPack).SetAnimation("JetPackActive");
                    }
                }
                if (gp.LeftStick.X != 0.0f)
                {
                    float x = 1.0f;
                    if(gp.LeftStick.X < 0.0f)
                    {
                        x = -1.0f;
                        Drawable_Sprite_Animated dsa = ((base.Parent as JetPack).Player[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated);
                        ((base.Parent as JetPack).Player[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Left;
                        if (dsa.CurrentlyPlaying != "Idle" + (base.Parent as JetPack).Player.GetFacing())
                        {
                            dsa.SetCurrentAnimation("Idle" + (base.Parent as JetPack).Player.GetFacing());
                        }
                    }else{
                        Drawable_Sprite_Animated dsa = ((base.Parent as JetPack).Player[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated);
                        ((base.Parent as JetPack).Player[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Right;
                        if (dsa.CurrentlyPlaying != "Idle" + (base.Parent as JetPack).Player.GetFacing())
                        {
                            dsa.SetCurrentAnimation("Idle" + (base.Parent as JetPack).Player.GetFacing());
                        }
                    }
                    ((base.Parent as WeaponObject).Player[ComponentType.Game_Velocity] as Game_Velocity).X += 0.1f * x;
                    TotalEnergy -= 0.5f; // *gp.LeftStick.X;
                    (base.Parent as JetPack).SetAnimation("JetPackActive");
                }
            }
        }

#if !ZUNE
        public override void ProcessKeyboard()
        {
            if (PInput.Instance.Keyboard.Q.SinglePress)
            {
                shooting = !shooting;
                if (shooting)
                {
                    ShowLauncher();
                }else{
                    Done();
                    if (TotalEnergy == 225)
                    {
                        this._CanShoot = true;
                    }
                }
            }
            if (TotalEnergy <= 0.0f)
            {
                shooting = false;
                Done();
            }
            if (shooting)
            {
                if (PInput.Instance.Keyboard.W.State == InputWrapper.ButtonState.Held)
                {
                    ((base.Parent as WeaponObject).Player[ComponentType.Game_Velocity] as Game_Velocity).Y -= 0.75f;
                    TotalEnergy -= 0.75f;
                    (base.Parent as JetPack).SetAnimation("JetPackActive");
                }else{
                    if(!((base.Parent as WeaponObject).Player[ComponentType.Settled_Ground] as Settled_Ground).Settled)
                    {
                        ((base.Parent as WeaponObject).Player[ComponentType.Game_Velocity] as Game_Velocity).Y -= 0.25f;
                        TotalEnergy -= 0.25f;
                        (base.Parent as JetPack).SetAnimation("JetPackActive");
                    }
                }
                if (PInput.Instance.Keyboard.A.State == InputWrapper.ButtonState.Held)
                {
                    ((base.Parent as WeaponObject).Player[ComponentType.Game_Velocity] as Game_Velocity).X -= 0.75f;
                    TotalEnergy -= 0.75f;

                    Drawable_Sprite_Animated dsa = ((base.Parent as JetPack).Player[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated);
                    ((base.Parent as JetPack).Player[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Left;
                    if (dsa.CurrentlyPlaying != "Idle" + (base.Parent as JetPack).Player.GetFacing())
                    {
                        dsa.SetCurrentAnimation("Idle" + (base.Parent as JetPack).Player.GetFacing());
                    }

                    (base.Parent as JetPack).SetAnimation("JetPackActive");
                } /*
                if (PInput.Instance.Keyboard.S.State == InputWrapper.ButtonState.Held)
                {
                    ((base.Parent as WeaponObject).Player[ComponentType.Game_Velocity] as Game_Velocity).Y += 1.33f;
                    TotalEnergy -= 1.33f;
                    (base.Parent as JetPack).SetAnimation("JetPackActive");
                } */
                if (PInput.Instance.Keyboard.D.State == InputWrapper.ButtonState.Held)
                {
                    ((base.Parent as WeaponObject).Player[ComponentType.Game_Velocity] as Game_Velocity).X += 0.75f;
                    TotalEnergy -= 0.75f;

                    Drawable_Sprite_Animated dsa = ((base.Parent as JetPack).Player[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated);
                    ((base.Parent as JetPack).Player[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Right;
                    if (dsa.CurrentlyPlaying != "Idle" + (base.Parent as JetPack).Player.GetFacing())
                    {
                        dsa.SetCurrentAnimation("Idle" + (base.Parent as JetPack).Player.GetFacing());
                    }

                    (base.Parent as JetPack).SetAnimation("JetPackActive");
                }
            }
        }
#endif

        void Done()
        {
            ((Parent as WeaponObject).Player[ComponentType.Holder_Weapon] as Holder_Weapon).IsActive = false;
            ((Parent as WeaponObject).Player[ComponentType.Collidable] as Collidable).Moving = true;
            Vector2 position = ((Parent as WeaponObject).Player[ComponentType.Game_Position] as Game_Position).Position;
            float height = ((Parent as WeaponObject).Player[ComponentType.Collidable] as Collidable).Height;
            position.Y = Game1.Instance.GameManager.Terrain[(int)position.X] - (0.5f * height);
            ((Parent as WeaponObject).Player[ComponentType.Game_Position] as Game_Position).Position = position;
            shooting = false;
            (Game1.Instance.GameManager as GameManagerTeamedInterface).SetCanChangeTeam(true);
            if (((Parent as WeaponObject).Player[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Left)
            {
                ((Parent as WeaponObject).Player[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("IdleLeft", "IdleLeft");
            }
            if (((Parent as WeaponObject).Player[ComponentType.Game_Facing] as Game_Facing).Facing == Facing.Right)
            {
                ((Parent as WeaponObject).Player[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("IdleRight", "IdleRight");
            }
            if ((Parent as WeaponObject).HasRod)
            {
                Game1.Instance.GameManager.RemoveFromSceneGraph((Parent as WeaponObject).Rod);
                (Parent as WeaponObject).Rod = null;
            }
            this._CanShoot = false;
        }

        public override void Init()
        {
            base.Init();
        }
    }
}
