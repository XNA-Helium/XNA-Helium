
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    [Serializable]
    class Drawable_Sprite_Static : DrawableComponent
    {
        //requres Drawable component
        //manipulates Drawable compnent
        public Drawable_Sprite_Static(Texture2D p_Sprite)
        {
            base._Type = ComponentType.Drawable_Sprite_Static;
            base._CurrentTexture = p_Sprite;
            base.origin = new Vector2(p_Sprite.Width/2.0f, p_Sprite.Height/2.0f);
        }
    }
}
