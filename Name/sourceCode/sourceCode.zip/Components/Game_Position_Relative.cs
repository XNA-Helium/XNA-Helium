#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    [Serializable]
    public class Game_Position_Relative :Component
    {
        Vector2 _Offset;
        GameObject _Relative_Object;
        public Game_Position_Relative(GameObject Relative_Object)
        {
            _Offset = new Vector2(0.0f, 0.0f);
            _Relative_Object = Relative_Object;
            base._Type = ComponentType.Game_Position_Relative;
            if (Relative_Object[ComponentType.Game_Position] == null)
            {
                throw new Exception("Must have Game_Position component on Relative Object for Game_Position_Relative component");
            }
            if (Relative_Object[ComponentType.Game_Position_Relative] != null)
            {
                throw new Exception("Can't have 2 layers of Relativity");
            }
        }
        public Game_Position_Relative(GameObject Relative_Object,Vector2 p_Offset)
        {
            _Offset = new Vector2(p_Offset.X, p_Offset.Y);
            _Relative_Object = Relative_Object;
            base._Type = ComponentType.Game_Position_Relative;
            if (Relative_Object[ComponentType.Game_Position_Relative] != null)
            {
                throw new Exception("Must have Game_Position component on Relative Object for Game_Position_Relative component");
            }
            if (Relative_Object[ComponentType.Game_Position_Relative] != null)
            {
                throw new Exception("Can't have 2 layers of Relativity");
            }
        }
        public Game_Position_Relative(GameObject Relative_Object,float p_x, float p_y)
        {
            _Offset = new Vector2(p_x, p_y);
            _Relative_Object = Relative_Object;
            base._Type = ComponentType.Game_Position_Relative;
            if (Relative_Object[ComponentType.Game_Position_Relative] != null)
            {
                throw new Exception("Must have Game_Position component on Relative Object for Game_Position_Relative component");
            }
            if (Relative_Object[ComponentType.Game_Position_Relative] != null)
            {
                throw new Exception("Can't have 2 layers of Relativity");
            }
        }
        public float X
        {
            get
            {
                return _Offset.X;
            }
            set
            {
                _Offset.X = value;
            }
        }
        public float Y
        {
            get
            {
                return _Offset.Y;
            }
            set
            {
                _Offset.Y = value;
            }
        }
        public Vector2 Offset
        {
            get
            {
                return _Offset;
            }
            set
            {
                _Offset = value;
            }
        }
        public override void Update(GameTime p_time) 
        { 
            (base.Parent[ComponentType.Game_Position] as Game_Position).Position = (_Relative_Object[ComponentType.Game_Position] as Game_Position).Position + _Offset;
        }


        public override void Init()
        {
        }
    }
}