#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{

    [Serializable]
    class Game_Damage_Radial : Component
    {
        protected int _Damage;
        protected int _Radius;

        public Game_Damage_Radial()
        {
            base._Type = ComponentType.Game_Damage;
            _Damage = 100;
            _Radius = 25;
        }

        public Game_Damage_Radial(int Damage, int Radius)
        {
            _Damage = Damage;
            _Radius = Radius;
        }

        public int Damage
        {
            get
            {
                return _Damage;
            }
            set
            {
                _Damage = value;
            }
        }
        public int Radius
        {
            get
            {
                return _Radius;
            }
            set
            {
                _Radius = value;
            }
        }

        public int DamageFromRadius(GameObject Collider)
        {
            Vector2 temp = (base.Parent[ComponentType.Game_Position] as Game_Position).Position;
            temp -= (Collider[ComponentType.Game_Position] as Game_Position).Position;
            float value = 1 - temp.Length() / _Radius;
            return (int)((float)Damage * value);
        }
    }
}
