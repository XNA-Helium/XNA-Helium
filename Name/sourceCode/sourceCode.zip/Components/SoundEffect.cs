
#region Using Statements
using System;
using System.Collections.Generic;
////using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    //this is the Animal type that the Collidable_Animal can collide against

    [Serializable]
    class SoundEffect : Component
    {
        System.Collections.Hashtable effects =new System.Collections.Hashtable();
        public SoundEffect()
        {
        }
        public void AddSoundEffect(string name,SoundEffectInstance effect)
        {
            effects[name] = effect;
        }
        public void Player(string name)
        {
            if(effects.Contains(name))
                (effects[name] as SoundEffectInstance).Play();
        }
    }
}