#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    public delegate void AlterSomething(GameObject Collider);

    [Serializable]
    class CollisionCallback : Component
    {
        AlterSomething _callback;
        public CollisionCallback(AlterSomething p_Delegate)
        {
            base._Type = ComponentType.CollisionCallback;
            _callback = p_Delegate;
        }

        public void OnCollision(GameObject p_Collider)
        {
            _callback.Invoke(p_Collider);
        }
    }
}
