
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    public interface Networkable
    {
        bool HasUpdates();

        void Read(PNetworkStream p_Stream);
        //if there are updates
        //[int component enum] 
        //[int number of values]
        // PNetwork
        //[int = -1 your done with this component]

        void Write(PNetworkStream p_Stream);
        //if there are updates
        //[int component enum] 
        //[int = -1 your done with this component]   

    }
}
