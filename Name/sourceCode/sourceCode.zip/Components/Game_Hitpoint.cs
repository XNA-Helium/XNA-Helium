#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Net;
#endregion

namespace Pauliver
{

    [Serializable]
    class Game_Hitpoints : Component
    {
        public const short SETHITPOINTS = 0x70;
        protected int _Hitpoints;
        protected int _SpawnHitpoints;

        public Game_Hitpoints()
        {
            base._Type = ComponentType.Game_Hitpoint;
            _Hitpoints = 100;
            _SpawnHitpoints = 100;
        }

        public Game_Hitpoints(int SpawnHitpoints)
        {
            base._Type = ComponentType.Game_Hitpoint;
            _Hitpoints = SpawnHitpoints;
            _SpawnHitpoints = SpawnHitpoints;
        }

        public string GetHitpoints()
        {
            return "" + _Hitpoints;
        }

        public int Hitpoints
        {
            get 
            {
                return _Hitpoints; 
            }
            set
            {
                if (NetworkManager.IsUsed)
                {
                    if ((Game1.Instance.GameManager as GameManagerTeamedInterface).MyMachineIsActive())
                    {
                        _Hitpoints = value;
                        PacketWriter pw = new PacketWriter();
                        pw.Write(SETHITPOINTS);
                        int id = Game1.Instance.GameManager.GetIndex(Parent);
                        pw.Write(id);
                        pw.Write(_Hitpoints);
                        NetworkManager.Instance.SendToAll(pw);
                    }else{

                    }
                }
                else
                {
                    _Hitpoints = value;
                }
            }
        }

        public void NetworkSetHitpoints(int NewHitpoints)
        {
            if(NetworkManager.IsUsed)
            {
                _Hitpoints = NewHitpoints;
            }else{
                System.Diagnostics.Debug.Assert(false, "only call this when network is used");
            }
        }

        public float HitpointRatio
        {
            get
            {
                return (float)_Hitpoints / (float)_SpawnHitpoints;
            }
        }

        public void ResetHitpoints()
        {
            _Hitpoints = _SpawnHitpoints;
        }
    }
}
