
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    [Serializable]
    public class DrawableComponent :  Component
    {
        protected Texture2D _CurrentTexture;
        protected Vector2 origin;
        
        public Texture2D GetTexture
        {
            get
            {
                return _CurrentTexture;
            }
        }

        public DrawableComponent()
        {
            base._Type = ComponentType.Drawable;
        }



        float DrawLayer = 0.5f;
        protected DrawLayer dl;
        protected Color DrawColor;
        protected Game_Team gt;
        protected Vector2 position;
        Rectangle target;
        public virtual void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            //float Scale = 1.0f;

            dl = (base.Parent[ComponentType.DrawLayer] as DrawLayer);
            if (base.Parent[ComponentType.DrawLayer] != null)
            {
                DrawLayer = dl.Layer;
            }

            DrawColor = Color.White;
            gt = (Parent[ComponentType.Game_Team] as Game_Team);
            if (gt != null)
            {
                DrawColor = gt.TeamColor();
            }

            //@@ don't do a rectangle based intersection query it will fail you
            position = (base.Parent[ComponentType.Game_Position] as Game_Position).Position;
            target = new Rectangle((int)position.X - p_Screen.X, (int)position.Y - p_Screen.Y, _CurrentTexture.Width, _CurrentTexture.Height);
            p_SpriteBatch.Draw(_CurrentTexture, target, null, DrawColor, (base.Parent[ComponentType.Game_Rotation] as Game_Rotation).Rotation, origin, SpriteEffects.None, DrawLayer);
        }

        public override void Init()
        {
        }
    }

}