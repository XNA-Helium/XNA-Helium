
#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    class GravityManager
    {
        private static GravityManager _Instance;
        private Vector2 _Gravity;
        public static GravityManager Instance
        {
            get
            {
                if (_Instance == null)
                {
                    _Instance = new GravityManager();
                }
                return _Instance;
            }
        }

        private GravityManager()
        {
            _Gravity = new Vector2(0,0.5f);
        }

        public Vector2 Gravity
        {
            get
            {
                return _Gravity;
            }
            internal set
            {
                _Gravity = value;
            }
        }
    }

    class Affectable_Gravity : Component
    {
        public Affectable_Gravity()
        {
            base._Type = ComponentType.Affectable_Gravity;
        }
        public override void Update(GameTime p_time)
        {
            {
                Settled_Ground sg = (base.Parent[ComponentType.Settled_Ground] as Settled_Ground);
                if (sg != null && sg.Settled)
                {
                    return;
                }
            }
            {
                Collidable c = (base.Parent[ComponentType.Collidable] as Collidable);
                if (c != null)
                {
                    c.Moving = true;
                }
            }

            (base.Parent[ComponentType.Game_Velocity] as Game_Velocity).Velocity += GravityManager.Instance.Gravity; // * p_time ?
        }
        public Vector2 Gravity
        {
            get
            {
                return GravityManager.Instance.Gravity;
            }
        }
    }

}