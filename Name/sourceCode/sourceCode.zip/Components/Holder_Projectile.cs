
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    [Serializable]
    class Holder_Projectile : Component
    {
        GameObject _Projectile;
        public Holder_Projectile(GameObject Projectile)
        {
            base._Type = ComponentType.Holder_Projectile;
            _Projectile = Projectile;
        }

        public GameObject Projectile
        {
            get
            {
                return _Projectile;
            }
        }
    }
}

	//a weapon has a Projectile HOlder
	//a new projectile of this type is spawned when need be [when its fired]