
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    [Serializable]
    abstract class Input : Component
    {
        

        public Input()
        {
            base._Type = ComponentType.Input;
            //Microsoft.Xna.Framework.Input
        }

        public virtual void ProcessInput(PlayerIndex p_PlayerIndex)
        {
            if (base.Parent[ComponentType.Input_Keyboard] != null)
            {

#if !ZUNE
                ProcessKeyboard();
#endif
            }
            if (base.Parent[ComponentType.Input_GamePad] != null)
            {
                ProcessGamePad(p_PlayerIndex);
            }
        }

#if !ZUNE
        public abstract void ProcessKeyboard();
#endif
        public abstract void ProcessGamePad(PlayerIndex p_PlayerIndex);

    }
}
