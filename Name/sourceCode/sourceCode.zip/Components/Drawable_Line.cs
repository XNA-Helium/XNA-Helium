
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    public delegate List<Pair<Vector2,Vector2>> GetPoints();

    [Serializable]
    class Drawable_Line : DrawableComponent
    {
        protected GetPoints _Delegate;
        protected Color _Color;

        public Drawable_Line(Color color,GetPoints PointDelegate)
        {
            base._Type = ComponentType.Drawable_Line;
            _Delegate = PointDelegate;
            _Color = color;
            base._CurrentTexture = PContentManager.Instance.GetObject<Texture2D>("1WhitePixel");
            System.Diagnostics.Debug.Assert(false);
            //ALL the code to make this work is here
            //its just not used so I commented it out
        }
        public override void Update(GameTime p_time)
        {
        }
        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            List<Pair<Vector2,Vector2>> Points = _Delegate.Invoke();

            foreach (Pair<Vector2,Vector2> Point in Points)
            {
                if (p_Screen.Contains(new Point((int)Point.First.X, (int)Point.First.Y)) || p_Screen.Contains(new Point((int)Point.Second.X, (int)Point.Second.Y)))
                {
                    //box comparison
                    Vector2 Origin = new Vector2(base._CurrentTexture.Width / 2, 0.0f);
                    Vector2 diff = Point.Second - Point.First;
                    float angle;
                    Vector2 Scale = new Vector2(1.0f, diff.Length());

                    angle = (float)(Math.Atan2(diff.Y, diff.X)) - MathHelper.PiOver2;

                    p_SpriteBatch.Draw(base._CurrentTexture, Point.First, null, _Color, angle, Origin, Scale, SpriteEffects.None, 0.1f);
                }
            }
        }
    }
}
