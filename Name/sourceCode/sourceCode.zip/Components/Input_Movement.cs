
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    [Serializable]
    class Input_Movement : Input
    {
        public Input_Movement()
        {
            base._Type = ComponentType.Input_Movement;
        }
        public override void ProcessInput(PlayerIndex p_PlayerIndex)
        {
            {
               //if we have a weapon that we want to try and shoot
               Holder_Weapon ho;
               if(Parent.GetComponent<Holder_Weapon>(ComponentType.Holder_Weapon,out ho))
               {
                   Input_Shoot i = (ho.Weapon[ComponentType.Input_Shoot] as Input_Shoot);
                   if(i != null)
                   {
                       if(i.CanShoot && !i.Shooting)
                       {
                           i.ProcessInput(p_PlayerIndex);
                           if(i.Shooting)
                           {
                               return;
                           }

                       }else if(i.Shooting)
                       {
                           i.ProcessInput(p_PlayerIndex);
                            return;
                       }
                   }
               }
            }
            {
                Settled_Ground sg;
                if (Parent.GetComponent<Settled_Ground>(ComponentType.Settled_Ground, out sg))
                {
                    if (!sg.Settled)
                    {
                        return;
                    }
                }
            }
            base.ProcessInput(p_PlayerIndex);
        }     
        public override void ProcessGamePad(PlayerIndex p_PlayerIndex)
        {
            Vector2 Ls = new Vector2(PInput.Instance.GamePad(p_PlayerIndex).LeftStick.X, PInput.Instance.GamePad(p_PlayerIndex).LeftStick.Y);
            Vector2 Position = ( Ls * new Vector2(2.0f, -2.0f));
            {
                Drawable_Sprite_Animated dsa = (Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated);
                if (Position.X != 0)
                {
                    string Direction = "";
                    if (Position.X > 0)
                    {
#if ZUNE
                        Position.X = 2.0f;
#endif
                        Direction = "WalkRight";
                    }
                    else if (Position.X < 0)
                    {
#if ZUNE
                        Position.X = -2.0f;
#endif
                        Direction = "WalkLeft";
                    }

                    if (dsa.CurrentlyPlaying != Direction)
                    {
                        dsa.SetCurrentAnimation(Direction);
                    }

                    if (base.Parent[ComponentType.Collidable] != null)
                    {
                        (base.Parent[ComponentType.Collidable] as Collidable).Moving = true;
                    }
                    Game_Position gp = (base.Parent[ComponentType.Game_Position] as Game_Position);
                    gp.Position += Position;
                }
                else
                {
                    if (dsa.CurrentlyPlaying == "WalkRight")
                    {
                        dsa.SetCurrentAnimation("IdleRight");
                        (Parent[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Right;
                    }
                    else if (dsa.CurrentlyPlaying == "WalkLeft")
                    {
                        dsa.SetCurrentAnimation("IdleLeft");
                        (Parent[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Left;
                    }

                }
            }
        }

#if WINDOWS
        public override void ProcessKeyboard()
        {
            KeyboardState ks = Microsoft.Xna.Framework.Input.Keyboard.GetState();
            Keys[] keys = ks.GetPressedKeys();
            Vector2 Position = new Vector2(0.0f, 0.0f);
            bool Jumping = false;
            bool Walking = false;
            String Direction = "";

            if(PInput.Instance.Keyboard.W.State == InputWrapper.ButtonState.Held)
            {
                Position += new Vector2(0.0f, -1.0f);
            }
            if(PInput.Instance.Keyboard.A.State == InputWrapper.ButtonState.Held)
            {    
                Walking = true;
                Direction = "Left";
                (Parent[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Left;
                Position += new Vector2(-1.0f, 0.0f);
            }
            if(PInput.Instance.Keyboard.S.State == InputWrapper.ButtonState.Held)
            {    
                Position += new Vector2(0.0f, 1.0f);
            }
            if(PInput.Instance.Keyboard.D.State == InputWrapper.ButtonState.Held)
            {    
                Walking = true;
                Direction = "Right";
                (Parent[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Right;
                Position += new Vector2(1.0f, 0.0f);
            }
            if(PInput.Instance.Keyboard.Space.SinglePress)
            {    
                Jumping = true;
            }

            if (Jumping)
            {
                if (Parent[ComponentType.Game_Velocity] != null)
                {
                    (Parent[ComponentType.Game_Velocity] as Game_Velocity).Velocity += new Vector2(Position.X * 1.0f,-12.0f);
                    //play Jump Animation
                    if ((Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).CurrentlyPlaying == "WalkRight")
                    {
                        (Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("IdleRight");
                        (Parent[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Right;
                    }
                    else if ((Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).CurrentlyPlaying == "WalkLeft")
                    {
                        (Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("IdleLeft");
                        (Parent[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Left;
                    }
                }
            }else if (Position != Vector2.Zero)
            {
                if (Walking)
                {
                    if ((Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).CurrentlyPlaying != "Walk" + Direction)
                    {
                        (Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("Walk" + Direction);//,"Idle" + Direction);
                    }
                }
                else
                {
                    if ((Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).CurrentlyPlaying == "WalkRight")
                    {
                        (Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("IdleRight");
                        (Parent[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Right;
                    }
                    else if ((Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).CurrentlyPlaying == "WalkLeft")
                    {
                        (Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("IdleLeft");
                        (Parent[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Left;
                    }
                    
                }

                if (base.Parent[ComponentType.Collidable] != null)
                {
                    (base.Parent[ComponentType.Collidable] as Collidable).Moving = true;
                }
                Game_Position gp = (base.Parent[ComponentType.Game_Position] as Game_Position);
                gp.Position += Position;
            }
            else
            {
                if ((Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).CurrentlyPlaying == "WalkRight")
                {
                    (Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("IdleRight");
                    (Parent[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Right;
                }
                else if ((Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).CurrentlyPlaying == "WalkLeft")
                {
                    (Parent[ComponentType.Drawable_Sprite_Animated] as Drawable_Sprite_Animated).SetCurrentAnimation("IdleLeft");
                    (Parent[ComponentType.Game_Facing] as Game_Facing).Facing = Facing.Left;
                }
            }
        }
#endif
    }
}
