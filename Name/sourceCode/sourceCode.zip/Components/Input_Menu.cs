
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    [Serializable]
    class Input_Menu : Input
    {
        public Input_Menu()
        {
            base._Type = ComponentType.Input_Menu;
        }
        public override void Update(GameTime p_time)
        {
            base.Update(p_time);
        }

        public override void ProcessInput(PlayerIndex p_PlayerIndex)
        {
            base.ProcessInput(p_PlayerIndex);
        }

        public override void ProcessGamePad(PlayerIndex p_PlayerIndex)
        {
            if(PInput.Instance.GamePad(p_PlayerIndex).B.SinglePress)
                Game1.Instance.AddMenu(new WeaponSelectionScreen(Parent as PlayerObject));
        }
#if !ZUNE
        public override void ProcessKeyboard()
        {
            if(PInput.Instance.Keyboard.E.SinglePress)
                Game1.Instance.AddMenu(new WeaponSelectionScreen(Parent as PlayerObject));
        }
#endif
        public override void Init()
        {
            base.Init();
        }
    }
}
