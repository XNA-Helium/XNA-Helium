#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{

    [Serializable]
    public class Game_Position : Component
    {
        Vector2 _position;

        public Game_Position()
        {
            base._Type = ComponentType.Game_Position;
            _position = new Vector2(0.0f, 0.0f);
        }
        public Game_Position(Vector2 p_Position)
        {
            base._Type = ComponentType.Game_Position;
            _position = new Vector2(p_Position.X, p_Position.Y);
        }
        public Game_Position(float p_x, float p_y)
        {
            base._Type = ComponentType.Game_Position;
            _position = new Vector2(p_x, p_y);
        }

        public float X
        {
            get
            {
                return _position.X;
            }
            set
            {
                _position.X = value;
            }
        }
        public float Y
        {
            get
            {
                return _position.Y;
            }
            set
            {
                _position.Y = value;
            }
        }
        public Vector2 Position
        {
            get
            {
                return _position;
            }
            set
            {
                _position = value;
            }
        }
    }
}