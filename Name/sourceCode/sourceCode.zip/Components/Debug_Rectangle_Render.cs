#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    [Serializable]
    class Debug_Rectangle_Render : Debug_Rectangle
    {
        DrawableComponent _Drawable;
        public Debug_Rectangle_Render(DrawableComponent dc)
            : base(Color.Yellow)
        {
            _Drawable = dc;
            base._Type = ComponentType.Debug_Rectangle_Render;
        }

        public override void Update(GameTime p_time)
        {
            base.Update(p_time);
            int width = _Drawable.GetTexture.Width;
            int height = _Drawable.GetTexture.Height;

            int x = (int)(base.Parent[ComponentType.Game_Position] as Game_Position).Position.X;
            int y = (int)(base.Parent[ComponentType.Game_Position] as Game_Position).Position.Y;


            base._DrawRectangle = new Rectangle(x, y, width, height);
        }
    }

}