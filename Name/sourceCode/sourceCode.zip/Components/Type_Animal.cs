
#region Using Statements
using System;
using System.Collections.Generic;
////using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    //this is the Animal type that the Collidable_Animal can collide against

    [Serializable]
    class Type_Animal : Component
    {
        public Type_Animal()
        {
            base._Type = ComponentType.Type_Animal;
        }
    }
}
