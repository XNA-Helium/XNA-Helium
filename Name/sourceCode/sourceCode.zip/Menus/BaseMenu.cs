

#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    public abstract class BaseMenu
    {
        protected UIBaseMenu _menu;
        public abstract void Draw(SpriteBatch p_spriteBatch, GameTime p_Time);
        public abstract void Update(GameTime p_Time);
        public abstract void ProccessInput(PlayerIndex p_index);
        public abstract void Back();
    }
}