#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{
    public class PlayerSelection : BaseMenu
    {
        Texture2D players_TExt;
        public PlayerSelection()
            : base()
        {
            PInput.Instance.ResetGamePads();
            _menu = new UIBaseMenu(@"Content/Art/GUI/MenuBackground", Vector2.Zero);
            players_TExt = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/GUI/Players");
            UIButton b = new UIButton(@"Content/Art/GUI/1p", new Vector2(20, 105));
            _menu.Add(OnePlayers, b);
            b = new UIButton(@"Content/Art/GUI/Back", new Vector2(20, 280));
            _menu.Add(Back, b);
            b = new UIButton(@"Content/Art/GUI/0p", new Vector2(20, 245));
            _menu.Add(ZeroPlayers, b);
            b = new UIButton(@"Content/Art/GUI/4p", new Vector2(20, 210));
            _menu.Add(FourPlayers, b);
            b = new UIButton(@"Content/Art/GUI/3p", new Vector2(20, 175));
            _menu.Add(ThreePlayers, b);
            b = new UIButton(@"Content/Art/GUI/2p", new Vector2(20, 140));
            _menu.Add(TwoPlayers, b);         
            _menu.Setup();
        }

        public override void Update(GameTime p_Time)
        {
            _menu.Update();
            _menu.ProcessInput(PlayerIndex.One); //only uncomment me if there are buttons
        }
        public override void ProccessInput(PlayerIndex p_index)
        {
            _menu.ProcessInput(p_index);
        }
        public override void Draw(SpriteBatch p_spriteBatch, GameTime p_Time)
        {
            _menu.Draw(p_spriteBatch, p_Time);
            p_spriteBatch.Draw(players_TExt, new Vector2(20, 80), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuButton));
        }

        public override void Back()
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu(new MainMenu());
        }
        protected void ZeroPlayers()
        {
            Game1.Instance.PopTopMenu();
            Triplet<Team, PlayerIndex, TeamType>[] teams = new Triplet<Team, PlayerIndex, TeamType>[0];
            Game1.Instance.AddMenu(new AISelection(teams));
        }
        protected void OnePlayers()
        {
            Game1.Instance.PopTopMenu();
            Triplet<Team, PlayerIndex, TeamType>[] teams = new Triplet<Team, PlayerIndex, TeamType>[1];
            teams[0] = new Triplet<Team, PlayerIndex, TeamType>(Team.Team1, PlayerIndex.One, TeamType.Local);
            Game1.Instance.AddMenu(new AISelection(teams));
        }
        protected void TwoPlayers()
        {
            Game1.Instance.PopTopMenu();
            Triplet<Team, PlayerIndex, TeamType>[] teams = new Triplet<Team, PlayerIndex, TeamType>[2];
            teams[0] = new Triplet<Team, PlayerIndex, TeamType>(Team.Team1, PlayerIndex.One, TeamType.Local);
            teams[1] = new Triplet<Team, PlayerIndex, TeamType>(Team.Team2, PlayerIndex.One, TeamType.Local);
            Game1.Instance.AddMenu(new AISelection(teams));
        }
        protected void ThreePlayers()
        {
            Game1.Instance.PopTopMenu();
            Triplet<Team, PlayerIndex, TeamType>[] teams = new Triplet<Team, PlayerIndex, TeamType>[3];
            teams[0] = new Triplet<Team, PlayerIndex, TeamType>(Team.Team1, PlayerIndex.One, TeamType.Local);
            teams[1] = new Triplet<Team, PlayerIndex, TeamType>(Team.Team2, PlayerIndex.One, TeamType.Local);
            teams[2] = new Triplet<Team, PlayerIndex, TeamType>(Team.Team3, PlayerIndex.One, TeamType.Local);
            Game1.Instance.AddMenu(new AISelection(teams));
        }
        protected void FourPlayers()
        {
            Game1.Instance.PopTopMenu();
            Triplet<Team, PlayerIndex, TeamType>[] teams = new Triplet<Team, PlayerIndex, TeamType>[4];
            teams[0] = new Triplet<Team, PlayerIndex, TeamType>(Team.Team1, PlayerIndex.One, TeamType.Local);
            teams[1] = new Triplet<Team, PlayerIndex, TeamType>(Team.Team2, PlayerIndex.One, TeamType.Local);
            teams[2] = new Triplet<Team, PlayerIndex, TeamType>(Team.Team3, PlayerIndex.One, TeamType.Local);
            teams[3] = new Triplet<Team, PlayerIndex, TeamType>(Team.Team4, PlayerIndex.One, TeamType.Local);
            Game1.Instance.AddMenu(new LevelSelection(teams));
        }
    }
}