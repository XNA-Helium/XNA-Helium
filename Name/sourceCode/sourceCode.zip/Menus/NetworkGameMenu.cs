﻿#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Net;
#endregion

namespace Pauliver
{
    public class NetworkGameMenu : BaseMenu
    {
        protected TerrainSaver lastts;

        public NetworkGameMenu()
            : base()
        {
            NetworkManager.Instance.Disconnect();

            _menu = new UIBaseMenu(@"Content/Art/GUI/MenuBackground", Vector2.Zero);
            UIButton b = new UIButton(@"Content/Art/GUI/Back", new Vector2(20, 175));
            _menu.Add(Back, b);
            SpriteFont sf = PContentManager.Instance.GetObject<SpriteFont>(@"Content/Art/Fonts/INVADER");
            _menu.AddUIElement( new UITextElement( new Vector2(20,245), sf, "Searching...") );
            _menu.Setup();

            NetworkManager.Instance.GetAvailableSessions(avsc);
        }

        void avsc(AvailableNetworkSessionCollection sessions)
        {
            if(sessions == null)
            {
                Back();
                return;
            }
            


            if (sessions.Count > 0)
            {
                lastts = new TerrainSaver();
                int[] data = new int[9];

                data[0] = (sessions[0].SessionProperties[0].Value % 100) - 25; // (oldValues[0] + 25) + ((oldValues[1] + 25) * 100);
                data[1] = (sessions[0].SessionProperties[0].Value / 100) - 25; // (oldValues[0] + 25) + ((oldValues[1] + 25) * 100);
                data[2] = (sessions[0].SessionProperties[1].Value % 100) - 25; // (oldValues[2] + 25) + ((oldValues[3] + 25) * 100);
                data[3] = (sessions[0].SessionProperties[1].Value / 100) - 25; // (oldValues[2] + 25) + ((oldValues[3] + 25) * 100);
                data[4] = (sessions[0].SessionProperties[2].Value % 100) - 25; // (oldValues[4] + 25) + ((oldValues[5] + 25) * 100);
                data[5] = (sessions[0].SessionProperties[2].Value / 100) - 25; // (oldValues[4] + 25) + ((oldValues[5] + 25) * 100);
                data[6] = (sessions[0].SessionProperties[3].Value % 100) - 25; // (oldValues[6] + 25) + ((oldValues[7] + 25) * 100);
                data[7] = (sessions[0].SessionProperties[3].Value / 100) - 25; // (oldValues[6] + 25) + ((oldValues[7] + 25) * 100);
                data[8] = (sessions[0].SessionProperties[4].Value);

                lastts.Values = data;

                NetworkManager.Instance.Connect(0, JoinCallback, sessions);
            }
            else
            {
                lastts = new TerrainSaver();

                System.Random rand = new Random();

                int s_hr = rand.Next(0, 11) * 5 - 25;
                int s_wr = rand.Next(0, 7) - 3; //width +-3
                int t_hr = rand.Next(0, 11) * 5 - 25;
                int t_wr = rand.Next(0, 5) - 2; //width +-2
                int n1_hr = rand.Next(0, 11) - 5;
                int n1_wr = rand.Next(0, 21) - 10; //width  +- 10
                int n2_hr = rand.Next(0, 11) - 5;
                int n2_wr = rand.Next(0, 11) - 5; //width +- 5

                int offset = (rand.Next(0, 41) - 20) * 10;

                lastts.Square_Height = s_hr;
                lastts.Square_Width = s_wr;
                lastts.Triangle_Height = t_hr;
                lastts.Triangle_Width = t_wr;
                lastts.Noise1_Height = n1_hr;
                lastts.Noise1_Width = n1_wr;
                lastts.Noise2_Height = n2_hr;
                lastts.Noise2_Width = n2_wr;
                lastts.Offset_From_Zero = offset;

                NetworkManager.Instance.StartServer(lastts.Values, HostCallback);
            }
        }


        public override void Update(GameTime p_Time)
        {
            _menu.Update();
            _menu.ProcessInput(PlayerIndex.One); //only uncomment me if there are buttons
        }
        public override void ProccessInput(PlayerIndex p_index)
        {
            _menu.ProcessInput(p_index);
        }
        public override void Draw(SpriteBatch p_spriteBatch, GameTime p_Time)
        {
            _menu.Draw(p_spriteBatch, p_Time);
        }
        public override void Back()
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu(new MainMenu());
        }


        public void JoinCallback(bool connected)
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu(new NetworkLobby(lastts, false));
        }

        public void HostCallback()
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu(new NetworkLobby(lastts, true));
        }

        protected void Join(TerrainSaver ts)
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu( new NetworkLobby(ts,false) );
        }
        protected void Host(TerrainSaver ts)
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu( new NetworkLobby(ts,true) );
        }
    }
}
