#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{

    class GameOver :BaseMenu
    {
        UITextElement _text;
        public GameOver(Team Team, bool FromNetwork)
            : base()
        {
            SpriteFont sf = PContentManager.Instance.GetObject<SpriteFont>(@"Content/Art/Fonts/INVADER");
            if (Team == Team.NoOneLeft)
            {
                _text = new UITextElement(new Vector2(38, 133), sf, "No One Left.", Color.White);
            }
            else
            {
                _text = new UITextElement(new Vector2(38, 133), sf, TeamManager.Instance.GetTeamString(Team) + " Wins!", TeamManager.Instance.GetTeam(Team));
            }
            _menu = new UIBaseMenu(@"Content/Art/GUI/GameOverBackground", Vector2.Zero);
            UIButton b = new UIButton(@"Content/Art/GUI/Exit", new Vector2(20, 245));
            _menu.Add(Back, b);
            if (!FromNetwork)
            {
                NetworkManager.Instance.RemoveAllCallbacks();
                NetworkManager.Instance.Disconnect();
            }
            b = new UIButton(@"Content/Art/GUI/Restart", new Vector2(20, 210));
            _menu.Add(StartOver, b);

            _menu.Setup();
        }
        public GameOver(Team Team): base()
        {
            SpriteFont sf = PContentManager.Instance.GetObject<SpriteFont>(@"Content/Art/Fonts/INVADER");
            if (Team == Team.NoOneLeft)
            {
                _text = new UITextElement(new Vector2(38,133), sf, "No One Left.", Color.White);
            }
            else
            {
                _text = new UITextElement(new Vector2(38, 133), sf, TeamManager.Instance.GetTeamString(Team) + " Wins!", TeamManager.Instance.GetTeam(Team));
            }
            _menu = new UIBaseMenu(@"Content/Art/GUI/GameOverBackground", Vector2.Zero);
            UIButton b = new UIButton(@"Content/Art/GUI/Exit", new Vector2(20, 245));
            _menu.Add(Back, b);
            b = new UIButton(@"Content/Art/GUI/Restart", new Vector2(20, 210));
            _menu.Add(StartOver, b);
             _menu.Setup();
        }
        public override void Draw(SpriteBatch p_spriteBatch, GameTime p_Time)
        {
            _menu.Draw(p_spriteBatch, p_Time);
            _text.Draw(p_spriteBatch, p_Time);
        }
        public override void ProccessInput(PlayerIndex p_index)
        {
            _menu.ProcessInput(p_index);
        }
        public override void Update(GameTime p_Time)
        {
            _menu.Update();
            _menu.ProcessInput(PlayerIndex.One);
#if !ZUNE
            _menu.ProcessInput(PlayerIndex.Two);
            _menu.ProcessInput(PlayerIndex.Three);
            _menu.ProcessInput(PlayerIndex.Four);
#endif
        }

        public override void Back()
        {
            TeamManager.Instance.ResetTeams();
            Game1.Instance.PopTopMenu();
            Game1.Instance.Exit();
        }
        public void StartOver()
        {
            TeamManager.Instance.ResetTeams();
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu(new MainMenu(false));
        }
    }
}
