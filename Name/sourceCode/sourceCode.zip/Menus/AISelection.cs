#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{
    public class AISelection : BaseMenu
    {
        Texture2D players_TExt;
        Triplet<Team, PlayerIndex, TeamType>[] teams;
        int CurrentPlayers;
        public AISelection(Triplet<Team, PlayerIndex, TeamType>[] p_teams)
            : base()
        {
            CurrentPlayers = p_teams.Length;
            teams = p_teams;
            PInput.Instance.ResetGamePads();
            _menu = new UIBaseMenu(@"Content/Art/GUI/MenuBackground", Vector2.Zero);
            players_TExt = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/GUI/AIPlayers");
            UIButton b = new UIButton(@"Content/Art/GUI/0p", new Vector2(20, 105));
            _menu.Add(ZeroAIPlayers, b);
            b = new UIButton(@"Content/Art/GUI/Back", new Vector2(20, 280));
            _menu.Add(Back, b);
            if (CurrentPlayers <= 0)
            {
                b = new UIButton(@"Content/Art/GUI/4p", new Vector2(20, 245));
                _menu.Add(FourAIPlayers, b);
            }
            if (CurrentPlayers <= 1)
            {
                b = new UIButton(@"Content/Art/GUI/3p", new Vector2(20, 210));
                _menu.Add(ThreeAIPlayers, b);
            }
            if (CurrentPlayers <= 2)
            {
                b = new UIButton(@"Content/Art/GUI/2p", new Vector2(20, 175));
                _menu.Add(TwoAIPlayers, b);
            }

            if (CurrentPlayers <= 3)
            {
                b = new UIButton(@"Content/Art/GUI/1p", new Vector2(20, 140));
                _menu.Add(OneAIPlayers, b);
            }
            if(CurrentPlayers <= 4)
            {
                Game1.Instance.PopTopMenu();
                Game1.Instance.AddMenu(new PlayerSelection());
            }
            _menu.Setup();
        }

        public override void Update(GameTime p_Time)
        {
            _menu.Update();
            _menu.ProcessInput(PlayerIndex.One); //only uncomment me if there are buttons
        }
        public override void ProccessInput(PlayerIndex p_index)
        {
            _menu.ProcessInput(p_index);
        }
        public override void Draw(SpriteBatch p_spriteBatch, GameTime p_Time)
        {
            _menu.Draw(p_spriteBatch, p_Time);
            p_spriteBatch.Draw(players_TExt, new Vector2(20, 80), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MenuButton));
        }
        public override void Back()
        {
            Game1.Instance.PopTopMenu();
            Game1.Instance.AddMenu(new PlayerSelection());
        }
        protected void ZeroAIPlayers()
        {
            if(teams.Length > 0)
            {
                Game1.Instance.PopTopMenu();
                Game1.Instance.AddMenu(new LevelSelection(teams));
            }
        }
        protected void OneAIPlayers()
        {
            Game1.Instance.PopTopMenu();
            Triplet<Team, PlayerIndex, TeamType>[] NewTeams = new Triplet<Team, PlayerIndex, TeamType>[1 + CurrentPlayers];
            PInput.Instance.SetFakeGamePad(2, PlayerIndex.Two);
            int i = 0;
            for(i = 0; i < CurrentPlayers; i++)
            {
                NewTeams[i] = teams[i];
            }
            NewTeams[i] = new Triplet<Team, PlayerIndex, TeamType>((Team)(i + 1), PlayerIndex.Two, TeamType.AI);
            i++;
            Game1.Instance.AddMenu(new LevelSelection(NewTeams));
        }
        protected void TwoAIPlayers()
        {
            Game1.Instance.PopTopMenu();
            Triplet<Team, PlayerIndex, TeamType>[] NewTeams = new Triplet<Team, PlayerIndex, TeamType>[2 + CurrentPlayers];
            PInput.Instance.SetFakeGamePad(2, PlayerIndex.Two);
            int i = 0;
            for (i = 0; i < CurrentPlayers; i++)
            {
                NewTeams[i] = teams[i];
            }
            NewTeams[i] = new Triplet<Team, PlayerIndex, TeamType>((Team)(i + 1), PlayerIndex.Two, TeamType.AI);
            i++;
            NewTeams[i] = new Triplet<Team, PlayerIndex, TeamType>((Team)(i + 1), PlayerIndex.Two, TeamType.AI);
            i++;
            Game1.Instance.AddMenu(new LevelSelection(NewTeams));
        }
        protected void ThreeAIPlayers()
        {
            Game1.Instance.PopTopMenu();
            Triplet<Team, PlayerIndex, TeamType>[] NewTeams = new Triplet<Team, PlayerIndex, TeamType>[3 + CurrentPlayers];
            PInput.Instance.SetFakeGamePad(2, PlayerIndex.Two);
            int i = 0;
            for (i = 0; i < CurrentPlayers; i++)
            {
                NewTeams[i] = teams[i];
            }
            NewTeams[i] = new Triplet<Team, PlayerIndex, TeamType>((Team)(i + 1), PlayerIndex.Two, TeamType.AI);
            i++;
            NewTeams[i] = new Triplet<Team, PlayerIndex, TeamType>((Team)(i + 1), PlayerIndex.Two, TeamType.AI);
            i++;
            NewTeams[i] = new Triplet<Team, PlayerIndex, TeamType>((Team)(i + 1), PlayerIndex.Two, TeamType.AI);
            i++;
            Game1.Instance.AddMenu(new LevelSelection(NewTeams));
        }
        protected void FourAIPlayers()
        {
            Game1.Instance.PopTopMenu();
            Triplet<Team, PlayerIndex, TeamType>[] NewTeams = new Triplet<Team, PlayerIndex, TeamType>[4 + CurrentPlayers];
            PInput.Instance.SetFakeGamePad(2, PlayerIndex.Two);
            int i = 0;
            for (i = 0; i < CurrentPlayers; i++)
            {
                NewTeams[i] = teams[i];
            }
            NewTeams[i] = new Triplet<Team, PlayerIndex, TeamType>((Team)(i + 1), PlayerIndex.Two, TeamType.AI);
            i++;
            NewTeams[i] = new Triplet<Team, PlayerIndex, TeamType>((Team)(i + 1), PlayerIndex.Two, TeamType.AI);
            i++;
            NewTeams[i] = new Triplet<Team, PlayerIndex, TeamType>((Team)(i + 1), PlayerIndex.Two, TeamType.AI);
            i++;
            NewTeams[i] = new Triplet<Team, PlayerIndex, TeamType>((Team)(i + 1), PlayerIndex.Two, TeamType.AI);
            i++;
            Game1.Instance.AddMenu(new LevelSelection(NewTeams));
        }
    }
}