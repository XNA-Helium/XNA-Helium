
#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion



namespace Pauliver
{
    public delegate void Callback();

    public class EventManager
    {
        private GameTime gt;
        private static EventManager Instance;
        public class GameEvent
        {
            private float ElapsedTime;
            private Callback eh;
            private float Seconds;
            //private float interval;
            bool Passed;
            //bool Repeating;
            public GameEvent(Callback p_eh, float p_Seconds)
            {
                eh = p_eh;
                Seconds = p_Seconds;
                Passed = false;
                //Repeating = false;
                ElapsedTime = 0;
            }
            public void Update(GameTime gt)
            {
                if (!Passed)
                {
                    ElapsedTime += gt.ElapsedGameTime.Milliseconds / 1000.0f;
                    if (ElapsedTime > Seconds)
                    {
                        eh.Invoke();
                        Passed = true;
                    }
                }
            }
            public bool HasPassed
            {
                get { return Passed; }
            }
        }
        List<GameEvent> Events;
        List<GameEvent> RemoveUS;

        private EventManager()
        {
            Events = new List<GameEvent>();
            gt = new GameTime(TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero);
            RemoveUS = new List<GameEvent>();
        }

        public static EventManager GetInstance()
        {
            if (Instance == null)
            {
                Instance = new EventManager();
            }
            return Instance;
        }

        public void AddEvent(Callback p_eh, float p_seconds)
        {
            float blah = gt.ElapsedGameTime.Seconds + (gt.ElapsedGameTime.Milliseconds / 1000.0f);
            GameEvent e = new GameEvent(p_eh, p_seconds);
            Events.Add(e);
        }

        public void Update(GameTime time)
        {
            gt = time;
            for (int i = 0; i < Events.Count; ++i)
            {
                Events[i].Update(time);
                if (Events[i].HasPassed)
                {
                    RemoveUS.Add(Events[i]);
                }
            }
            for (int i = 0; i < RemoveUS.Count; ++i)
            {
                Events.Remove(RemoveUS[i]);
            }
            RemoveUS.Clear();
        }

    }
}
