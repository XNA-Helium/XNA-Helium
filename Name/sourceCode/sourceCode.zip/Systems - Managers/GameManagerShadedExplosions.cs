

#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{
    class GameManagerShadedExplosions : GameMangerToys
    {
        public GameManagerShadedExplosions(List<Triplet<Team, PlayerIndex, TeamType>> teams, DynamicLevel level, BaseCollision Collision)
            : base(teams, level, Collision)
        {

        }
        public virtual void DrawExplosions(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            //SpriteSorter<GameObject> ss = new SpriteSorter<GameObject>(_SceneGraph,GetValue,SpriteSorter<GameObject>.Greater);
            foreach (GameObject gameObject in _SceneGraph)//ss.GetList())
            {
                if (gameObject is DefaultExplosion)
                {
                    gameObject.Draw(p_SpriteBatch, p_GameTime, p_Screen);
                }

            }
        }
        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            foreach (GameObject gameObject in _SceneGraph)
            {
                if (!(gameObject is DefaultExplosion))
                {
                    gameObject.Draw(p_SpriteBatch, p_GameTime, p_Screen);
                }
            }
            foreach (GameObject gameObject in _RemoveUs)
            {
                _SceneGraph.Remove(gameObject);
            }
            _RemoveUs.Clear();
            //System.GC.Collect();
        }
    }

}