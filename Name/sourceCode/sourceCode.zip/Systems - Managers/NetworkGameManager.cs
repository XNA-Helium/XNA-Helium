

#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Net;
#endregion


namespace Pauliver
{
    public class NetworkGameManager : NetworkGameMangerToys
    {
        public NetworkGameManager(List<Triplet<Team, PlayerIndex, TeamType>> teams, DynamicLevel level, BaseCollision Collision,NetworkManager networkManager)
            : base(teams, level, Collision, networkManager)
        {
        }


        public override void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            base.Draw(p_SpriteBatch, p_GameTime, p_Screen);

            SpriteFont invader = PContentManager.Instance.GetObject<SpriteFont>(@"Content/Art/Fonts/Irken");
            Texture2D you = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/GUI/Arrow");
            Texture2D overlay_top = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/GUI/Overlay_top");
            Texture2D overlay_left = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/GUI/Overlay_left");
            Texture2D overlay_right = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/GUI/Overlay_right");
            Texture2D overlay_bottom = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/GUI/Overlay_bottom");
            Texture2D overlay_map = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/GUI/Overlay_map");
            Texture2D YouDot = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/MiniMap/MiniMapYou");
            Texture2D pixel = PContentManager.Instance.GetObject<Texture2D>("pixel");
            Vector2 currentPosition = UTPM.CurrentAvatar.Position();

            //Draw the green hat
            p_SpriteBatch.Draw(you, currentPosition - new Vector2(0, 64) - new Vector2(p_Screen.X, p_Screen.Y), null, Color.White, 0.0f, new Vector2(you.Width / 2, you.Height / 2), 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.ArrowAbovePlayer));

            //Draw mini map
            p_SpriteBatch.Draw(Terrain.m_MiniMap, new Rectangle(24, 245, Terrain.m_MiniMap.Width, Terrain.m_MiniMap.Height), null, Color.White, 0.0f, Vector2.Zero, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MiniMap));

            {
                //put a box around the mini map
                Texture2D overlaybox = PContentManager.Instance.GetObject<Texture2D>(@"Content/Art/MiniMap/mini_screen");
                Rectangle view = Game1.Instance.CurrentViewport;
                int x = (int)((view.X + (0.5f * view.Width)) / 10.0f) + 24;
                int y = (int)((view.Y + (0.5f * view.Height)) / 10.0f) + 245;
                //Draw the MinMap Overlay to show where in the world you are
                Vector2 positionthing = new Vector2(x, y);
                p_SpriteBatch.Draw(overlaybox, positionthing, null, Color.White, 0.0f, new Vector2(12.0f, 16.0f), 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MiniMapRectangle));
            }


            LinkedList<UserTeamPlayer> teams = UTPM.PlayerManagers;
            Team currentTeam = UTPM.CurrentTeam;
            foreach (UserTeamPlayer pm in teams)
            {
                Team teamName = pm.Team;
                Color teamColor = TeamManager.Instance.GetTeam(teamName);
                Texture2D PlayerDot = TeamManager.Instance.GetTexture(teamName);

                int HPTotal = 0;

                //Plot the players on the Mini-Map
                foreach (PlayerObject p in pm.Avatars)
                {
                    Vector2 v = p.Position();
                    if (v == currentPosition)
                    {
                        p_SpriteBatch.Draw(YouDot, new Vector2((int)(20 + (v.X / 10)), (int)(241 + (v.Y / 10))), null, teamColor, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.GreenPlayerDot) );
                    }
                    else
                    {
                        p_SpriteBatch.Draw(PlayerDot, new Vector2((int)(22 + (v.X / 10)), (int)(243 + (v.Y / 10))), null, teamColor, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MiniMapDot) );
                    }
                    HPTotal += (p[ComponentType.Game_Hitpoint] as Game_Hitpoints).Hitpoints;
                }
                HPTotal /= 5;
                switch (teamName)
                {
                    case Team.Team1:
                        {
                            Vector2 r = new Vector2(8, 228 + (80 - HPTotal));
                            p_SpriteBatch.Draw(pixel, r, null, teamColor, 0.0f, Vector2.Zero, new Vector2(7, HPTotal), SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.TeamHealthBar));
                        }
                        break;
                    case Team.Team2:
                        {
                            Vector2 r = new Vector2(16, 228 + (80 - HPTotal));
                            p_SpriteBatch.Draw(pixel, r, null, teamColor, 0.0f, Vector2.Zero, new Vector2(7, HPTotal), SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.TeamHealthBar));
                        }
                        break;
                    case Team.Team3:
                        {
                            Vector2 r = new Vector2(217, 228 + (80 - HPTotal));
                            p_SpriteBatch.Draw(pixel, r, null, teamColor, 0.0f, Vector2.Zero, new Vector2(7, HPTotal), SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.TeamHealthBar));
                        }
                        break;
                    case Team.Team4:
                        {
                            Vector2 r = new Vector2(225, 228 + (80 - HPTotal));
                            p_SpriteBatch.Draw(pixel, r, null, teamColor, 0.0f, Vector2.Zero, new Vector2(7, HPTotal), SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.TeamHealthBar));
                        }
                        break;
                } 
            }
            p_SpriteBatch.Draw(overlay_top, Vector2.Zero, null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MainScreenOverlay));
            p_SpriteBatch.Draw(overlay_left, new Vector2(0, 9), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MainScreenOverlay));
            p_SpriteBatch.Draw(overlay_right, new Vector2(233, 9), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MainScreenOverlay));
            p_SpriteBatch.Draw(overlay_bottom, new Vector2(7, 306), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MainScreenOverlay));
            p_SpriteBatch.Draw(overlay_map, new Vector2(24, 244), null, Color.White, 0.0f, Vector2.Zero, 1.0f, SpriteEffects.None, DrawLayer.GetLayer(DrawLayer.LayerDepth.MainScreenOverlay));
        }
    
    }
}