

#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{
    public class GameMangerToys : GameManagerTeamed //This should inherit from GameManager and GameManagerTeamed should inherit from this..
    {

        public GameMangerToys(List<Triplet<Team, PlayerIndex, TeamType>> teams, DynamicLevel level, BaseCollision Collision)
            : base(teams, level, Collision)
        {


        }
        public override void SwitchTeam(GameTime p_time, bool CanShoot)
        {
            System.Random rand = new Random();
            if(rand.Next(1,11) == 5)
            {
                int x = rand.Next(100, (int)Game1.Instance.World.X) - 50;
                HealthPack hp = new HealthPack(25, new Vector2(x, Terrain[x] - 32));
                AddToSceneGraphLater(hp);
                Game1.Instance.CenterOn((hp[ComponentType.Game_Position] as Game_Position).Position);
            }
            base.SwitchTeam(p_time, CanShoot);
        }
        
    }
}
