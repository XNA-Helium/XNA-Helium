#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{
    class PContentManager
    {

        System.Collections.Hashtable _ht;
        private Microsoft.Xna.Framework.Content.ContentManager _contentManager;
        private static PContentManager _cm;

        PContentManager()
        {
            _ht = new System.Collections.Hashtable();
            _contentManager = Game1.Instance.ContentManager;
        }
        public static PContentManager Instance
        {
            get
            {
                if (_cm == null)
                {
                    _cm = new PContentManager();
                }
                return _cm;
            }
        }

        //some delage stuff??
        //public void SetupDynamicContent<T>(returns T Delegate, string Name);

        public void SetupDynamicContent(GraphicsDevice p_GraphicsDevice, string Name)
        {
            Texture2D WhiteBox = new Texture2D(p_GraphicsDevice, 2, 2, 1,TextureUsage.AutoGenerateMipMap,SurfaceFormat.Color);
            Color[] WhiteBoxColorData = new Color[4];
            WhiteBox.GetData<Color>(WhiteBoxColorData);
            WhiteBoxColorData[0] = new Color(255, 255, 255, 128);
            WhiteBoxColorData[1] = new Color(255, 255, 255, 128);
            WhiteBoxColorData[2] = new Color(255, 255, 255, 128);
            WhiteBoxColorData[3] = new Color(255, 255, 255, 128);
            WhiteBox.SetData<Color>(WhiteBoxColorData);

            _ht[Name] = WhiteBox;
        }

        public void SetupSinglePixel(GraphicsDevice p_GraphicsDevice, string Name)
        {
            Texture2D WhiteBox = new Texture2D(p_GraphicsDevice, 1, 1, 1, TextureUsage.AutoGenerateMipMap, SurfaceFormat.Color);
            Color[] WhiteBoxColorData = new Color[1];
            WhiteBox.GetData<Color>(WhiteBoxColorData);
            WhiteBoxColorData[0] = Color.White;
            WhiteBox.SetData<Color>(WhiteBoxColorData);

            _ht[Name] = WhiteBox;
        }

        public void SaveContent<T>(T Object, String Name)
        {
            _ht[Name] = Object;
        }

        public void Load<T>(string Name,string Identifier)
        {
            _ht[Name] = _contentManager.Load<T>(Name);
            _ht[Identifier] = _contentManager.Load<T>(Name);
        }

        public void Load<T>(string Name)
        {
            _ht[Name] = _contentManager.Load<T>(Name);
        }

        public T GetObject<T>(string Name)
        {
            if (_ht.Contains(Name))
            {
                return ((T)_ht[Name]);
            }
            else
            {
                Load<T>(Name);
                if (_ht.Contains(Name))
                {
                    return ((T)_ht[Name]);
                }
                else
                {
                    //return texture not found
                    //texture
                    return ((T)_ht[Name]);
                }
            }
        }
    }
}
