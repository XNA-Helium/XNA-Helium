

#region Using Statements
using System;
using System.Collections.Generic;
//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Net;
#endregion


namespace Pauliver
{
    public class NetworkGameMangerToys : NetworkGameManagerTeamed //This should inherit from GameManager and GameManagerTeamed should inherit from this..
    {
        public static short HEALTHPACKDROP = 0x50;
        public NetworkGameMangerToys(List<Triplet<Team, PlayerIndex, TeamType>> teams, DynamicLevel level, BaseCollision Collision, NetworkManager nm)
            : base(teams, level, Collision, nm)
        {
            NetManager.AddNCallBack(HEALTHPACKDROP, HealthPackDrop);
        }

        ~NetworkGameMangerToys()
        {
            NetManager.RemoveCalback(HEALTHPACKDROP);
        }

        protected bool HealthPackDrop(PacketReader pr)
        {
            int hp2 = pr.ReadInt32();
            int x = pr.ReadInt32();
            int y = pr.ReadInt32();
            HealthPack hp = new HealthPack(hp2, new Vector2(x, y));
            AddToSceneGraphLater(hp);
            return true;
        }

        public override void SwitchTeam(double p_time, bool CanShoot)
        {
            if (UTPM.Current.TeamType == TeamType.Local)
            {
                System.Random rand = new Random();
                if (rand.Next(1, 11) == 5)
                {
                    int x = rand.Next(100, (int)Game1.Instance.World.X) - 50;
                    int y = Terrain[x] - 32;
                    int hp2 = 25;
                    HealthPack hp = new HealthPack(hp2, new Vector2(x, y));
                    PacketWriter pw = new PacketWriter();
                    pw.Write(HEALTHPACKDROP);
                    pw.Write((int)hp2);
                    pw.Write((int)x);
                    pw.Write((int)y);
                    NetManager.SendToAll(pw);
                    AddToSceneGraphLater(hp);
                }
            }
            base.SwitchTeam(p_time, CanShoot);
        }
        
    }
}
