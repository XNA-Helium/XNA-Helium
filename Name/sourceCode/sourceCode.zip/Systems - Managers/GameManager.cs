

#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion


namespace Pauliver
{

    public abstract class GameManager
    {
        public GameManager(Level Level, BaseCollision collision)
        {
            _collision = collision;
            _level = Level;

            _SceneGraph = new List<GameObject>();

            _RemoveUs = new List<GameObject>();
            _AddUs = new List<GameObject>();
            _Collectables = new List<GameObject>();

        }

        protected BaseCollision _collision;


        protected Level _level;
        protected List<GameObject> _SceneGraph;
        protected List<GameObject> _RemoveUs;
        protected List<GameObject> _AddUs;
        public List<GameObject> _Collectables;

        public Level Level
        {
            get
            {
                return _level;
            }
        }

        public Terrain Terrain
        {
            get
            {
                return _level.Terrain;
            }
        }

        public List<GameObject> SceneGraph
        {
            get
            {
                return _SceneGraph;
            }
        }

        public int GetIndex(GameObject go)
        {
            return _SceneGraph.IndexOf(go);
        }

        protected virtual void RemoveObjects()
        {
            foreach (GameObject gameObject in _RemoveUs)
            {
                RemoveObject(gameObject);
            }
            _RemoveUs.Clear();
        }

        private void RemoveObject(GameObject Object)
        {
            _SceneGraph.Remove(Object);
        }

        public virtual void Update(GameTime p_time)
        {
            {
                for (int i = 0; i < _SceneGraph.Count; ++i)
                {
                    _SceneGraph[i].Update(p_time);
                }

                _level.Update(p_time);
            }
            {
                //now collision
                _collision.ObjectOnObjectCollision();
                //now terrain collision
                _collision.ObjectOnTerrainCollision();
            }
            if (_RemoveUs.Count > 0)
            {
                RemoveObjects();
            }

            if (_AddUs.Count > 0)
            {
                foreach (GameObject gameObject in _AddUs)
                {
                    _SceneGraph.Add(gameObject);
                }
                _AddUs.Clear();
            }
        }

        public virtual void Draw(SpriteBatch p_SpriteBatch, GameTime p_GameTime, Rectangle p_Screen)
        {
            foreach (GameObject gameObject in _SceneGraph)
            {
                gameObject.Draw(p_SpriteBatch, p_GameTime, p_Screen);
            }
        }

        public virtual void AddToSceneGraphLater(GameObject Object)
        {
            _AddUs.Add(Object);

            if (Object is Napalm || Object is LandMine || Object is HealthPack)
                _Collectables.Add(Object);
        }

        public void AddToSceneGraph(GameObject Object)
        {
            _SceneGraph.Add(Object);
            if (Object is Napalm || Object is LandMine || Object is HealthPack)
                _Collectables.Add(Object);
        }

        public virtual void RemoveFromSceneGraph(GameObject Object)
        {
            _RemoveUs.Add(Object);

            if (Object is Napalm || Object is LandMine || Object is HealthPack)
                _Collectables.Remove(Object);
        }
    }
}
