﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Name Beta 2")]
[assembly: AssemblyProduct("Name Beta 2")]
[assembly: AssemblyDescription("Beta 2.0 with AI and Netcode.")]
[assembly: AssemblyCompany("Legendary Studios LLC")]

[assembly: AssemblyCopyright("Copyright © Legendary Studios LLC 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("7d78ccf8-3ad5-463a-b7d0-20e609c57ea6")]


// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("2.0.0.0")]
