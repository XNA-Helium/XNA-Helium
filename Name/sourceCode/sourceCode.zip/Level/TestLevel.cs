#region Using Statements
using System;
using System.Collections.Generic;//using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Pauliver
{
    public enum PlayerStage { Movement, Deploying, Aiming, Shooting, Running, Done };


        /*
    public class TestLevel : DynamicLevel
    {
        public TestLevel(Texture2D p_Texture,Texture2D p_MiniMap,BaseCollision p_Collision,TerrainSaver ts)
            : base(p_Texture, p_MiniMap, p_Collision, ts)
        {
        }
    }
        */
}